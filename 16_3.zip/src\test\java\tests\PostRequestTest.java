package tests;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.File;

public class PostRequestTest {

    @Test
    public void verifyPostRequestWithJsonFile() {

        // Step 3: Reference the JSON file placed in src/test/resources
        File jsonFile = new File("src/test/resources/samsung_edge.json");

        // Step 4: Use the JSON file as the request body and send POST request
        Response response = RestAssured
                .given()
                    .baseUri("https://api.restful-api.dev")
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .body(jsonFile)
                    .log().all()
                .when()
                    .post("/objects")
                .then()
                    .log().all()
                    .extract()
                    .response();

        // Step 5: Verify the status code is 200
        int statusCode = response.getStatusCode();
        System.out.println("Status Code: " + statusCode);
        Assert.assertEquals(statusCode, 200, "Expected status code 200 but got: " + statusCode);

        // Step 6: Print the entire response
        System.out.println("========= Full Response =========");
        System.out.println("Status Code  : " + response.getStatusCode());
        System.out.println("Status Line  : " + response.getStatusLine());
        System.out.println("Response Time: " + response.getTime() + " ms");
        System.out.println("Headers      : " + response.getHeaders());
        System.out.println("Response Body:");
        System.out.println(response.getBody().asPrettyString());
        System.out.println("=================================");
    }
}
