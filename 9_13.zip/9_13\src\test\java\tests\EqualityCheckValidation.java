package tests;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class EqualityCheckValidation {

    @Test
    public void validateResponseUsingEqualityCheck() {

        String requestBody = "{\n"
                + "    \"firstname\": \"Jim\",\n"
                + "    \"lastname\": \"Brown\",\n"
                + "    \"totalprice\": 111,\n"
                + "    \"depositpaid\": true,\n"
                + "    \"bookingdates\": {\n"
                + "        \"checkin\": \"2018-01-01\",\n"
                + "        \"checkout\": \"2019-01-01\"\n"
                + "    },\n"
                + "    \"additionalneeds\": \"Breakfast\"\n"
                + "}";

        // Step 1: POST request
        // Step 2: Check if each response value equals the expected value using equalTo()
        Response response = given()
                    .baseUri("https://restful-booker.herokuapp.com")
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .body(requestBody)
                .when()
                    .post("/booking")
                .then()
                    .assertThat()
                        .statusCode(equalTo(200))
                        .body("booking.firstname",                equalTo("Jim"))
                        .body("booking.lastname",                 equalTo("Brown"))
                        .body("booking.totalprice",               equalTo(111))
                        .body("booking.depositpaid",              equalTo(true))
                        .body("booking.bookingdates.checkin",     equalTo("2018-01-01"))
                        .body("booking.bookingdates.checkout",    equalTo("2019-01-01"))
                        .body("booking.additionalneeds",          equalTo("Breakfast"))
                    .extract()
                    .response();

        // Step 3: Print the response in the console
        System.out.println("Response Status Code              : " + response.getStatusCode());
        System.out.println("Response Body                     : " + response.getBody().asPrettyString());
        System.out.println("------ Equality Check Results ------");
        System.out.println("booking.firstname    equals Jim          : " + response.jsonPath().getString("booking.firstname").equals("Jim"));
        System.out.println("booking.lastname     equals Brown        : " + response.jsonPath().getString("booking.lastname").equals("Brown"));
        System.out.println("booking.totalprice   equals 111          : " + (response.jsonPath().getInt("booking.totalprice") == 111));
        System.out.println("booking.depositpaid  equals true         : " + (response.jsonPath().getBoolean("booking.depositpaid") == true));
        System.out.println("checkin              equals 2018-01-01   : " + response.jsonPath().getString("booking.bookingdates.checkin").equals("2018-01-01"));
        System.out.println("checkout             equals 2019-01-01   : " + response.jsonPath().getString("booking.bookingdates.checkout").equals("2019-01-01"));
        System.out.println("additionalneeds      equals Breakfast    : " + response.jsonPath().getString("booking.additionalneeds").equals("Breakfast"));
    }
}
