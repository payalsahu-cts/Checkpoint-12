package com.api.tests;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;

import static io.restassured.RestAssured.*;

/**
 * Test Class : GetAPIResponseInJSON
 *
 * Scenario   : Get the API response in JSON in REST Assured
 * API        : https://restful-booker.herokuapp.com/booking
 * Method     : GET
 *
 * Steps covered:
 * Step 1 - Maven project with TestNG & REST Assured dependencies (pom.xml)
 * Step 2 - Java class created in REST Assured framework (this file)
 * Step 3 - GET request sent to https://restful-booker.herokuapp.com/booking
 * Step 4 - Retrieve the response body and parse it into JSON
 * Step 5 - Print the values of JSON
 *
 * API Response Format:
 * [
 *   { "bookingid": 1 },
 *   { "bookingid": 2 },
 *   ...
 * ]
 */
public class GetAPIResponseInJSON {

    // ----------------------------------------------------------------
    // Constants
    // ----------------------------------------------------------------
    private static final String BASE_URL = "https://restful-booker.herokuapp.com";
    private static final String ENDPOINT = "/booking";

    // ----------------------------------------------------------------
    // Step 2 : Setup — configure base URI before tests run
    // ----------------------------------------------------------------
    @BeforeClass
    public void setUp() {
        RestAssured.baseURI = BASE_URL;
        System.out.println("=======================================================");
        System.out.println("  REST Assured Framework - Get API Response in JSON    ");
        System.out.println("=======================================================");
        System.out.println("Base URI : " + BASE_URL);
        System.out.println("Endpoint : " + ENDPOINT);
    }

    // ================================================================
    // Step 3, 4, 5 — GET request, parse JSON, print values
    //                 using REST Assured JsonPath (primary approach)
    // ================================================================

    /**
     * TEST 1 : Parse and print using REST Assured JsonPath
     *
     * Step 3 - Sends GET request
     * Step 4 - Parses response body into JSON via JsonPath
     * Step 5 - Prints all bookingid values from the JSON array
     */
    @Test(priority = 1, description = "GET booking list, parse JSON, print all bookingid values")
    public void getAndPrintJSON_UsingJsonPath() {

        System.out.println("\n[TEST 1] Parse & Print JSON using REST Assured JsonPath");
        System.out.println("-------------------------------------------------------");

        // Step 3: Send GET request
        Response response =
            given()
                .header("Accept", "application/json")   // Request JSON response
                .log().uri()
            .when()
                .get(ENDPOINT)
            .then()
                .statusCode(200)
                .extract()
                .response();

        // Step 4: Parse response body into JSON using JsonPath
        JsonPath jsonPath = response.jsonPath();

        // Step 5: Print raw JSON response body
        System.out.println("\n--- Raw JSON Response Body ---");
        System.out.println(response.getBody().asPrettyString());

        // Step 5: Extract and print each bookingid from the JSON array
        List<Integer> bookingIds = jsonPath.getList("bookingid");

        System.out.println("\n--- Parsed JSON Values ---");
        System.out.println("Total Bookings Found : " + bookingIds.size());
        System.out.println("\nBooking IDs:");

        for (int i = 0; i < bookingIds.size(); i++) {
            System.out.println("  [" + (i + 1) + "] bookingid : " + bookingIds.get(i));
        }

        // Verify the list is not empty
        Assert.assertFalse(bookingIds.isEmpty(), "Booking list should not be empty");

        System.out.println("\n[TEST 1] PASSED - JSON parsed and all bookingid values printed");
    }

    // ================================================================
    // Step 3, 4, 5 — Parse using List of Maps
    // ================================================================

    /**
     * TEST 2 : Parse and print using List<Map> structure
     *
     * Step 3 - GET request
     * Step 4 - Parse entire JSON array into List of Maps
     * Step 5 - Iterate and print each JSON object (key-value pairs)
     */
    @Test(priority = 2, description = "GET booking list, parse into List of Maps, print key-value pairs")
    public void getAndPrintJSON_UsingListOfMaps() {

        System.out.println("\n[TEST 2] Parse & Print JSON using List of Maps");
        System.out.println("-------------------------------------------------------");

        // Step 3: Send GET request
        Response response =
            given()
                .header("Accept", "application/json")
                .log().uri()
            .when()
                .get(ENDPOINT)
            .then()
                .statusCode(200)
                .extract()
                .response();

        // Step 4: Parse response body into List of Maps
        List<Map<String, Integer>> bookingList = response.jsonPath().getList("$");

        // Step 5: Print each JSON object and its values
        System.out.println("\n--- Parsed JSON Array (List of Maps) ---");
        System.out.println("Total Records : " + bookingList.size());
        System.out.println();

        for (int i = 0; i < bookingList.size(); i++) {
            Map<String, Integer> booking = bookingList.get(i);
            System.out.println("Record [" + (i + 1) + "] :");
            for (Map.Entry<String, Integer> entry : booking.entrySet()) {
                System.out.println("   Key   : " + entry.getKey());
                System.out.println("   Value : " + entry.getValue());
            }
        }

        Assert.assertNotNull(bookingList, "Booking list should not be null");
        Assert.assertTrue(bookingList.size() > 0, "Booking list should contain at least one record");

        System.out.println("\n[TEST 2] PASSED - JSON array parsed into List of Maps and printed");
    }

    // ================================================================
    // Step 3, 4, 5 — Parse using Jackson ObjectMapper
    // ================================================================

    /**
     * TEST 3 : Parse and print using Jackson ObjectMapper
     *
     * Step 3 - GET request
     * Step 4 - Parse response body string into Jackson JsonNode tree
     * Step 5 - Iterate node tree and print all values
     */
    @Test(priority = 3, description = "GET booking list, parse with Jackson ObjectMapper, print JSON tree")
    public void getAndPrintJSON_UsingJacksonObjectMapper() throws Exception {

        System.out.println("\n[TEST 3] Parse & Print JSON using Jackson ObjectMapper");
        System.out.println("-------------------------------------------------------");

        // Step 3: Send GET request and get response as String
        String responseBody =
            given()
                .header("Accept", "application/json")
                .log().uri()
            .when()
                .get(ENDPOINT)
            .then()
                .statusCode(200)
                .extract()
                .asString();

        // Step 4: Parse JSON string into Jackson JsonNode
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode jsonArray = objectMapper.readTree(responseBody);

        // Step 5: Print values from the parsed JSON tree
        System.out.println("\n--- Parsed JSON via Jackson ObjectMapper ---");
        System.out.println("Is JSON Array   : " + jsonArray.isArray());
        System.out.println("Total Elements  : " + jsonArray.size());
        System.out.println();

        for (int i = 0; i < jsonArray.size(); i++) {
            JsonNode bookingNode = jsonArray.get(i);
            System.out.println("Element [" + (i + 1) + "] :");
            bookingNode.fields().forEachRemaining(field ->
                System.out.println("   " + field.getKey() + " : " + field.getValue())
            );
        }

        Assert.assertTrue(jsonArray.isArray(), "Response should be a JSON array");
        Assert.assertTrue(jsonArray.size() > 0, "JSON array should not be empty");

        System.out.println("\n[TEST 3] PASSED - JSON parsed via Jackson and values printed");
    }

    // ================================================================
    // Step 3, 4, 5 — Print specific first & last booking IDs
    // ================================================================

    /**
     * TEST 4 : Print first and last bookingid from JSON response
     *
     * Step 3 - GET request
     * Step 4 - Parse JSON
     * Step 5 - Print first and last bookingid values specifically
     */
    @Test(priority = 4, description = "Print first and last bookingid from JSON response")
    public void getAndPrintFirstAndLastBookingId() {

        System.out.println("\n[TEST 4] Print First and Last Booking ID from JSON");
        System.out.println("-------------------------------------------------------");

        // Step 3: GET request
        Response response =
            given()
                .header("Accept", "application/json")
                .log().uri()
            .when()
                .get(ENDPOINT)
            .then()
                .statusCode(200)
                .extract()
                .response();

        // Step 4: Parse JSON
        JsonPath jsonPath = response.jsonPath();
        List<Integer> bookingIds = jsonPath.getList("bookingid");

        // Step 5: Print first and last booking ID
        int firstBookingId = bookingIds.get(0);
        int lastBookingId  = bookingIds.get(bookingIds.size() - 1);

        System.out.println("\n--- JSON Values (First & Last) ---");
        System.out.println("Total Booking IDs : " + bookingIds.size());
        System.out.println("First Booking ID  : " + firstBookingId);
        System.out.println("Last  Booking ID  : " + lastBookingId);
        System.out.println("All   Booking IDs : " + bookingIds);

        Assert.assertTrue(firstBookingId > 0, "First bookingid should be greater than 0");
        Assert.assertTrue(lastBookingId  > 0, "Last bookingid should be greater than 0");

        System.out.println("\n[TEST 4] PASSED - First and last bookingid values printed");
    }
}
