# REST Assured - Get API Response in JSON

## Scenario: Get the API Response in JSON in REST Assured

| Step | Description |
|------|-------------|
| 1 | Maven project with TestNG & REST Assured dependencies |
| 2 | Java class created in REST Assured framework |
| 3 | GET request sent to `https://restful-booker.herokuapp.com/booking` |
| 4 | Retrieve the response body and parse it into JSON |
| 5 | Print the values of JSON |

---

## Project Structure

```
json-response-project/
├── pom.xml                          ← Maven dependencies
├── testng.xml                       ← TestNG suite configuration
├── README.md
└── src/
    └── test/
        └── java/
            └── com/api/tests/
                └── GetAPIResponseInJSON.java   ← Main test class
```

---

## API Details

- **URL:** `https://restful-booker.herokuapp.com/booking`
- **Method:** GET
- **Accept Header:** `application/json`
- **Expected Response:** JSON array of booking IDs

### Sample Response
```json
[
    { "bookingid": 1 },
    { "bookingid": 2 },
    { "bookingid": 3 }
]
```

---

## Dependencies Used

| Library | Version | Purpose |
|---------|---------|---------|
| REST Assured | 5.3.2 | API testing & JSON path parsing |
| TestNG | 7.8.0 | Test runner & assertions |
| Jackson Databind | 2.15.2 | JSON parsing via ObjectMapper |
| JSON Simple | 1.1.1 | Lightweight JSON parsing |
| Hamcrest | 2.2 | Response matchers |

---

## Test Cases

| Test Method | Step 4 — Parse Method | Step 5 — Print Output |
|-------------|----------------------|----------------------|
| `getAndPrintJSON_UsingJsonPath` | REST Assured `JsonPath` | All bookingid values from array |
| `getAndPrintJSON_UsingListOfMaps` | `List<Map>` via JsonPath | Each JSON object's key-value pairs |
| `getAndPrintJSON_UsingJacksonObjectMapper` | Jackson `ObjectMapper` + `JsonNode` | Full JSON tree traversal |
| `getAndPrintFirstAndLastBookingId` | `JsonPath.getList()` | First & last bookingid + full list |

---

## How to Run

```bash
mvn clean test
```

Or in IDE: Right-click `testng.xml` → **Run**

---

## Sample Console Output (TEST 1)

```
--- Raw JSON Response Body ---
[
    { "bookingid": 1 },
    { "bookingid": 3 },
    { "bookingid": 5 }
]

--- Parsed JSON Values ---
Total Bookings Found : 3

Booking IDs:
  [1] bookingid : 1
  [2] bookingid : 3
  [3] bookingid : 5
```
