package tests;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import pojo.Booking;
import pojo.BookingDates;

public class CreateBookingTest {

    public static void main(String[] args) throws JsonProcessingException {

        // Step 1: Build the BookingDates POJO
        BookingDates bookingDates = new BookingDates();
        bookingDates.setCheckin("2018-01-01");
        bookingDates.setCheckout("2019-01-01");

        // Step 2: Build the Booking POJO and pass BookingDates into it
        Booking booking = new Booking();
        booking.setFirstname("Jim");
        booking.setLastname("Brown");
        booking.setTotalprice(111);
        booking.setDepositpaid(true);
        booking.setBookingdates(bookingDates);
        booking.setAdditionalneeds("Breakfast");

        // Step 3: Serialize the POJO to a JSON string using ObjectMapper
        ObjectMapper objectMapper = new ObjectMapper();
        String requestBody = objectMapper.writeValueAsString(booking);

        System.out.println("Serialized Request Body:");
        System.out.println(requestBody);
        System.out.println();

        // Step 4: Send POST request to the booking API
        Response response = RestAssured
                .given()
                    .baseUri("https://restful-booker.herokuapp.com")
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .body(requestBody)
                    .log().all()
                .when()
                    .post("/booking")
                .then()
                    .log().all()
                    .statusCode(200)
                    .extract()
                    .response();

        // Step 5: Print the response body to the console
        System.out.println("Response Body:");
        System.out.println(response.getBody().asPrettyString());
    }
}
