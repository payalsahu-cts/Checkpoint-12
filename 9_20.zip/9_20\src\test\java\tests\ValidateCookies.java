package tests;

import io.restassured.http.Cookie;
import io.restassured.http.Cookies;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

public class ValidateCookies {

    // Step 2: Cookie key is "skill" and value is "Communication"
    private static final String COOKIE_KEY   = "skill";
    private static final String COOKIE_VALUE = "Communication";

    @Test
    public void validateCookiesFromResponse() {

        // Step 3: GET request to set cookies via query param
        Response response = given()
                    .baseUri("https://postman-echo.com")
                    .queryParam(COOKIE_KEY, COOKIE_VALUE)
                    .redirects().follow(true)
                .when()
                    .get("/cookies/set")
                .then()
                    .assertThat()
                        .statusCode(200)
                    .extract()
                    .response();

        // Step 4: Extract ALL cookies from the response
        Cookies allCookies = response.detailedCookies();

        System.out.println("Response Status Code          : " + response.getStatusCode());
        System.out.println("Response Body                 : " + response.getBody().asPrettyString());
        System.out.println("------ All Cookies ------");
        for (Cookie cookie : allCookies) {
            System.out.println("Cookie Name  : " + cookie.getName());
            System.out.println("Cookie Value : " + cookie.getValue());
            System.out.println("-------------------------");
        }

        // Step 5: Extract SPECIFIC cookie — "skill"
        String specificCookieValue = response.getCookie(COOKIE_KEY);
        System.out.println("------ Specific Cookie ------");
        System.out.println("Cookie Key   : " + COOKIE_KEY);
        System.out.println("Cookie Value : " + specificCookieValue);

        // Step 6: Validate the specific cookie value using given().then() chain
        given()
            .baseUri("https://postman-echo.com")
            .queryParam(COOKIE_KEY, COOKIE_VALUE)
            .redirects().follow(true)
        .when()
            .get("/cookies/set")
        .then()
            .assertThat()
                .statusCode(200)
                // Validate cookie value equals "Communication"
                .cookie(COOKIE_KEY, equalTo(COOKIE_VALUE));

        System.out.println("------ Cookie Value Validation ------");
        System.out.println("Cookie '" + COOKIE_KEY + "' equals '" + COOKIE_VALUE + "' : PASSED");

        // Step 7: Validate the specific cookie EXISTS (is not null)
        given()
            .baseUri("https://postman-echo.com")
            .queryParam(COOKIE_KEY, COOKIE_VALUE)
            .redirects().follow(true)
        .when()
            .get("/cookies/set")
        .then()
            .assertThat()
                .statusCode(200)
                // Validate cookie exists (notNullValue)
                .cookie(COOKIE_KEY, notNullValue());

        System.out.println("------ Cookie Existence Validation ------");
        System.out.println("Cookie '" + COOKIE_KEY + "' exists : PASSED");
    }
}
