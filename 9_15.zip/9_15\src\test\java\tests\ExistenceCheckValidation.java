package tests;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import java.util.Map;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.hasKey;
import static org.hamcrest.Matchers.notNullValue;

public class ExistenceCheckValidation {

    @Test
    public void checkKeyExistenceInResponse() {

        String requestBody = "{\n"
                + "    \"firstname\": \"Jim\",\n"
                + "    \"lastname\": \"Brown\",\n"
                + "    \"totalprice\": 111,\n"
                + "    \"depositpaid\": true,\n"
                + "    \"bookingdates\": {\n"
                + "        \"checkin\": \"2018-01-01\",\n"
                + "        \"checkout\": \"2019-01-01\"\n"
                + "    },\n"
                + "    \"additionalneeds\": \"Breakfast\"\n"
                + "}";

        // Step 1: POST request
        // Step 2: Check if a key exists in the response
        Response response = given()
                    .baseUri("https://restful-booker.herokuapp.com")
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .body(requestBody)
                .when()
                    .post("/booking")
                .then()
                    .assertThat()
                        .statusCode(200)
                        // Check top-level key existence using hasKey()
                        .body("$",       hasKey("bookingid"))
                        .body("$",       hasKey("booking"))
                        // Check nested key existence inside "booking"
                        .body("booking", hasKey("firstname"))
                        .body("booking", hasKey("lastname"))
                        .body("booking", hasKey("totalprice"))
                        .body("booking", hasKey("depositpaid"))
                        .body("booking", hasKey("bookingdates"))
                        .body("booking", hasKey("additionalneeds"))
                        // Check deeply nested key existence inside "booking.bookingdates"
                        .body("booking.bookingdates", hasKey("checkin"))
                        .body("booking.bookingdates", hasKey("checkout"))
                        // Confirm values of existing keys are not null
                        .body("bookingid",                        notNullValue())
                        .body("booking.firstname",                notNullValue())
                        .body("booking.bookingdates.checkin",     notNullValue())
                    .extract()
                    .response();

        // Step 3: Print the response in the console
        Map<String, Object> root         = response.jsonPath().getMap("$");
        Map<String, Object> booking      = response.jsonPath().getMap("booking");
        Map<String, Object> bookingDates = response.jsonPath().getMap("booking.bookingdates");

        System.out.println("Response Status Code              : " + response.getStatusCode());
        System.out.println("Response Body                     : " + response.getBody().asPrettyString());
        System.out.println("------ Key Existence Check Results ------");
        System.out.println("Root level key 'bookingid' exists : " + root.containsKey("bookingid"));
        System.out.println("Root level key 'booking' exists   : " + root.containsKey("booking"));
        System.out.println("booking key 'firstname' exists    : " + booking.containsKey("firstname"));
        System.out.println("booking key 'lastname' exists     : " + booking.containsKey("lastname"));
        System.out.println("booking key 'totalprice' exists   : " + booking.containsKey("totalprice"));
        System.out.println("booking key 'depositpaid' exists  : " + booking.containsKey("depositpaid"));
        System.out.println("booking key 'bookingdates' exists : " + booking.containsKey("bookingdates"));
        System.out.println("booking key 'additionalneeds' exists: " + booking.containsKey("additionalneeds"));
        System.out.println("bookingdates key 'checkin' exists : " + bookingDates.containsKey("checkin"));
        System.out.println("bookingdates key 'checkout' exists: " + bookingDates.containsKey("checkout"));
    }
}
