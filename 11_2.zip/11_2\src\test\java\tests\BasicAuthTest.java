package tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class BasicAuthTest {

    private static final String BASE_URI = "https://postman-echo.com";
    private static final String ENDPOINT = "/basic-auth";
    private static final String USERNAME  = "postman";
    private static final String PASSWORD  = "password";

    private Response response;

    // Step 2: Set up Basic Auth and send GET request @BeforeClass
    @BeforeClass
    public void setUpBasicAuth() {

        System.out.println("=======================================================");
        System.out.println(" Setting up Basic Authentication:");
        System.out.println("   URL      : " + BASE_URI + ENDPOINT);
        System.out.println("   Method   : GET");
        System.out.println("   Username : " + USERNAME);
        System.out.println("   Password : " + PASSWORD);
        System.out.println("=======================================================");

        // Step 3 & 4: Send GET request with Basic Auth credentials
        response = RestAssured
                .given()
                    .baseUri(BASE_URI)
                    .auth()
                    .basic(USERNAME, PASSWORD)
                    .log().all()
                .when()
                    .get(ENDPOINT)
                .then()
                    .log().all()
                    .extract()
                    .response();
    }

    // Step 5: Verify the status code of Basic Auth is 200
    @Test(priority = 1)
    public void verifyBasicAuthStatusCode() {

        int actualStatusCode = response.getStatusCode();

        System.out.println("=======================================================");
        System.out.println(" Verifying Status Code");
        System.out.println("-------------------------------------------------------");
        System.out.println(" Expected Status Code : 200");
        System.out.println(" Actual Status Code   : " + actualStatusCode);
        System.out.println("=======================================================");

        Assert.assertEquals(actualStatusCode, 200,
                "Expected status code 200 but received: " + actualStatusCode);

        System.out.println(" Test Passed: Status Code 200 verified successfully.");
        System.out.println("=======================================================");
    }

    // Step 6: Verify the response body of Basic Auth
    @Test(priority = 2)
    public void verifyBasicAuthResponseBody() {

        String responseBody    = response.getBody().asString();
        boolean authenticated  = response.jsonPath().getBoolean("authenticated");

        System.out.println("=======================================================");
        System.out.println(" Verifying Response Body");
        System.out.println("-------------------------------------------------------");
        System.out.println(" Full Response Body       : " + responseBody);
        System.out.println(" authenticated field      : " + authenticated);
        System.out.println(" Expected authenticated   : true");
        System.out.println("=======================================================");

        Assert.assertNotNull(responseBody,
                "Response body should not be null.");

        Assert.assertTrue(authenticated,
                "Expected 'authenticated' to be true but got: " + authenticated);

        System.out.println(" Test Passed: Response body verified successfully.");
        System.out.println(" Test Passed: 'authenticated' field is true.");
        System.out.println("=======================================================");
    }
}
