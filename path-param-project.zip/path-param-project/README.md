# REST Assured - Get API Response with Path Parameter

## Scenario: Get API Response with Path Parameter

| Step | Description |
|------|-------------|
| 1 | Maven project with TestNG & REST Assured dependencies |
| 2 | Java class created in REST Assured framework |
| 3 | GET request to `https://jsonplaceholder.typicode.com/posts` |
| 4 | Path parameter: `id = 5` → resolves to `/posts/5` |
| 5 | Print all values of the response in the console |

---

## ⚡ Path Param vs Query Param — Key Difference

| Type | Syntax | Resolved URL |
|------|--------|-------------|
| **Path Parameter** | `.pathParam("id", 5)` | `/posts/5` |
| **Query Parameter** | `.queryParam("id", 5)` | `/posts?id=5` |

The path parameter value is embedded **inside** the URL path itself.

---

## Project Structure

```
path-param-project/
├── pom.xml                                  ← Maven dependencies
├── testng.xml                               ← TestNG suite configuration
├── README.md
└── src/
    └── test/
        └── java/
            └── com/api/tests/
                └── GetResponseWithPathParameter.java  ← Main test class
```

---

## API Details

- **Base URL:** `https://jsonplaceholder.typicode.com`
- **Endpoint:** `/posts/{id}`
- **Resolved URL:** `https://jsonplaceholder.typicode.com/posts/5`
- **Method:** GET
- **Path Param:** `id = 5`

### Expected Response
```json
{
    "userId": 1,
    "id": 5,
    "title": "nesciunt quas odio",
    "body": "repudiandae veniam quaerat sunt sed\nalias aut fugiat..."
}
```

---

## Three Ways to Pass Path Parameters (all demonstrated)

| Method | Code | Notes |
|--------|------|-------|
| `.pathParam()` | `.pathParam("id", 5)` with `.get("/posts/{id}")` | Recommended — clean & reusable |
| Named placeholder | `.pathParam("id", postId)` with `/posts/{id}` | Best for variables |
| Inline URL | `.get("/posts/5")` | Quick one-liners |

---

## Test Cases

| Test Method | Path Param Style | Step 5 Output |
|-------------|-----------------|---------------|
| `getResponseWithPathParam_AndPrintValues` | `.pathParam()` | Formatted table + full field values |
| `getResponseWithPathParam_InlineURL` | Inline `/posts/5` | Raw pretty JSON |
| `getResponseWithNamedPlaceholder_PrintFieldTypes` | Named `{id}` placeholder | Fields with type labels |
| `getResponseWithPathParam_JacksonFullPrint` | `.pathParam()` + Jackson | Full JSON node traversal |

---

## How to Run

```bash
mvn clean test
```

Or in IDE: Right-click `testng.xml` → **Run**

---

## Sample Console Output (TEST 1)

```
--- Path Parameter Response Values ---
+------------+-----------------------------------------------+
| Field      | Value                                         |
+------------+-----------------------------------------------+
| userId     | 1                                             |
| id         | 5                                             |
| title      | nesciunt quas odio                            |
| body       | repudiandae veniam quaerat sunt sed...        |
+------------+-----------------------------------------------+

--- Full Body Value ---
userId : 1
id     : 5
title  : nesciunt quas odio
body   : repudiandae veniam quaerat sunt sed
alias aut fugiat sit autem mollitia voluptatibus temporibus...
```
