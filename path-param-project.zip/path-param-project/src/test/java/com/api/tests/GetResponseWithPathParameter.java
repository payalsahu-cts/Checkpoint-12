package com.api.tests;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;

/**
 * Test Class : GetResponseWithPathParameter
 *
 * Scenario   : Get the API response with path parameter in REST Assured
 * API        : https://jsonplaceholder.typicode.com/posts
 * Method     : GET
 * Path Param : id = 5  →  /posts/5
 *
 * Steps covered:
 * Step 1 - Maven project with TestNG & REST Assured dependencies (pom.xml)
 * Step 2 - Java class created in REST Assured framework (this file)
 * Step 3 - GET request to https://jsonplaceholder.typicode.com/posts
 * Step 4 - Path parameter: id = 5  (resolved URL: /posts/5)
 * Step 5 - Print all values of the response in the console
 *
 * KEY DIFFERENCE — Path Param vs Query Param:
 *   Query Param : /posts?id=5    (appended after ? in URL)
 *   Path  Param : /posts/5       (embedded inside the URL path)
 *
 * Expected Response for /posts/5:
 * {
 *   "userId" : 1,
 *   "id"     : 5,
 *   "title"  : "nesciunt quas odio",
 *   "body"   : "repudiandae veniam quaerat..."
 * }
 */
public class GetResponseWithPathParameter {

    // ----------------------------------------------------------------
    // Constants
    // ----------------------------------------------------------------
    private static final String BASE_URL        = "https://jsonplaceholder.typicode.com";
    private static final String ENDPOINT        = "/posts/{id}";   // path param placeholder
    private static final String PATH_PARAM_NAME = "id";
    private static final int    PATH_PARAM_VAL  = 5;

    // ----------------------------------------------------------------
    // Step 2 : Setup — configure base URI before tests run
    // ----------------------------------------------------------------
    @BeforeClass
    public void setUp() {
        RestAssured.baseURI = BASE_URL;
        System.out.println("================================================================");
        System.out.println("  REST Assured Framework - Get API Response with Path Parameter ");
        System.out.println("================================================================");
        System.out.println("Base URI    : " + BASE_URL);
        System.out.println("Endpoint    : " + ENDPOINT);
        System.out.println("Path Param  : " + PATH_PARAM_NAME + " = " + PATH_PARAM_VAL);
        System.out.println("Resolved URL: " + BASE_URL + "/posts/" + PATH_PARAM_VAL);
        System.out.println();
        System.out.println("NOTE: Path param embeds the value INTO the URL → /posts/5");
        System.out.println("      Query param would append after ?           → /posts?id=5");
    }

    // ================================================================
    // Step 3, 4, 5 — .pathParam() method (primary recommended approach)
    // ================================================================

    /**
     * TEST 1 : Pass path param using .pathParam() and print all field values
     *
     * Step 3 - GET /posts/{id}
     * Step 4 - .pathParam("id", 5)  →  resolves to /posts/5
     * Step 5 - Print all JSON fields: userId, id, title, body
     */
    @Test(priority = 1, description = "GET /posts/5 using .pathParam() and print all field values")
    public void getResponseWithPathParam_AndPrintValues() {

        System.out.println("\n[TEST 1] .pathParam(\"id\", 5) - Print All Field Values");
        System.out.println("--------------------------------------------------------");

        // Step 3: GET /posts/{id}
        // Step 4: .pathParam("id", 5)  → URL resolved to /posts/5
        Response response =
            given()
                .pathParam(PATH_PARAM_NAME, PATH_PARAM_VAL)   // Step 4: id=5 in path
                .header("Accept", "application/json")
                .log().all()                                   // Log shows resolved URL
            .when()
                .get(ENDPOINT)                                 // Step 3: GET /posts/{id}
            .then()
                .log().all()                                   // Log full response
                .statusCode(200)
                .extract()
                .response();

        // Step 5: Parse and print all field values
        JsonPath jp = response.jsonPath();

        int    userId = jp.getInt("userId");
        int    id     = jp.getInt("id");
        String title  = jp.getString("title");
        String body   = jp.getString("body");

        System.out.println("\n--- Path Parameter Response Values ---");
        System.out.println("+------------+-----------------------------------------------+");
        System.out.printf("| %-10s | %-45s |%n", "Field",  "Value");
        System.out.println("+------------+-----------------------------------------------+");
        System.out.printf("| %-10s | %-45s |%n", "userId", userId);
        System.out.printf("| %-10s | %-45s |%n", "id",     id);
        System.out.printf("| %-10s | %-45s |%n", "title",  title);
        System.out.printf("| %-10s | %-45s |%n", "body",   body.length() > 45
                                                            ? body.substring(0, 42) + "..." : body);
        System.out.println("+------------+-----------------------------------------------+");

        System.out.println("\n--- Full Body Value ---");
        System.out.println("userId : " + userId);
        System.out.println("id     : " + id);
        System.out.println("title  : " + title);
        System.out.println("body   : " + body);

        // Assertions
        Assert.assertEquals(id, PATH_PARAM_VAL, "id in response should match path param value 5");
        Assert.assertNotNull(title, "title should not be null");
        Assert.assertNotNull(body,  "body should not be null");

        System.out.println("\n[TEST 1] PASSED - Path param resolved to /posts/5 and all values printed");
    }

    // ================================================================
    // Step 3, 4, 5 — Inline path value directly in URL
    // ================================================================

    /**
     * TEST 2 : Pass path param value directly in the URL string
     *
     * Step 3 & 4 - GET /posts/5  (value embedded directly in URL)
     * Step 5     - Print raw pretty JSON response body
     */
    @Test(priority = 2, description = "GET /posts/5 with id hardcoded in URL and print raw JSON")
    public void getResponseWithPathParam_InlineURL() {

        System.out.println("\n[TEST 2] Path Param Inline in URL (/posts/5) - Print Raw JSON");
        System.out.println("--------------------------------------------------------------");

        // Step 3 & 4: id=5 embedded directly in the URL path
        Response response =
            given()
                .log().uri()
            .when()
                .get("/posts/" + PATH_PARAM_VAL)               // Step 3 & 4 combined
            .then()
                .statusCode(200)
                .extract()
                .response();

        // Step 5: Print raw pretty JSON
        System.out.println("\n--- Raw JSON Response Body (id=5) ---");
        System.out.println(response.getBody().asPrettyString());

        int returnedId = response.jsonPath().getInt("id");
        System.out.println("Returned id : " + returnedId + "  (matches path param = " + PATH_PARAM_VAL + ")");

        Assert.assertEquals(returnedId, PATH_PARAM_VAL, "id should be 5");

        System.out.println("\n[TEST 2] PASSED - Inline URL path param printed successfully");
    }

    // ================================================================
    // Step 3, 4, 5 — Named placeholder {id} with explicit variable
    // ================================================================

    /**
     * TEST 3 : Named placeholder syntax {id} with variable substitution
     *
     * Step 3 - GET /posts/{id}
     * Step 4 - .pathParam("id", 5) using named placeholder
     * Step 5 - Print each field with its type label
     */
    @Test(priority = 3, description = "Named placeholder {id}=5, print each field with type label")
    public void getResponseWithNamedPlaceholder_PrintFieldTypes() {

        System.out.println("\n[TEST 3] Named Placeholder {id}=5 - Print Fields with Type Labels");
        System.out.println("-------------------------------------------------------------------");

        int postId = PATH_PARAM_VAL; // id = 5

        // Step 3 & 4: Named placeholder with pathParam
        Response response =
            given()
                .pathParam("id", postId)                       // Step 4: named placeholder
                .log().uri()
            .when()
                .get("/posts/{id}")                            // Step 3: placeholder in path
            .then()
                .statusCode(200)
                .extract()
                .response();

        // Step 5: Print field values with type labels
        JsonPath jp = response.jsonPath();

        System.out.println("\n--- Response Fields for /posts/" + postId + " ---");
        System.out.printf("  %-15s %-10s : %s%n", "userId",  "[Integer]", jp.getInt("userId"));
        System.out.printf("  %-15s %-10s : %s%n", "id",      "[Integer]", jp.getInt("id"));
        System.out.printf("  %-15s %-10s : %s%n", "title",   "[String]",  jp.getString("title"));
        System.out.printf("  %-15s %-10s : %s%n", "body",    "[String]",  jp.getString("body"));

        Assert.assertEquals(jp.getInt("id"), postId, "Response id should equal path param 5");

        System.out.println("\n[TEST 3] PASSED - Named placeholder {id} resolved and field types printed");
    }

    // ================================================================
    // Step 3, 4, 5 — Jackson ObjectMapper full parse & print
    // ================================================================

    /**
     * TEST 4 : Parse full response with Jackson ObjectMapper and print entire tree
     *
     * Step 3 - GET /posts/{id}
     * Step 4 - .pathParam("id", 5)
     * Step 5 - Print every key-value pair via Jackson node traversal
     */
    @Test(priority = 4, description = "Parse /posts/5 with Jackson ObjectMapper and print full JSON tree")
    public void getResponseWithPathParam_JacksonFullPrint() throws Exception {

        System.out.println("\n[TEST 4] .pathParam() + Jackson ObjectMapper - Full JSON Tree");
        System.out.println("--------------------------------------------------------------");

        // Step 3 & 4: GET with pathParam
        String body =
            given()
                .pathParam(PATH_PARAM_NAME, PATH_PARAM_VAL)   // Step 4: id=5
                .log().uri()
            .when()
                .get(ENDPOINT)                                 // Step 3: /posts/{id}
            .then()
                .statusCode(200)
                .extract()
                .asString();

        // Step 5: Parse with Jackson and print every node
        ObjectMapper mapper   = new ObjectMapper();
        JsonNode     rootNode = mapper.readTree(body);

        System.out.println("\n--- Full JSON Tree (Jackson) for /posts/" + PATH_PARAM_VAL + " ---");
        System.out.println("{");
        rootNode.fields().forEachRemaining(field -> {
            String key   = field.getKey();
            String value = field.getValue().asText();
            System.out.printf("  %-10s : %s%n", key, value);
        });
        System.out.println("}");

        System.out.println("\n--- Summary ---");
        System.out.println("Path Param Sent : " + PATH_PARAM_NAME + " = " + PATH_PARAM_VAL);
        System.out.println("id in Response  : " + rootNode.path("id").asInt());
        System.out.println("Title           : " + rootNode.path("title").asText());

        Assert.assertEquals(rootNode.path("id").asInt(), PATH_PARAM_VAL,
            "id in response should be " + PATH_PARAM_VAL);

        System.out.println("\n[TEST 4] PASSED - Jackson full tree printed for path param id=5");
    }
}
