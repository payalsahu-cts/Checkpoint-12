# REST Assured - Validate 500 Status Code

## Scenario: Validate the 500 Status Code in REST Assured

| Step | Description |
|------|-------------|
| 1 | Maven project with TestNG & REST Assured dependencies |
| 2 | Java class created in REST Assured framework |
| 3 | GET request sent to `https://the-internet.herokuapp.com/status_codes/500` |
| 4 | Verify the status code is `500` |

---

## Project Structure

```
statuscode500-project/
├── pom.xml                          ← Maven dependencies (TestNG + REST Assured)
├── testng.xml                       ← TestNG suite configuration
├── README.md
└── src/
    └── test/
        └── java/
            └── com/api/tests/
                └── ValidateStatusCode500.java   ← Main test class
```

---

## Prerequisites

- Java 11 or higher
- Maven 3.6+

---

## How to Run

```bash
mvn clean test
```

Or in IDE: Right-click `testng.xml` → **Run**

---

## Test Cases

| Test Method | Description | Expected |
|-------------|-------------|----------|
| `validateStatusCode500_FluentChain` | Fluent REST Assured `.statusCode(500)` | Status 500 |
| `validateStatusCode500_ExplicitAssertion` | TestNG `Assert.assertEquals` on response | Status 500 |
| `validateStatusLine_500InternalServerError` | Full HTTP status line check | Contains "500" |
| `validateResponseTime_500` | Status 500 + response within 5000ms | Status 500 & time < 5s |

---

## API Details

- **URL:** `https://the-internet.herokuapp.com/status_codes/500`
- **Method:** GET
- **Auth:** None required
- **Expected Status Code:** `500 Internal Server Error`

---

## HTTP Status Code Reference

| Code | Category | Description |
|------|----------|-------------|
| 200  | 2xx Success | Request succeeded |
| 301  | 3xx Redirection | Resource permanently moved (needs redirect config in REST Assured) |
| 404  | 4xx Client Error | Resource not found |
| 500  | 5xx Server Error | Internal server error |
