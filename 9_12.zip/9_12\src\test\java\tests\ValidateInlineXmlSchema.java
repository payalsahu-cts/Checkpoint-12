package tests;

import io.restassured.response.Response;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static io.restassured.matcher.RestAssuredMatchers.matchesXsd;

public class ValidateInlineXmlSchema {

    // Step 3: XSD schema defined inline — matches the GET /booking/{id} XML response structure
    private static final String XSD_SCHEMA =
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
        "<xs:schema xmlns:xs=\"http://www.w3.org/2001/XMLSchema\">" +
            "<xs:element name=\"booking\">" +
                "<xs:complexType>" +
                    "<xs:sequence>" +
                        "<xs:element name=\"firstname\"      type=\"xs:string\"/>" +
                        "<xs:element name=\"lastname\"       type=\"xs:string\"/>" +
                        "<xs:element name=\"totalprice\"     type=\"xs:integer\"/>" +
                        "<xs:element name=\"depositpaid\"    type=\"xs:boolean\"/>" +
                        "<xs:element name=\"bookingdates\">" +
                            "<xs:complexType>" +
                                "<xs:sequence>" +
                                    "<xs:element name=\"checkin\"  type=\"xs:string\"/>" +
                                    "<xs:element name=\"checkout\" type=\"xs:string\"/>" +
                                "</xs:sequence>" +
                            "</xs:complexType>" +
                        "</xs:element>" +
                        "<xs:element name=\"additionalneeds\" type=\"xs:string\" minOccurs=\"0\"/>" +
                    "</xs:sequence>" +
                "</xs:complexType>" +
            "</xs:element>" +
        "</xs:schema>";

    @Test
    public void validateInlineXsdSchema() {

        // Step 1: GET request with id = 119
        // Step 2: contentType and Accept set to application/xml
        Response response = given()
                    .baseUri("https://restful-booker.herokuapp.com")
                    .contentType("application/xml")
                    .accept("application/xml")
                .when()
                    .get("/booking/119")
                .then()
                    .assertThat()
                        .statusCode(200)
                        // Step 3: Validate response against inline XSD using matchesXsd()
                        .body(matchesXsd(XSD_SCHEMA))
                    .extract()
                    .response();

        // Step 4: Print the response in the console
        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Body         : " + response.getBody().asPrettyString());
        System.out.println("Inline XSD Validation : PASSED");
    }
}
