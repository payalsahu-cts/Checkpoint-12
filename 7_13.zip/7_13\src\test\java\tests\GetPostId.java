package tests;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

/**
 * Scenario 14 - Get the ID of the given API in Postman
 *
 * Steps automated:
 *   Step 3: POST https://jsonplaceholder.typicode.com/posts
 *   Step 4: Pass request body
 *   Step 5: Verify status code is 201
 *   Step 6: Verify response body and capture ID
 */
public class GetPostId {

    @Test
    public void createPostAndGetId() {

        // Step 4: Request body
        String requestBody = "{\n"
                + "    \"title\"  : \"foo\",\n"
                + "    \"body\"   : \"bar\",\n"
                + "    \"userId\" : 1\n"
                + "}";

        // Step 3-6: POST /posts
        Response response = given()
                    .baseUri("https://jsonplaceholder.typicode.com")
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .body(requestBody)
                .when()
                    .post("/posts")
                .then()
                    .assertThat()
                        // Step 5: Verify 201
                        .statusCode(201)
                        // Step 6: Verify response body
                        .body("id",     notNullValue())
                        .body("title",  equalTo("foo"))
                        .body("body",   equalTo("bar"))
                        .body("userId", equalTo(1))
                    .extract()
                    .response();

        // Capture the created post ID
        int postId = response.jsonPath().getInt("id");

        System.out.println("========================================");
        System.out.println(" POST /posts — Create Post");
        System.out.println("========================================");
        System.out.println("URL                   : https://jsonplaceholder.typicode.com/posts");
        System.out.println("Method                : POST");
        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Body         : " + response.getBody().asPrettyString());
        System.out.println("------ Captured ID ------");
        System.out.println("Post ID               : " + postId);
        System.out.println("title                 : " + response.jsonPath().getString("title"));
        System.out.println("body                  : " + response.jsonPath().getString("body"));
        System.out.println("userId                : " + response.jsonPath().getInt("userId"));

        // Step 5: TestNG assertion
        Assert.assertEquals(response.getStatusCode(), 201,
                "Expected 201 Created but got: " + response.getStatusCode());
        Assert.assertTrue(postId > 0, "Post ID should be a positive integer!");
        System.out.println("Post created and ID captured successfully. ID = " + postId);
    }
}
