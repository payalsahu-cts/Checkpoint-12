package com.api.tests;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static io.restassured.RestAssured.*;

/**
 * Test Class : GetResponseWithDoubleQueryParam
 *
 * Scenario   : Get the API response with double query parameters in REST Assured
 * API        : https://reqres.in/api/users
 * Method     : GET
 * Parameters : page=2  AND  id=5
 *
 * Steps covered:
 * Step 1 - Maven project with TestNG & REST Assured dependencies (pom.xml)
 * Step 2 - Java class created in REST Assured framework (this file)
 * Step 3 - GET request to https://reqres.in/api/users
 * Step 4 - Query parameters: page=2 and id=5
 * Step 5 - Print all values of the response in the console
 *
 * NOTE: reqres.in uses 'page' for pagination; 'id' is not a native filter
 *       on /api/users but is accepted and returned in the response metadata.
 *       All params are sent and logged; the full response is parsed and printed.
 *
 * Full URL : https://reqres.in/api/users?page=2&id=5
 */
public class GetResponseWithDoubleQueryParam {

    // ----------------------------------------------------------------
    // Constants
    // ----------------------------------------------------------------
    private static final String BASE_URL     = "https://reqres.in";
    private static final String ENDPOINT     = "/api/users";
    private static final String PARAM_PAGE   = "page";
    private static final int    PAGE_VALUE   = 2;
    private static final String PARAM_ID     = "id";
    private static final int    ID_VALUE     = 5;

    // ----------------------------------------------------------------
    // Step 2 : Setup — configure base URI before tests run
    // ----------------------------------------------------------------
    @BeforeClass
    public void setUp() {
        RestAssured.baseURI = BASE_URL;
        System.out.println("=================================================================");
        System.out.println("  REST Assured - Get API Response with Double Query Parameters   ");
        System.out.println("=================================================================");
        System.out.println("Base URI   : " + BASE_URL);
        System.out.println("Endpoint   : " + ENDPOINT);
        System.out.println("Param 1    : " + PARAM_PAGE + " = " + PAGE_VALUE);
        System.out.println("Param 2    : " + PARAM_ID   + " = " + ID_VALUE);
        System.out.println("Full URL   : " + BASE_URL + ENDPOINT
                           + "?" + PARAM_PAGE + "=" + PAGE_VALUE
                           + "&" + PARAM_ID   + "=" + ID_VALUE);
    }

    // ================================================================
    // Step 3, 4, 5 — Two chained .queryParam() calls (primary approach)
    // ================================================================

    /**
     * TEST 1 : Pass two params via chained .queryParam() and print all values
     *
     * Step 3 - GET /api/users
     * Step 4 - .queryParam("page", 2).queryParam("id", 5)
     * Step 5 - Print pagination fields + each user record + support block
     */
    @Test(priority = 1, description = "GET /api/users?page=2&id=5 using chained queryParam() and print all values")
    public void getResponseWithDoubleQueryParam_Chained() {

        System.out.println("\n[TEST 1] Chained queryParam(\"page\",2).queryParam(\"id\",5) - Print All Values");
        System.out.println("------------------------------------------------------------------------------");

        // Step 3: GET /api/users
        // Step 4: Two chained queryParam() calls — page=2 and id=5
        Response response =
            given()
                .queryParam(PARAM_PAGE, PAGE_VALUE)    // Step 4: first  param page=2
                .queryParam(PARAM_ID,   ID_VALUE)      // Step 4: second param id=5
                .header("Accept", "application/json")
                .log().all()                           // Log request — URL shows both params
            .when()
                .get(ENDPOINT)                         // Step 3: GET call
            .then()
                .log().all()                           // Log full response
                .statusCode(200)
                .extract()
                .response();

        // Step 5: Parse and print every value in the response
        JsonPath jp = response.jsonPath();

        // --- Pagination fields ---
        System.out.println("\n--- Pagination Values ---");
        System.out.println("page         : " + jp.getInt("page"));
        System.out.println("per_page     : " + jp.getInt("per_page"));
        System.out.println("total        : " + jp.getInt("total"));
        System.out.println("total_pages  : " + jp.getInt("total_pages"));

        // --- User data array ---
        List<Map<String, Object>> dataList = jp.getList("data");
        System.out.println("\n--- User Data (page=2 , id=5) ---");
        System.out.println("Users returned : " + dataList.size());
        System.out.println();

        for (int i = 0; i < dataList.size(); i++) {
            Map<String, Object> user = dataList.get(i);
            System.out.println("  User [" + (i + 1) + "] :");
            System.out.println("    id         : " + user.get("id"));
            System.out.println("    email      : " + user.get("email"));
            System.out.println("    first_name : " + user.get("first_name"));
            System.out.println("    last_name  : " + user.get("last_name"));
            System.out.println("    avatar     : " + user.get("avatar"));
            System.out.println();
        }

        // --- Support block ---
        System.out.println("--- Support Block ---");
        System.out.println("support.url  : " + jp.getString("support.url"));
        System.out.println("support.text : " + jp.getString("support.text"));

        // Assertions
        Assert.assertEquals(jp.getInt("page"), PAGE_VALUE, "page param should be 2");
        Assert.assertFalse(dataList.isEmpty(), "Data list should not be empty");

        System.out.println("\n[TEST 1] PASSED - Double query params sent and all values printed");
    }

    // ================================================================
    // Step 3, 4, 5 — Pass both params via Map
    // ================================================================

    /**
     * TEST 2 : Pass two params together via a Map and print raw JSON
     *
     * Step 3 - GET /api/users
     * Step 4 - .queryParams(Map { "page"->2, "id"->5 })
     * Step 5 - Print pretty raw JSON + confirm both param values
     */
    @Test(priority = 2, description = "GET /api/users?page=2&id=5 using queryParams(Map) and print raw JSON")
    public void getResponseWithDoubleQueryParam_UsingMap() {

        System.out.println("\n[TEST 2] queryParams(Map) with page=2 & id=5 - Print Raw JSON");
        System.out.println("--------------------------------------------------------------");

        // Build the two-param map — Step 4
        Map<String, Object> params = new HashMap<>();
        params.put(PARAM_PAGE, PAGE_VALUE);            // Step 4: page=2
        params.put(PARAM_ID,   ID_VALUE);              // Step 4: id=5

        // Step 3 & 4: GET with queryParams map
        Response response =
            given()
                .queryParams(params)                   // Step 4: both params via Map
                .log().uri()
            .when()
                .get(ENDPOINT)                         // Step 3: GET
            .then()
                .statusCode(200)
                .extract()
                .response();

        // Step 5: Print raw pretty JSON
        System.out.println("\n--- Raw JSON Response Body ---");
        System.out.println(response.getBody().asPrettyString());

        // Confirm both params reflected in response
        System.out.println("\n--- Parameter Verification ---");
        System.out.println("Sent     page = " + PAGE_VALUE + "  →  Returned page : " + response.jsonPath().getInt("page"));
        System.out.println("Sent     id   = " + ID_VALUE);

        Assert.assertEquals(response.jsonPath().getInt("page"), PAGE_VALUE);

        System.out.println("\n[TEST 2] PASSED - queryParams(Map) with two params printed successfully");
    }

    // ================================================================
    // Step 3, 4, 5 — Both params inline in URL string
    // ================================================================

    /**
     * TEST 3 : Pass both query params directly in the URL string
     *
     * Step 3 - GET /api/users?page=2&id=5  (both params in URL)
     * Step 4 - page=2 & id=5 embedded in URL
     * Step 5 - Print formatted table of all user fields
     */
    @Test(priority = 3, description = "GET with page=2&id=5 embedded in URL string, print formatted user table")
    public void getResponseWithDoubleParam_InURL() {

        System.out.println("\n[TEST 3] Both Params Inline in URL - Formatted User Table");
        System.out.println("-----------------------------------------------------------");

        // Step 3 & 4: Both params directly in URL string
        Response response =
            given()
                .log().uri()
            .when()
                .get(ENDPOINT + "?page=2&id=5")        // Step 3 & 4 combined
            .then()
                .statusCode(200)
                .extract()
                .response();

        // Step 5: Print formatted user table
        List<Integer> ids        = response.jsonPath().getList("data.id");
        List<String>  firstNames = response.jsonPath().getList("data.first_name");
        List<String>  lastNames  = response.jsonPath().getList("data.last_name");
        List<String>  emails     = response.jsonPath().getList("data.email");
        List<String>  avatars    = response.jsonPath().getList("data.avatar");

        System.out.println("\n--- Response with page=2 & id=5 ---");
        System.out.printf("%n  %-4s | %-10s | %-22s | %-30s | %s%n",
            "ID", "Name", "Email", "Avatar", "");
        System.out.println("  " + "-".repeat(90));

        for (int i = 0; i < ids.size(); i++) {
            System.out.printf("  %-4d | %-10s | %-22s | %s%n",
                ids.get(i),
                firstNames.get(i) + " " + lastNames.get(i),
                emails.get(i),
                avatars.get(i));
        }

        Assert.assertFalse(ids.isEmpty(), "User list should not be empty");

        System.out.println("\n[TEST 3] PASSED - Inline double params printed as formatted table");
    }

    // ================================================================
    // Step 3, 4, 5 — Jackson full tree + highlight id=5 user if found
    // ================================================================

    /**
     * TEST 4 : Parse with Jackson, print full tree, highlight user with id=5
     *
     * Step 3 - GET /api/users
     * Step 4 - .queryParam("page", 2).queryParam("id", 5)
     * Step 5 - Print every JSON value; highlight the user whose id == 5
     */
    @Test(priority = 4, description = "Jackson full tree print with page=2 & id=5, highlight user id=5")
    public void getResponseWithDoubleParam_JacksonHighlightUser() throws Exception {

        System.out.println("\n[TEST 4] Jackson Full Tree - Highlight User id=5");
        System.out.println("-------------------------------------------------");

        // Step 3 & 4: GET with both query params
        String body =
            given()
                .queryParam(PARAM_PAGE, PAGE_VALUE)    // Step 4: page=2
                .queryParam(PARAM_ID,   ID_VALUE)      // Step 4: id=5
                .log().uri()
            .when()
                .get(ENDPOINT)
            .then()
                .statusCode(200)
                .extract()
                .asString();

        // Step 5: Parse with Jackson and print full tree
        ObjectMapper mapper   = new ObjectMapper();
        JsonNode     root     = mapper.readTree(body);

        System.out.println("\n--- Full Response (Jackson) ---");
        System.out.println("page        : " + root.path("page").asInt());
        System.out.println("per_page    : " + root.path("per_page").asInt());
        System.out.println("total       : " + root.path("total").asInt());
        System.out.println("total_pages : " + root.path("total_pages").asInt());

        JsonNode dataArray = root.path("data");
        System.out.println("\ndata (" + dataArray.size() + " users) :");

        boolean userFound = false;
        for (JsonNode user : dataArray) {
            int userId = user.path("id").asInt();
            String marker = (userId == ID_VALUE) ? "  ◄── id=" + ID_VALUE + " (matched param)" : "";

            System.out.println("\n  {");
            System.out.println("    id         : " + userId + marker);
            System.out.println("    email      : " + user.path("email").asText());
            System.out.println("    first_name : " + user.path("first_name").asText());
            System.out.println("    last_name  : " + user.path("last_name").asText());
            System.out.println("    avatar     : " + user.path("avatar").asText());
            System.out.println("  }");

            if (userId == ID_VALUE) userFound = true;
        }

        // Support block
        JsonNode support = root.path("support");
        System.out.println("\nsupport :");
        System.out.println("  url  : " + support.path("url").asText());
        System.out.println("  text : " + support.path("text").asText());

        System.out.println("\n--- Query Params Summary ---");
        System.out.println("page = " + PAGE_VALUE + "  →  page in response : " + root.path("page").asInt());
        System.out.println("id   = " + ID_VALUE   + "  →  User id=" + ID_VALUE + " found in data : " + userFound);

        Assert.assertEquals(root.path("page").asInt(), PAGE_VALUE, "page should be 2");

        System.out.println("\n[TEST 4] PASSED - Full JSON tree printed with both query params");
    }
}
