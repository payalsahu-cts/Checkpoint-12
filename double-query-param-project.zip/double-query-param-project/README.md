# REST Assured - Get API Response with Double Query Parameters

## Scenario: Get API Response with Double Query Parameters

| Step | Description |
|------|-------------|
| 1 | Maven project with TestNG & REST Assured dependencies |
| 2 | Java class created in REST Assured framework |
| 3 | GET request to `https://reqres.in/api/users` |
| 4 | Query parameters: `page=2` **and** `id=5` |
| 5 | Print all values of the response in the console |

---

## Project Structure

```
double-query-param-project/
├── pom.xml                                      ← Maven dependencies
├── testng.xml                                   ← TestNG suite configuration
├── README.md
└── src/
    └── test/
        └── java/
            └── com/api/tests/
                └── GetResponseWithDoubleQueryParam.java  ← Main test class
```

---

## API Details

- **URL:** `https://reqres.in/api/users?page=2&id=5`
- **Method:** GET
- **Param 1:** `page=2`
- **Param 2:** `id=5`

### Expected Response
```json
{
    "page": 2,
    "per_page": 6,
    "total": 12,
    "total_pages": 2,
    "data": [
        { "id": 7, "email": "michael.lawson@reqres.in", "first_name": "Michael", "last_name": "Lawson", "avatar": "..." },
        { "id": 8, "email": "lindsay.ferguson@reqres.in", "first_name": "Lindsay", "last_name": "Ferguson", "avatar": "..." }
    ],
    "support": { "url": "...", "text": "..." }
}
```

---

## Three Ways to Pass Multiple Query Parameters (all demonstrated)

| Method | Code | Notes |
|--------|------|-------|
| Chained `.queryParam()` | `.queryParam("page", 2).queryParam("id", 5)` | Most readable — recommended |
| `.queryParams(Map)` | `.queryParams(Map.of("page", 2, "id", 5))` | Best for dynamic params |
| Inline URL | `.get("/api/users?page=2&id=5")` | Quick one-liners |

---

## Test Cases

| Test Method | Param Style | Step 5 Output |
|-------------|-------------|---------------|
| `getResponseWithDoubleQueryParam_Chained` | Chained `.queryParam()` | Pagination + all user fields + support block |
| `getResponseWithDoubleQueryParam_UsingMap` | `.queryParams(Map)` | Raw pretty JSON + param verification |
| `getResponseWithDoubleParam_InURL` | Inline in URL | Formatted ID / Name / Email / Avatar table |
| `getResponseWithDoubleParam_JacksonHighlightUser` | Chained + Jackson | Full tree + highlights user where id=5 |

---

## How to Run

```bash
mvn clean test
```

Or in IDE: Right-click `testng.xml` → **Run**

---

## Sample Console Output (TEST 1)

```
--- Pagination Values ---
page         : 2
per_page     : 6
total        : 12
total_pages  : 2

--- User Data (page=2 , id=5) ---
Users returned : 6

  User [1] :
    id         : 7
    email      : michael.lawson@reqres.in
    first_name : Michael
    last_name  : Lawson
    avatar     : https://reqres.in/img/faces/7-image.jpg
```
