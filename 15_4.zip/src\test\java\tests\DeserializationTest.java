package tests;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import pojo.Booking;
import pojo.BookingDates;
import pojo.BookingResponse;

public class DeserializationTest {

    public static void main(String[] args) throws JsonProcessingException {

        // Step 1: Build the request POJOs (serialization — creating the request body)
        BookingDates bookingDates = new BookingDates();
        bookingDates.setCheckin("2018-01-01");
        bookingDates.setCheckout("2019-01-01");

        Booking booking = new Booking();
        booking.setFirstname("Jim");
        booking.setLastname("Brown");
        booking.setTotalprice(111);
        booking.setDepositpaid(true);
        booking.setBookingdates(bookingDates);
        booking.setAdditionalneeds("Breakfast");

        // Step 2: Serialize the request POJO to a JSON string using ObjectMapper
        ObjectMapper objectMapper = new ObjectMapper();
        String requestBody = objectMapper.writeValueAsString(booking);

        System.out.println("Serialized Request Body:");
        System.out.println(requestBody);
        System.out.println();

        // Step 3: Send POST request to the booking API and capture response as String
        Response response = RestAssured
                .given()
                    .baseUri("https://restful-booker.herokuapp.com")
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .body(requestBody)
                    .log().all()
                .when()
                    .post("/booking")
                .then()
                    .log().all()
                    .statusCode(200)
                    .extract()
                    .response();

        String responseBody = response.getBody().asString();

        System.out.println("Raw Response Body:");
        System.out.println(responseBody);
        System.out.println();

        // Step 4: Deserialize the JSON response into BookingResponse POJO using readValue()
        BookingResponse bookingResponse = objectMapper.readValue(responseBody, BookingResponse.class);

        // Step 5: Print the deserialized POJO values to the console
        System.out.println("========= Deserialized Response Values =========");
        System.out.println("Booking ID       : " + bookingResponse.getBookingid());
        System.out.println("First Name       : " + bookingResponse.getBooking().getFirstname());
        System.out.println("Last Name        : " + bookingResponse.getBooking().getLastname());
        System.out.println("Total Price      : " + bookingResponse.getBooking().getTotalprice());
        System.out.println("Deposit Paid     : " + bookingResponse.getBooking().isDepositpaid());
        System.out.println("Check-In Date    : " + bookingResponse.getBooking().getBookingdates().getCheckin());
        System.out.println("Check-Out Date   : " + bookingResponse.getBooking().getBookingdates().getCheckout());
        System.out.println("Additional Needs : " + bookingResponse.getBooking().getAdditionalneeds());
        System.out.println("================================================");
        System.out.println();
        System.out.println("Full Deserialized Object:");
        System.out.println(bookingResponse.toString());
    }
}
