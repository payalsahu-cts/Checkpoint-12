package tests;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import org.hamcrest.Matchers;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class USPopulation2019ResponseSpecBuilderTest {

    private static final String BASE_URI = "https://datausa.io";
    private static final String ENDPOINT = "/api/data";
    private static final String YEAR     = "2019";

    private RequestSpecification  requestSpec;
    private ResponseSpecification responseSpec;
    private Response              response;

    // Step 3 & 4: Create ResponseSpecBuilder and execute @BeforeClass
    @BeforeClass
    public void setUpSpecifications() {

        // Build RequestSpecification
        requestSpec = new RequestSpecBuilder()
                .setBaseUri(BASE_URI)
                .setBasePath(ENDPOINT)
                .addQueryParam("drilldowns", "Nation")
                .addQueryParam("measures",   "Population")
                .addQueryParam("Year",       YEAR)
                .build();

        // Step 3: Build ResponseSpecification using ResponseSpecBuilder
        // Validates Status Code 200 and Content-Type as JSON
        responseSpec = new ResponseSpecBuilder()
                .expectStatusCode(200)
                .expectContentType(ContentType.JSON)
                .expectResponseTime(Matchers.lessThan(10000L))
                .expectBody("data",        Matchers.notNullValue())
                .expectBody("data.size()", Matchers.greaterThan(0))
                .build();

        System.out.println("=======================================================");
        System.out.println(" RequestSpecification created:");
        System.out.println("   Base URI   : " + BASE_URI);
        System.out.println("   Endpoint   : " + ENDPOINT);
        System.out.println("   drilldowns : Nation");
        System.out.println("   measures   : Population");
        System.out.println("   Year       : " + YEAR);
        System.out.println("-------------------------------------------------------");
        System.out.println(" ResponseSpecBuilder configured with:");
        System.out.println("   expectStatusCode    : 200");
        System.out.println("   expectContentType   : application/json");
        System.out.println("   expectResponseTime  : less than 10000ms");
        System.out.println("   expectBody(data)    : not null");
        System.out.println("   expectBody(size)    : greater than 0");
        System.out.println("=======================================================");

        // Step 5: Send GET request — ResponseSpecBuilder validates automatically
        response = RestAssured
                .given()
                    .spec(requestSpec)
                    .log().all()
                .when()
                    .get()
                .then()
                    .log().all()
                    .spec(responseSpec)
                    .extract()
                    .response();
    }

    // Scenario 3: Print United States population details for year 2019
    @Test
    public void printUSPopulationDetails2019() {

        // Step 6: Print ID Nation
        String idNation = response.jsonPath().getString("data[0].'ID Nation'");

        // Step 7: Print Nation
        String nation = response.jsonPath().getString("data[0].Nation");

        // Step 8: Print ID Year
        String idYear = response.jsonPath().getString("data[0].'ID Year'");

        // Step 9: Print Population
        String population = response.jsonPath().getString("data[0].Population");

        // Step 10: Print Slug Nation
        String slugNation = response.jsonPath().getString("data[0].'Slug Nation'");

        // Step 11: Print source_name & source_description
        String sourceName        = response.jsonPath()
                .getString("source[0].annotations.source_name");
        String sourceDescription = response.jsonPath()
                .getString("source[0].annotations.source_description");

        System.out.println("=======================================================");
        System.out.println(" United States Population Details - Year " + YEAR);
        System.out.println("=======================================================");
        System.out.println(" ID Nation          : " + idNation);
        System.out.println(" Nation             : " + nation);
        System.out.println(" ID Year            : " + idYear);
        System.out.println(" Population         : " + population);
        System.out.println(" Slug Nation        : " + slugNation);
        System.out.println("-------------------------------------------------------");
        System.out.println(" Source Name        : " + sourceName);
        System.out.println(" Source Description : " + sourceDescription);
        System.out.println("=======================================================");
    }
}
