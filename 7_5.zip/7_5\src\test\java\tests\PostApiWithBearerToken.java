package tests;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.notNullValue;

/**
 * Scenario 5 - Get the response of POST API Request
 *
 * Postman steps automated:
 *   Step 6 : Method = POST
 *   Step 7 : Get token from auth endpoint and use as Bearer token
 *   Step 8 : URL = https://restful-booker.herokuapp.com/booking
 *   Step 9 : Request body = Jim Brown booking
 *   Step 10: Click Send and verify response
 */
public class PostApiWithBearerToken {

    private static final String BASE_URI = "https://restful-booker.herokuapp.com";

    // Step 7: Token retrieved from auth endpoint — stored for use in POST
    private String authToken;

    @BeforeClass
    public void getAuthToken() {

        String authBody = "{\n"
                + "    \"username\" : \"admin\",\n"
                + "    \"password\" : \"password123\"\n"
                + "}";

        // Step 7: POST to /auth to get the bearer token
        Response authResponse = given()
                    .baseUri(BASE_URI)
                    .contentType(ContentType.JSON)
                    .body(authBody)
                .when()
                    .post("/auth")
                .then()
                    .assertThat()
                        .statusCode(200)
                        .body("token", notNullValue())
                    .extract()
                    .response();

        authToken = authResponse.jsonPath().getString("token");

        System.out.println("========================================");
        System.out.println(" Auth Token Retrieved: " + authToken);
        System.out.println("========================================");
    }

    @Test
    public void postBookingWithBearerToken() {

        // Step 9: Request body
        String requestBody = "{\n"
                + "    \"firstname\": \"Jim\",\n"
                + "    \"lastname\": \"Brown\",\n"
                + "    \"totalprice\": 111,\n"
                + "    \"depositpaid\": true,\n"
                + "    \"bookingdates\": {\n"
                + "        \"checkin\": \"2018-01-01\",\n"
                + "        \"checkout\": \"2019-01-01\"\n"
                + "    },\n"
                + "    \"additionalneeds\": \"Breakfast\"\n"
                + "}";

        // Step 6, 8, 10: POST /booking with Bearer token in Authorization header
        Response response = given()
                    .baseUri(BASE_URI)
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .header("Authorization", "Bearer " + authToken)
                    .body(requestBody)
                .when()
                    .post("/booking")
                .then()
                    .assertThat()
                        .statusCode(200)
                        .body("bookingid",            notNullValue())
                        .body("bookingid",            greaterThan(0))
                        .body("booking.firstname",    equalTo("Jim"))
                        .body("booking.lastname",     equalTo("Brown"))
                        .body("booking.totalprice",   equalTo(111))
                        .body("booking.depositpaid",  equalTo(true))
                    .extract()
                    .response();

        System.out.println("========================================");
        System.out.println(" POST /booking with Bearer Token");
        System.out.println("========================================");
        System.out.println("URL                   : " + BASE_URI + "/booking");
        System.out.println("Method                : POST");
        System.out.println("Authorization         : Bearer " + authToken);
        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Body         : " + response.getBody().asPrettyString());
        System.out.println("Created Booking ID    : " + response.jsonPath().getInt("bookingid"));

        Assert.assertEquals(response.getStatusCode(), 200,
                "Expected status 200 but got: " + response.getStatusCode());
        Assert.assertNotNull(response.jsonPath().getString("bookingid"),
                "Booking ID should not be null!");
        System.out.println("POST request with Bearer Token verified successfully.");
    }
}
