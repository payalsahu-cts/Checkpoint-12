package tests;

import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.greaterThan;

public class PrintUniversitiesCount {

    @Test
    public void printNumberOfUniversitiesInUnitedStates() {

        // Step 3: GET request to universities API — search by country
        Response response = given()
                    .baseUri("http://universities.hipolabs.com")
                    .queryParam("country", "United States")
                    .accept("application/json")
                .when()
                    .get("/search")
                .then()
                    .assertThat()
                        .statusCode(200)
                        .body("$", org.hamcrest.Matchers.hasSize(greaterThan(0)))
                    .extract()
                    .response();

        // Step 4: Print number of universities in United States
        List<Map<String, Object>> universities = response.jsonPath().getList("$");
        int totalCount = universities.size();

        System.out.println("Response Status Code                    : " + response.getStatusCode());
        System.out.println("========================================");
        System.out.println(" Number of Universities in United States: " + totalCount);
        System.out.println("========================================");

        // Print each university name
        System.out.println("\n------ University Names ------");
        for (int i = 0; i < universities.size(); i++) {
            String name    = (String) universities.get(i).get("name");
            String state   = (String) universities.get(i).get("state-province");
            String website = universities.get(i).get("web_pages") != null
                    ? ((List<?>) universities.get(i).get("web_pages")).get(0).toString()
                    : "N/A";
            System.out.println((i + 1) + ". " + name
                    + " | State: " + state
                    + " | Website: " + website);
        }

        // TestNG assertion — confirm at least 1 university was returned
        Assert.assertTrue(totalCount > 0,
            "Expected at least 1 university but got: " + totalCount);

        System.out.println("\nTotal Universities Found : " + totalCount);
    }
}
