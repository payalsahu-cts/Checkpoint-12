package tests;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

/**
 * Scenario 7 - Get the response of PUT API Request
 *
 * Step 6: Method      = PUT
 * Step 7: Auth        = Basic Auth (admin / password123)
 * Step 8: URL         = https://restful-booker.herokuapp.com/booking/:id
 * Step 9: Request body from input file
 * Step 10: Send and verify
 */
public class PutApiWithBasicAuth {

    private static final String BASE_URI = "https://restful-booker.herokuapp.com";
    private static final String USERNAME = "admin";
    private static final String PASSWORD = "password123";

    private int bookingId;

    @BeforeClass
    public void createBookingToUpdate() {

        // Create a booking first so we have an ID to PUT
        String createBody = "{\n"
                + "    \"firstname\": \"Jim\",\n"
                + "    \"lastname\": \"Brown\",\n"
                + "    \"totalprice\": 111,\n"
                + "    \"depositpaid\": true,\n"
                + "    \"bookingdates\": {\n"
                + "        \"checkin\": \"2018-01-01\",\n"
                + "        \"checkout\": \"2019-01-01\"\n"
                + "    },\n"
                + "    \"additionalneeds\": \"Breakfast\"\n"
                + "}";

        Response createResponse = given()
                    .baseUri(BASE_URI)
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .body(createBody)
                .when()
                    .post("/booking")
                .then()
                    .assertThat().statusCode(200)
                    .extract().response();

        bookingId = createResponse.jsonPath().getInt("bookingid");
        System.out.println("Booking created with ID: " + bookingId);
    }

    @Test
    public void putBookingWithBasicAuth() {

        // Step 9: Updated request body
        String updateBody = "{\n"
                + "    \"firstname\": \"James\",\n"
                + "    \"lastname\": \"Brown\",\n"
                + "    \"totalprice\": 222,\n"
                + "    \"depositpaid\": true,\n"
                + "    \"bookingdates\": {\n"
                + "        \"checkin\": \"2020-01-01\",\n"
                + "        \"checkout\": \"2021-01-01\"\n"
                + "    },\n"
                + "    \"additionalneeds\": \"Lunch\"\n"
                + "}";

        // Step 6-10: PUT /booking/:id with Basic Auth
        Response response = given()
                    .baseUri(BASE_URI)
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .auth().basic(USERNAME, PASSWORD)
                    .body(updateBody)
                .when()
                    .put("/booking/" + bookingId)
                .then()
                    .assertThat()
                        .statusCode(200)
                        .body("firstname",    equalTo("James"))
                        .body("lastname",     equalTo("Brown"))
                        .body("totalprice",   equalTo(222))
                        .body("depositpaid",  equalTo(true))
                        .body("additionalneeds", equalTo("Lunch"))
                    .extract()
                    .response();

        System.out.println("========================================");
        System.out.println(" PUT /booking/" + bookingId + " with Basic Auth");
        System.out.println("========================================");
        System.out.println("URL                   : " + BASE_URI + "/booking/" + bookingId);
        System.out.println("Method                : PUT");
        System.out.println("Auth                  : Basic Auth (" + USERNAME + " / " + PASSWORD + ")");
        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Body         : " + response.getBody().asPrettyString());

        Assert.assertEquals(response.getStatusCode(), 200);
        Assert.assertEquals(response.jsonPath().getString("firstname"), "James");
        System.out.println("PUT request verified successfully.");
    }
}
