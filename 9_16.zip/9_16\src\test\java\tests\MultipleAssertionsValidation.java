package tests;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.hasKey;
import static org.hamcrest.Matchers.notNullValue;

public class MultipleAssertionsValidation {

    @Test
    public void performMultipleAssertionsOnResponse() {

        String requestBody = "{\n"
                + "    \"firstname\": \"Jim\",\n"
                + "    \"lastname\": \"Brown\",\n"
                + "    \"totalprice\": 111,\n"
                + "    \"depositpaid\": true,\n"
                + "    \"bookingdates\": {\n"
                + "        \"checkin\": \"2018-01-01\",\n"
                + "        \"checkout\": \"2019-01-01\"\n"
                + "    },\n"
                + "    \"additionalneeds\": \"Breakfast\"\n"
                + "}";

        // Step 1: POST request
        // Step 2: Perform multiple assertions — status, headers, body fields
        Response response = given()
                    .baseUri("https://restful-booker.herokuapp.com")
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .body(requestBody)
                .when()
                    .post("/booking")
                .then()
                    .assertThat()
                        // --- Status assertions ---
                        .statusCode(200)
                        .statusLine(containsString("OK"))

                        // --- Header assertions ---
                        .header("Content-Type", containsString("application/json"))
                        .header("Server",       notNullValue())

                        // --- Body: top-level key existence ---
                        .body("$",       hasKey("bookingid"))
                        .body("$",       hasKey("booking"))

                        // --- Body: field equality ---
                        .body("booking.firstname",             equalTo("Jim"))
                        .body("booking.lastname",              equalTo("Brown"))
                        .body("booking.totalprice",            equalTo(111))
                        .body("booking.depositpaid",           equalTo(true))
                        .body("booking.bookingdates.checkin",  equalTo("2018-01-01"))
                        .body("booking.bookingdates.checkout", equalTo("2019-01-01"))
                        .body("booking.additionalneeds",       equalTo("Breakfast"))

                        // --- Body: numeric range assertion ---
                        .body("bookingid", greaterThan(0))

                        // --- Body: not null assertions ---
                        .body("bookingid",           notNullValue())
                        .body("booking.bookingdates",notNullValue())
                    .extract()
                    .response();

        // Step 3: Print the response in the console
        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Status Line  : " + response.getStatusLine());
        System.out.println("Response Body         : " + response.getBody().asPrettyString());
        System.out.println("Content-Type Header   : " + response.header("Content-Type"));
        System.out.println("All Multiple Assertions PASSED");
    }
}
