# REST Assured - Validate 404 Status Code

## Scenario: Validate the 404 Status Code in REST Assured

| Step | Description |
|------|-------------|
| 1 | Maven project with TestNG & REST Assured dependencies |
| 2 | Java class created in REST Assured framework |
| 3 | GET request sent to `https://the-internet.herokuapp.com/status_codes/404` |
| 4 | Verify the status code is `404` |

---

## Project Structure

```
statuscode404-project/
├── pom.xml                          ← Maven dependencies (TestNG + REST Assured)
├── testng.xml                       ← TestNG suite configuration
├── README.md
└── src/
    └── test/
        └── java/
            └── com/api/tests/
                └── ValidateStatusCode404.java   ← Main test class
```

---

## Prerequisites

- Java 11 or higher
- Maven 3.6+

---

## How to Run

```bash
mvn clean test
```

Or in IDE: Right-click `testng.xml` → **Run**

---

## Test Cases

| Test Method | Description | Expected |
|-------------|-------------|----------|
| `validateStatusCode404_FluentChain` | Fluent REST Assured `.statusCode(404)` | Status 404 |
| `validateStatusCode404_ExplicitAssertion` | TestNG `Assert.assertEquals` on response | Status 404 |
| `validateStatusLine_404NotFound` | Full HTTP status line check | Contains "404" |
| `validateResponseTime_404` | Status 404 + response within 5000ms | Status 404 & time < 5s |

---

## API Details

- **URL:** `https://the-internet.herokuapp.com/status_codes/404`
- **Method:** GET
- **Auth:** None required
- **Expected Status Code:** `404 Not Found`

---

## Key Difference from 301 Tests

Unlike 301 (redirect), **no redirect config is needed** for 404.
REST Assured only auto-follows 3xx redirects — 4xx responses are returned as-is.
