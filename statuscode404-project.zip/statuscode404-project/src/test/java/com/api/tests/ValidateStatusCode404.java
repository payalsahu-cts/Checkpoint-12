package com.api.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;

/**
 * Test Class : ValidateStatusCode404
 *
 * Scenario   : Validate the 404 status code in REST Assured
 * API        : https://the-internet.herokuapp.com/status_codes/404
 * Method     : GET
 *
 * Steps covered:
 * Step 1 - Maven project with TestNG & REST Assured dependencies (pom.xml)
 * Step 2 - Java class created in REST Assured framework (this file)
 * Step 3 - GET request sent to https://the-internet.herokuapp.com/status_codes/404
 * Step 4 - Verify the status code is 404
 *
 * NOTE: REST Assured does NOT follow redirects for 4xx responses,
 *       so no redirect config is needed — the 404 is captured directly.
 */
public class ValidateStatusCode404 {

    // ----------------------------------------------------------------
    // Constants
    // ----------------------------------------------------------------
    private static final String BASE_URL = "https://the-internet.herokuapp.com";
    private static final String ENDPOINT = "/status_codes/404";

    // ----------------------------------------------------------------
    // Step 2 : Setup — configure base URI before tests run
    // ----------------------------------------------------------------
    @BeforeClass
    public void setUp() {
        RestAssured.baseURI = BASE_URL;
        System.out.println("=======================================================");
        System.out.println("  REST Assured Framework - Status Code 404 Validation  ");
        System.out.println("=======================================================");
        System.out.println("Base URI : " + BASE_URL);
        System.out.println("Endpoint : " + ENDPOINT);
    }

    // ================================================================
    // Step 3 & 4 — Fluent chain: GET request + assert 404
    // ================================================================

    /**
     * TEST 1 : Fluent chain approach
     * Sends GET request and asserts status code 404 inline.
     */
    @Test(priority = 1, description = "Validate 404 status code using fluent REST Assured chain")
    public void validateStatusCode404_FluentChain() {

        System.out.println("\n[TEST 1] Fluent Chain - Validate Status Code 404");

        // Step 3: GET request to the API
        // Step 4: Verify status code is 404
        given()
            .log().all()                    // Log full request details
        .when()
            .get(ENDPOINT)                  // Step 3: GET call
        .then()
            .log().all()                    // Log full response details
            .statusCode(404);               // Step 4: Assert status code = 404

        System.out.println("[TEST 1] PASSED - Status Code is 404");
    }

    // ================================================================
    // Step 3 & 4 — Explicit assertion using Response object
    // ================================================================

    /**
     * TEST 2 : Explicit assertion using Response object + TestNG Assert
     */
    @Test(priority = 2, description = "Validate 404 status code using explicit TestNG assertion")
    public void validateStatusCode404_ExplicitAssertion() {

        System.out.println("\n[TEST 2] Explicit Assertion - Validate Status Code 404");

        // Step 3: Send GET request and capture response
        Response response =
            given()
                .log().uri()
            .when()
                .get(ENDPOINT)
            .then()
                .extract()
                .response();

        // Step 4: Verify the status code is 404
        int actualStatusCode = response.getStatusCode();
        System.out.println("Actual Status Code   : " + actualStatusCode);
        System.out.println("Expected Status Code : 404");

        Assert.assertEquals(actualStatusCode, 404,
            "Status code mismatch! Expected 404 but got: " + actualStatusCode);

        System.out.println("[TEST 2] PASSED - Status Code verified as 404");
    }

    // ================================================================
    // Step 3 & 4 — Status line verification
    // ================================================================

    /**
     * TEST 3 : Verify full HTTP status line contains "404"
     */
    @Test(priority = 3, description = "Validate full HTTP status line contains '404 Not Found'")
    public void validateStatusLine_404NotFound() {

        System.out.println("\n[TEST 3] Status Line Verification - 404 Not Found");

        // Step 3: GET request
        Response response =
            given()
                .log().uri()
            .when()
                .get(ENDPOINT)
            .then()
                .extract()
                .response();

        // Step 4: Verify status line contains "404"
        String statusLine = response.getStatusLine();
        System.out.println("Status Line : " + statusLine);

        Assert.assertTrue(statusLine.contains("404"),
            "Expected status line to contain '404' but got: " + statusLine);

        System.out.println("[TEST 3] PASSED - Status Line contains 404");
    }

    // ================================================================
    // Bonus — Verify response time is within acceptable range
    // ================================================================

    /**
     * TEST 4 : Verify the 404 response is received within 5 seconds
     */
    @Test(priority = 4, description = "Validate 404 response is received within 5000ms")
    public void validateResponseTime_404() {

        System.out.println("\n[TEST 4] Response Time Verification for 404");

        // Step 3: GET request
        Response response =
            given()
                .log().uri()
            .when()
                .get(ENDPOINT)
            .then()
                .extract()
                .response();

        // Step 4: Verify status code + response time
        int actualStatusCode = response.getStatusCode();
        long responseTime = response.getTime();

        System.out.println("Status Code    : " + actualStatusCode);
        System.out.println("Response Time  : " + responseTime + " ms");

        Assert.assertEquals(actualStatusCode, 404,
            "Expected 404 but got: " + actualStatusCode);
        Assert.assertTrue(responseTime < 5000,
            "Response time exceeded 5000ms: " + responseTime + "ms");

        System.out.println("[TEST 4] PASSED - Status 404 received within " + responseTime + "ms");
    }
}
