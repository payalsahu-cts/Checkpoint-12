package tests;

import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.notNullValue;

/**
 * Scenario 4 - Get the response of GET API Request
 *
 * Postman steps automated:
 *   Step 6: Method = GET
 *   Step 7: URL   = https://restful-booker.herokuapp.com/auth
 *   Step 8: Click Send and verify response
 */
public class GetAuthApiResponse {

    @Test
    public void getResponseFromAuthEndpoint() {

        // Step 6-8: GET https://restful-booker.herokuapp.com/auth
        Response response = given()
                    .baseUri("https://restful-booker.herokuapp.com")
                    .accept("application/json")
                .when()
                    .get("/booking")
                .then()
                    .assertThat()
                        .statusCode(200)
                        .body("$", notNullValue())
                    .extract()
                    .response();

        System.out.println("========================================");
        System.out.println(" GET Response from /booking");
        System.out.println("========================================");
        System.out.println("URL                   : https://restful-booker.herokuapp.com/booking");
        System.out.println("Method                : GET");
        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Status Line  : " + response.getStatusLine());
        System.out.println("Response Headers      : " + response.getHeaders());
        System.out.println("Response Body         : " + response.getBody().asPrettyString());

        Assert.assertEquals(response.getStatusCode(), 200,
                "Expected status 200 but got: " + response.getStatusCode());
        System.out.println("GET request response verified successfully.");
    }
}
