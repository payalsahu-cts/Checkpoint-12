package tests;

import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;

public class ValidateMatchingSchema {

    @Test
    public void ensureDataTypesMatchSchema() {

        // Step 4: GET request to jsonplaceholder
        Response response = given()
                    .baseUri("https://jsonplaceholder.typicode.com")
                    .accept("application/json")
                .when()
                    .get("/posts/2")
                .then()
                    .assertThat()
                        .statusCode(200)
                    .extract()
                    .response();

        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Body         : " + response.getBody().asPrettyString());

        // Step 5: Ensure data types MATCH the schema using TestNG assertion
        boolean schemaMatched = true;
        try {
            given()
                .baseUri("https://jsonplaceholder.typicode.com")
                .accept("application/json")
            .when()
                .get("/posts/2")
            .then()
                .assertThat()
                    .body(matchesJsonSchemaInClasspath("postsSchema.json"));
        } catch (AssertionError e) {
            schemaMatched = false;
            System.out.println("Schema validation error : " + e.getMessage());
        }

        // TestNG assertion — types SHOULD match
        Assert.assertTrue(schemaMatched,
            "FAILED: Response data types do NOT match the schema!");

        System.out.println("------ Schema Data Type Validation ------");
        System.out.println("Schema File           : postsSchema.json");
        System.out.println("userId  expected type : integer  | actual: "
                + response.jsonPath().get("userId").getClass().getSimpleName());
        System.out.println("id      expected type : integer  | actual: "
                + response.jsonPath().get("id").getClass().getSimpleName());
        System.out.println("title   expected type : string   | actual: "
                + response.jsonPath().get("title").getClass().getSimpleName());
        System.out.println("body    expected type : string   | actual: "
                + response.jsonPath().get("body").getClass().getSimpleName());
        System.out.println("Data Types Match Schema : " + schemaMatched);
    }
}
