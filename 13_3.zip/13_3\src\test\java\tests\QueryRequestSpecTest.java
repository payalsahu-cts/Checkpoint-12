package tests;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.filter.log.LogDetail;
import io.restassured.http.Header;
import io.restassured.internal.SpecificationMerger;
import io.restassured.specification.QueryableRequestSpecification;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.SpecificationQuerier;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class QueryRequestSpecTest {

    private static final String BASE_URI  = "https://datausa.io";
    private static final String BASE_PATH = "/api/data";

    private RequestSpecification requestSpec;

    // Step 3: Create RequestSpecification @BeforeClass
    @BeforeClass
    public void setUpRequestSpecification() {

        requestSpec = new RequestSpecBuilder()
                .setBaseUri(BASE_URI)
                .setBasePath(BASE_PATH)
                .addQueryParam("drilldowns", "Nation")
                .addQueryParam("measures",   "Population")
                .addQueryParam("Year",       "2021")
                .addHeader("Content-Type",   "application/json")
                .addHeader("Accept",         "application/json")
                .log(LogDetail.ALL)
                .build();

        System.out.println("=======================================================");
        System.out.println(" RequestSpecification created successfully.");
        System.out.println("=======================================================");
    }

    // Scenario 3: Print queried RequestSpecification using Query() method
    @Test
    public void printQueriedRequestSpecification() {

        // Use SpecificationQuerier.query() to inspect the RequestSpecification
        QueryableRequestSpecification queryable = SpecificationQuerier.query(requestSpec);

        // Step 4: Query and print Base URI
        String baseUri = queryable.getBaseUri();

        // Step 5: Query and print Base Path
        String basePath = queryable.getBasePath();

        // Step 6: Query and print Query Parameters
        Map<String, String> queryParams = queryable.getQueryParams();

        // Step 7: Query and print Headers
        io.restassured.http.Headers headers = queryable.getHeaders();

        System.out.println("=======================================================");
        System.out.println(" Queried RequestSpecification Details");
        System.out.println("=======================================================");

        // Step 4: Print Base URI
        System.out.println(" Base URI              : " + baseUri);

        // Step 5: Print Base Path
        System.out.println(" Base Path             : " + basePath);

        // Step 6: Print Query Parameters
        System.out.println("-------------------------------------------------------");
        System.out.println(" Query Parameters      :");
        if (queryParams != null && !queryParams.isEmpty()) {
            for (Map.Entry<String, String> param : queryParams.entrySet()) {
                System.out.println("   " + param.getKey() + " = " + param.getValue());
            }
        } else {
            System.out.println("   No query parameters found.");
        }

        // Step 7: Print Headers
        System.out.println("-------------------------------------------------------");
        System.out.println(" Headers               :");
        if (headers != null) {
            for (Header header : headers) {
                System.out.println("   " + header.getName() + " : " + header.getValue());
            }
        } else {
            System.out.println("   No headers found.");
        }

        System.out.println("=======================================================");
        System.out.println(" Full Request URL      : " + baseUri + basePath
                + "?drilldowns=" + queryParams.get("drilldowns")
                + "&measures="   + queryParams.get("measures")
                + "&Year="       + queryParams.get("Year"));
        System.out.println("=======================================================");
    }
}
