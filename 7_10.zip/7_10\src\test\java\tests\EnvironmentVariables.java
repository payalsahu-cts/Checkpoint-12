package tests;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

/**
 * Scenario 11 - Create an Environment in Postman
 *
 * Postman steps:
 *   Step 2: Select Environments in sidebar, click +
 *   Step 3: Enter a name for the new environment
 *   Step 4: Add variables (baseUrl, username, password, token)
 *   Step 5: Save the environment
 *   Step 6: Select the environment from the selector
 *
 * REST Assured equivalent:
 *   Environment variables are represented as a static Map<String, String>
 *   loaded in @BeforeClass. All tests use values from this map via
 *   a shared RequestSpecification — identical to switching environments
 *   in Postman.
 */
public class EnvironmentVariables {

    // Step 2-5: Define the environment (name + variables)
    private static final String ENV_NAME = "RestfulBooker QA Environment";

    private static final Map<String, String> ENV = new HashMap<>();
    private RequestSpecification envSpec;

    @BeforeClass
    public void setupEnvironment() {

        // Step 4: Add environment variables
        ENV.put("baseUrl",  "https://restful-booker.herokuapp.com");
        ENV.put("username", "admin");
        ENV.put("password", "password123");

        // Retrieve token and store as environment variable
        String authBody = "{\n"
                + "    \"username\" : \"" + ENV.get("username") + "\",\n"
                + "    \"password\" : \"" + ENV.get("password") + "\"\n"
                + "}";

        Response authResponse = given()
                    .baseUri(ENV.get("baseUrl"))
                    .contentType(ContentType.JSON)
                    .body(authBody)
                .when()
                    .post("/auth")
                .then()
                    .assertThat().statusCode(200)
                    .extract().response();

        // Step 4: Store token as environment variable
        ENV.put("token", authResponse.jsonPath().getString("token"));

        // Step 5-6: Build the shared specification from environment variables
        RestAssured.baseURI = ENV.get("baseUrl");

        envSpec = given()
                .baseUri(ENV.get("baseUrl"))
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header("Cookie", "token=" + ENV.get("token"));

        System.out.println("========================================");
        System.out.println(" Environment : " + ENV_NAME);
        System.out.println("========================================");
        ENV.forEach((key, value) -> System.out.println(" " + key + " = " + value));
        System.out.println("========================================");
    }

    // Test using environment variable: baseUrl
    @Test(priority = 1)
    public void getAllBookingsUsingEnvUrl() {

        Response response = given(envSpec)
                .when()
                    .get("/booking")
                .then()
                    .assertThat()
                        .statusCode(200)
                        .body("$", notNullValue())
                    .extract()
                    .response();

        System.out.println("[ENV: " + ENV_NAME + "] GET /booking");
        System.out.println("baseUrl               : " + ENV.get("baseUrl"));
        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Body         : " + response.getBody().asPrettyString());
        Assert.assertEquals(response.getStatusCode(), 200);
    }

    // Test using environment variable: token
    @Test(priority = 2)
    public void createBookingUsingEnvToken() {

        String requestBody = "{\n"
                + "    \"firstname\": \"Jim\",\n"
                + "    \"lastname\": \"Brown\",\n"
                + "    \"totalprice\": 111,\n"
                + "    \"depositpaid\": true,\n"
                + "    \"bookingdates\": {\n"
                + "        \"checkin\": \"2018-01-01\",\n"
                + "        \"checkout\": \"2019-01-01\"\n"
                + "    },\n"
                + "    \"additionalneeds\": \"Breakfast\"\n"
                + "}";

        Response response = given(envSpec)
                    .body(requestBody)
                .when()
                    .post("/booking")
                .then()
                    .assertThat()
                        .statusCode(200)
                        .body("bookingid",         notNullValue())
                        .body("booking.firstname", equalTo("Jim"))
                    .extract()
                    .response();

        System.out.println("[ENV: " + ENV_NAME + "] POST /booking");
        System.out.println("token                 : " + ENV.get("token"));
        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Body         : " + response.getBody().asPrettyString());
        Assert.assertEquals(response.getStatusCode(), 200);
    }
}
