package data;

public class TestData {

    // Step 3: Static String variable holding the JSON request body
    public static String requestBody = "{\n" +
            "    \"name\": \"Vivo Pro 16\",\n" +
            "    \"data\": {\n" +
            "       \"year\": 2019,\n" +
            "       \"price\": 1849.99,\n" +
            "       \"CPU model\": \"Intel Core i9\",\n" +
            "       \"Hard disk size\": \"1 TB\"\n" +
            "    }\n" +
            "}";
}
