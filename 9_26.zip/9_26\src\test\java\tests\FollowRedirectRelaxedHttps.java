package tests;

import io.restassured.RestAssured;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RedirectConfig;
import io.restassured.config.SSLConfig;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class FollowRedirectRelaxedHttps {

    @Test
    public void followRedirectsWithRelaxedHttpsValidation() {

        // Step 1 & 3: Follow redirects but use relaxed HTTPS validation on redirected requests
        // using redirects().followRedirects(true) combined with relaxedHTTPSValidation()
        Response response = given()
                    .baseUri("https://simple-tool-rental-api.glitch.me")
                    .config(RestAssured.config()
                        .redirect(RedirectConfig.redirectConfig()
                            .followRedirects(true)
                            .maxRedirects(5))
                        .sslConfig(SSLConfig.sslConfig()
                            .relaxedHTTPSValidation()))
                .when()
                    .get("/status")
                .then()
                    .assertThat()
                        .statusCode(200)
                    .extract()
                    .response();

        // Step 2 & 3: Print the response in the console
        System.out.println("------ Follow Redirects + Relaxed HTTPS Validation ------");
        System.out.println("Response Status Code       : " + response.getStatusCode());
        System.out.println("Response Status Line       : " + response.getStatusLine());
        System.out.println("Response Body              : " + response.getBody().asString());
        System.out.println("Redirects Followed         : true");
        System.out.println("Relaxed HTTPS Validation   : true");
        System.out.println("SSL Certificate Verified   : false (relaxed — skips cert validation)");
    }

    @Test
    public void followRedirectsWithStrictHttpsValidation() {

        // For comparison — follow redirects with STRICT HTTPS validation (default)
        Response response = given()
                    .baseUri("https://simple-tool-rental-api.glitch.me")
                    .config(RestAssured.config()
                        .redirect(RedirectConfig.redirectConfig()
                            .followRedirects(true)))
                .when()
                    .get("/status")
                .then()
                    .assertThat()
                        .statusCode(200)
                    .extract()
                    .response();

        System.out.println("------ Follow Redirects + Strict HTTPS Validation ------");
        System.out.println("Response Status Code       : " + response.getStatusCode());
        System.out.println("Response Body              : " + response.getBody().asString());
        System.out.println("Redirects Followed         : true");
        System.out.println("Relaxed HTTPS Validation   : false (strict — validates SSL cert)");
    }
}
