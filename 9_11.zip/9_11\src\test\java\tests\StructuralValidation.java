package tests;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.notNullValue;

public class StructuralValidation {

    @Test
    public void validateStructureUsingRootPath() {

        String requestBody = "{\n"
                + "    \"firstname\": \"Jim\",\n"
                + "    \"lastname\": \"Brown\",\n"
                + "    \"totalprice\": 111,\n"
                + "    \"depositpaid\": true,\n"
                + "    \"bookingdates\": {\n"
                + "        \"checkin\": \"2018-01-01\",\n"
                + "        \"checkout\": \"2019-01-01\"\n"
                + "    },\n"
                + "    \"additionalneeds\": \"Breakfast\"\n"
                + "}";

        // Step 1: POST request
        // Step 2: Use root() to set root path, then check field existence with body()
        Response response = given()
                    .baseUri("https://restful-booker.herokuapp.com")
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .body(requestBody)
                .when()
                    .post("/booking")
                .then()
                    .assertThat()
                        .statusCode(200)

                        // Check top-level field existence (no root path)
                        .body("bookingid", notNullValue())
                        .body("booking",   notNullValue())

                        // Set root path to "booking" — all subsequent body() calls
                        // use paths relative to "booking"
                        .root("booking")
                        .body("firstname",      notNullValue())
                        .body("lastname",       notNullValue())
                        .body("totalprice",     notNullValue())
                        .body("depositpaid",    notNullValue())
                        .body("bookingdates",   notNullValue())
                        .body("additionalneeds",notNullValue())

                        // Drill deeper — set root path to "booking.bookingdates"
                        .root("booking.bookingdates")
                        .body("checkin",  notNullValue())
                        .body("checkout", notNullValue())

                        // Reset root path back to top level
                        .noRoot()

                    .extract()
                    .response();

        // Step 3: Print the response in the console
        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Body         : " + response.getBody().asPrettyString());
        System.out.println("------ Structural Validation Result ------");
        System.out.println("bookingid             : " + response.jsonPath().get("bookingid"));
        System.out.println("booking               : " + response.jsonPath().get("booking"));
        System.out.println("booking.firstname     : " + response.jsonPath().getString("booking.firstname"));
        System.out.println("booking.lastname      : " + response.jsonPath().getString("booking.lastname"));
        System.out.println("booking.totalprice    : " + response.jsonPath().getInt("booking.totalprice"));
        System.out.println("booking.depositpaid   : " + response.jsonPath().getBoolean("booking.depositpaid"));
        System.out.println("checkin               : " + response.jsonPath().getString("booking.bookingdates.checkin"));
        System.out.println("checkout              : " + response.jsonPath().getString("booking.bookingdates.checkout"));
        System.out.println("additionalneeds       : " + response.jsonPath().getString("booking.additionalneeds"));
    }
}
