package com.api.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;

/**
 * Test Class : ValidateStatusCode200
 *
 * Scenario   : Validate the 200 status code in REST Assured
 * API        : https://the-internet.herokuapp.com/status_codes/200
 * Method     : GET
 *
 * Steps covered:
 * Step 1 - Maven project with TestNG & REST Assured dependencies (pom.xml)
 * Step 2 - Basic Auth Java class created in REST Assured framework (this file)
 * Step 3 - GET request sent to https://the-internet.herokuapp.com/status_codes/200
 * Step 4 - Verify the status code is 200
 */
public class ValidateStatusCode200 {

    // ----------------------------------------------------------------
    // Constants
    // ----------------------------------------------------------------
    private static final String BASE_URL = "https://the-internet.herokuapp.com";
    private static final String ENDPOINT = "/status_codes/200";

    // ----------------------------------------------------------------
    // Step 2 : Setup — configure base URI before tests run
    // ----------------------------------------------------------------
    @BeforeClass
    public void setUp() {
        RestAssured.baseURI = BASE_URL;
        System.out.println("=======================================================");
        System.out.println("  REST Assured Framework - Status Code 200 Validation  ");
        System.out.println("=======================================================");
        System.out.println("Base URI : " + BASE_URL);
        System.out.println("Endpoint : " + ENDPOINT);
    }

    // ================================================================
    // Step 3 & 4 — Fluent chain: GET request + status code assertion
    // ================================================================

    /**
     * TEST 1 : Fluent chain approach
     * Sends GET request and asserts status code 200 inline
     */
    @Test(priority = 1, description = "Validate 200 status code using fluent REST Assured chain")
    public void validateStatusCode200_FluentChain() {

        System.out.println("\n[TEST 1] Fluent Chain - Validate Status Code 200");

        // Step 3: GET request to the API
        // Step 4: Verify status code is 200
        given()
            .log().all()                    // Log full request details
        .when()
            .get(ENDPOINT)                  // Step 3: GET call
        .then()
            .log().all()                    // Log full response details
            .statusCode(200);               // Step 4: Assert status code = 200

        System.out.println("[TEST 1] PASSED - Status Code is 200");
    }

    // ================================================================
    // Step 3 & 4 — Explicit assertion using Response object
    // ================================================================

    /**
     * TEST 2 : Explicit assertion using Response object
     * Captures the response, then asserts status code with TestNG Assert
     */
    @Test(priority = 2, description = "Validate 200 status code using explicit TestNG assertion")
    public void validateStatusCode200_ExplicitAssertion() {

        System.out.println("\n[TEST 2] Explicit Assertion - Validate Status Code 200");

        // Step 3: Send GET request and capture response
        Response response =
            given()
                .log().uri()
            .when()
                .get(ENDPOINT)
            .then()
                .extract()
                .response();

        // Step 4: Verify the status code is 200
        int actualStatusCode = response.getStatusCode();
        System.out.println("Actual Status Code   : " + actualStatusCode);
        System.out.println("Expected Status Code : 200");

        Assert.assertEquals(actualStatusCode, 200,
            "Status code mismatch! Expected 200 but got: " + actualStatusCode);

        System.out.println("[TEST 2] PASSED - Status Code verified as 200");
    }

    // ================================================================
    // Step 3 & 4 — Status line verification
    // ================================================================

    /**
     * TEST 3 : Verify full status line
     * Asserts the complete HTTP status line "HTTP/1.1 200 OK"
     */
    @Test(priority = 3, description = "Validate full HTTP status line is '200 OK'")
    public void validateStatusLine_200OK() {

        System.out.println("\n[TEST 3] Status Line Verification - 200 OK");

        // Step 3: GET request
        Response response =
            given()
                .log().uri()
            .when()
                .get(ENDPOINT)
            .then()
                .extract()
                .response();

        // Step 4: Verify status line contains "200"
        String statusLine = response.getStatusLine();
        System.out.println("Status Line : " + statusLine);

        Assert.assertTrue(statusLine.contains("200"),
            "Expected status line to contain '200' but got: " + statusLine);

        System.out.println("[TEST 3] PASSED - Status Line contains 200");
    }
}
