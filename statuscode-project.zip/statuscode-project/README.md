# REST Assured - Validate 200 Status Code

## Scenario: Validate the 200 Status Code in REST Assured

| Step | Description |
|------|-------------|
| 1 | Maven project with TestNG & REST Assured dependencies |
| 2 | Basic Auth Java class created in REST Assured framework |
| 3 | GET request sent to `https://the-internet.herokuapp.com/status_codes/200` |
| 4 | Verify the status code is `200` |

---

## Project Structure

```
statuscode-project/
├── pom.xml                          ← Maven dependencies (TestNG + REST Assured)
├── testng.xml                       ← TestNG suite configuration
├── README.md
└── src/
    └── test/
        └── java/
            └── com/api/tests/
                └── ValidateStatusCode200.java   ← Main test class
```

---

## Prerequisites

- Java 11 or higher
- Maven 3.6+

---

## How to Run

```bash
mvn clean test
```

Or in IDE: Right-click `testng.xml` → **Run**

---

## Test Cases

| Test Method | Description | Expected |
|-------------|-------------|----------|
| `validateStatusCode200_FluentChain` | Fluent REST Assured chain assertion | Status 200 |
| `validateStatusCode200_ExplicitAssertion` | TestNG Assert on response object | Status 200 |
| `validateStatusLine_200OK` | Full HTTP status line check | Contains "200" |

---

## API Details

- **URL:** `https://the-internet.herokuapp.com/status_codes/200`
- **Method:** GET
- **Auth:** None required
- **Expected Status Code:** `200`
