package tests;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class USPopulation2020Test {

    private static final String BASE_URI = "https://datausa.io";
    private static final String ENDPOINT = "/api/data";

    // Base RequestSpecification (with default Year)
    private RequestSpecification baseRequestSpec;

    // Overwritten RequestSpecification (for Year 2020)
    private RequestSpecification overwrittenRequestSpec;

    private Response response;

    // Step 3 & 4: Create base RequestSpecification and execute @BeforeClass
    // Step 5: Overwrite the RequestSpecification for Year 2020
    @BeforeClass
    public void setUpRequestSpecification() {

        // Step 3: Base RequestSpecification with drilldowns and measures
        baseRequestSpec = new RequestSpecBuilder()
                .setBaseUri(BASE_URI)
                .addQueryParam("drilldowns", "Nation")
                .addQueryParam("measures",   "Population")
                .addQueryParam("Year",       "2022")
                .build();

        System.out.println("=======================================================");
        System.out.println(" Base RequestSpecification created:");
        System.out.println(" Base URI   : " + BASE_URI);
        System.out.println(" drilldowns : Nation");
        System.out.println(" measures   : Population");
        System.out.println(" Year       : 2022  (default)");
        System.out.println("=======================================================");

        // Step 5: Overwrite the RequestSpecification — replace Year with 2020
        overwrittenRequestSpec = new RequestSpecBuilder()
                .addRequestSpecification(baseRequestSpec)
                .addQueryParam("Year", "2020")
                .build();

        System.out.println(" Overwritten RequestSpecification created:");
        System.out.println(" Year overwritten to : 2020");
        System.out.println("=======================================================");

        // Step 6: Send GET request using overwritten spec
        response = RestAssured
                .given()
                    .spec(overwrittenRequestSpec)
                    .log().all()
                .when()
                    .get(ENDPOINT)
                .then()
                    .log().all()
                    .extract()
                    .response();
    }

    // Scenario 2: Print United States population details for year 2020
    @Test
    public void printUSPopulationDetails2020() {

        // Step 7: Print ID Nation
        String idNation = response.jsonPath().getString("data[0].'ID Nation'");

        // Step 8: Print Nation
        String nation = response.jsonPath().getString("data[0].Nation");

        // Step 9: Print ID Year
        String idYear = response.jsonPath().getString("data[0].'ID Year'");

        // Step 10: Print Population
        String population = response.jsonPath().getString("data[0].Population");

        // Step 11: Print Slug Nation
        String slugNation = response.jsonPath().getString("data[0].'Slug Nation'");

        // Step 12: Print source_name & source_description
        String sourceName        = response.jsonPath()
                .getString("source[0].annotations.source_name");
        String sourceDescription = response.jsonPath()
                .getString("source[0].annotations.source_description");

        System.out.println("=======================================================");
        System.out.println(" United States Population Details - Year 2020");
        System.out.println("=======================================================");
        System.out.println(" ID Nation          : " + idNation);
        System.out.println(" Nation             : " + nation);
        System.out.println(" ID Year            : " + idYear);
        System.out.println(" Population         : " + population);
        System.out.println(" Slug Nation        : " + slugNation);
        System.out.println("-------------------------------------------------------");
        System.out.println(" Source Name        : " + sourceName);
        System.out.println(" Source Description : " + sourceDescription);
        System.out.println("=======================================================");
    }
}
