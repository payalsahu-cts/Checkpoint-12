package tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class BitcoinRateTest {

    private static final String BASE_URL = "https://api.coindesk.com/v1/bpi/currentprice.json";

    @BeforeClass
    public void setUp() {
        RestAssured.baseURI = BASE_URL;
    }

    // Scenario 1: Verify Success Status Code 200
    @Test
    public void verifyStatusCode200() {
        Response response = RestAssured
                .given()
                    .log().all()
                .when()
                    .get()
                .then()
                    .log().all()
                    .extract()
                    .response();

        int actualStatusCode = response.getStatusCode();
        System.out.println("Actual Status Code: " + actualStatusCode);

        Assert.assertEquals(actualStatusCode, 200,
                "Expected Status Code 200 but got: " + actualStatusCode);

        System.out.println("Test Passed: Status Code is 200 as expected.");
    }

    // Scenario 2: Verify Failure Status Code 404
    @Test
    public void verifyStatusCode404() {
        Response response = RestAssured
                .given()
                    .log().all()
                .when()
                    .get()
                .then()
                    .log().all()
                    .extract()
                    .response();

        int actualStatusCode = response.getStatusCode();
        System.out.println("Actual Status Code: " + actualStatusCode);

        Assert.assertEquals(actualStatusCode, 404,
                "Expected Status Code 404 but got: " + actualStatusCode);

        System.out.println("Test Passed: Status Code is 404 as expected.");
    }
}
