package tests;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class USPopulation2020ResponseSpecTest {

    private static final String BASE_URI = "https://datausa.io";
    private static final String ENDPOINT = "/api/data";

    // Base RequestSpecification (Year 2022 - default)
    private RequestSpecification  baseRequestSpec;

    // Overwritten RequestSpecification (Year 2020)
    private RequestSpecification  overwrittenRequestSpec;

    // Base ResponseSpecification
    private ResponseSpecification baseResponseSpec;

    // Overwritten ResponseSpecification
    private ResponseSpecification overwrittenResponseSpec;

    private Response response;

    // Step 3, 4 & 5: Create and overwrite both specs @BeforeClass
    @BeforeClass
    public void setUpSpecifications() {

        // Base RequestSpecification (with default Year 2022)
        baseRequestSpec = new RequestSpecBuilder()
                .setBaseUri(BASE_URI)
                .setBasePath(ENDPOINT)
                .addQueryParam("drilldowns", "Nation")
                .addQueryParam("measures",   "Population")
                .addQueryParam("Year",       "2022")
                .build();

        // Overwrite RequestSpecification — replace Year with 2020
        overwrittenRequestSpec = new RequestSpecBuilder()
                .addRequestSpecification(baseRequestSpec)
                .addQueryParam("Year", "2020")
                .build();

        System.out.println("=======================================================");
        System.out.println(" Base RequestSpecification created (Year: 2022)");
        System.out.println(" Overwritten RequestSpecification applied (Year: 2020)");
        System.out.println("=======================================================");

        // Base ResponseSpecification — status code 200 and ContentType JSON
        baseResponseSpec = new ResponseSpecBuilder()
                .expectStatusCode(200)
                .expectContentType(ContentType.JSON)
                .build();

        // Overwrite ResponseSpecification — extend base with additional body validation
        overwrittenResponseSpec = new ResponseSpecBuilder()
                .addResponseSpecification(baseResponseSpec)
                .expectStatusCode(200)
                .expectContentType(ContentType.JSON)
                .expectBody("data[0].Nation",
                        org.hamcrest.Matchers.equalTo("United States"))
                .build();

        System.out.println(" Base ResponseSpecification created:");
        System.out.println("   Expected Status Code  : 200");
        System.out.println("   Expected Content-Type : application/json");
        System.out.println("-------------------------------------------------------");
        System.out.println(" Overwritten ResponseSpecification applied:");
        System.out.println("   Expected Status Code  : 200  (retained)");
        System.out.println("   Expected Content-Type : application/json  (retained)");
        System.out.println("   Additional Body Check : data[0].Nation = United States");
        System.out.println("=======================================================");

        // Step 6: Send GET request using overwritten specs
        response = RestAssured
                .given()
                    .spec(overwrittenRequestSpec)
                    .log().all()
                .when()
                    .get()
                .then()
                    .log().all()
                    .spec(overwrittenResponseSpec)
                    .extract()
                    .response();
    }

    // Scenario 2: Print United States population details for year 2020
    @Test
    public void printUSPopulationDetails2020() {

        // Step 7: Print ID Nation
        String idNation = response.jsonPath().getString("data[0].'ID Nation'");

        // Step 8: Print Nation
        String nation = response.jsonPath().getString("data[0].Nation");

        // Step 9: Print ID Year
        String idYear = response.jsonPath().getString("data[0].'ID Year'");

        // Step 10: Print Population
        String population = response.jsonPath().getString("data[0].Population");

        // Step 11: Print Slug Nation
        String slugNation = response.jsonPath().getString("data[0].'Slug Nation'");

        // Step 12: Print source_name & source_description
        String sourceName        = response.jsonPath()
                .getString("source[0].annotations.source_name");
        String sourceDescription = response.jsonPath()
                .getString("source[0].annotations.source_description");

        System.out.println("=======================================================");
        System.out.println(" United States Population Details - Year 2020");
        System.out.println("=======================================================");
        System.out.println(" ID Nation          : " + idNation);
        System.out.println(" Nation             : " + nation);
        System.out.println(" ID Year            : " + idYear);
        System.out.println(" Population         : " + population);
        System.out.println(" Slug Nation        : " + slugNation);
        System.out.println("-------------------------------------------------------");
        System.out.println(" Source Name        : " + sourceName);
        System.out.println(" Source Description : " + sourceDescription);
        System.out.println("=======================================================");
    }
}
