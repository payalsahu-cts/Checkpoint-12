package tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

/**
 * Scenario 1 - Create Workspace for API Request
 *
 * In Postman:
 *   Step 1: Open Postman
 *   Step 2: Click on Workspace > Create Workspace
 *   Step 3: Select Blank workspace template, click Next
 *   Step 4: Give a meaningful name, choose access, click Create
 *
 * In REST Assured (Java equivalent):
 *   A "workspace" concept is represented by a base URL configured via
 *   RestAssured.baseURI and a shared RequestSpecification — the equivalent
 *   of scoping all requests to a common base.
 */
public class CreateWorkspace {

    // Step 2-4: Define the workspace — base URI acts as the workspace scope
    private static final String WORKSPACE_NAME = "RestfulBooker Workspace";
    private static final String BASE_URI       = "https://restful-booker.herokuapp.com";

    private RequestSpecification workspaceSpec;

    @BeforeClass
    public void setupWorkspace() {
        // Configure the shared workspace specification
        RestAssured.baseURI = BASE_URI;

        workspaceSpec = given()
                .baseUri(BASE_URI)
                .header("Content-Type", "application/json")
                .accept("application/json");

        System.out.println("========================================");
        System.out.println(" Workspace Created: " + WORKSPACE_NAME);
        System.out.println(" Base URI         : " + BASE_URI);
        System.out.println("========================================");
    }

    @Test
    public void verifyWorkspaceIsReachable() {

        // Verify the workspace base URI is reachable
        Response response = given(workspaceSpec)
                .when()
                    .get("/booking")
                .then()
                    .assertThat()
                        .statusCode(200)
                        .body("$", notNullValue())
                    .extract()
                    .response();

        System.out.println("Workspace Base URI    : " + BASE_URI);
        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Body         : " + response.getBody().asPrettyString());

        Assert.assertEquals(response.getStatusCode(), 200,
                "Workspace base URI is not reachable!");
        System.out.println("Workspace setup verified successfully.");
    }
}
