package tests;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.internal.mapping.Jackson2Mapper;
import io.restassured.parsing.Parser;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

public class CustomParserValidation {

    @Test
    public void validateResponseWithCustomParser() {

        // Register a custom parser:
        // The server may return JSON content with a non-standard MIME type (e.g. text/plain).
        // REST Assured won't parse it as JSON by default — register JSON parser for that type.
        RestAssured.registerParser("text/plain", Parser.JSON);

        String requestBody = "{\n"
                + "    \"firstname\": \"Jim\",\n"
                + "    \"lastname\": \"Brown\",\n"
                + "    \"totalprice\": 111,\n"
                + "    \"depositpaid\": true,\n"
                + "    \"bookingdates\": {\n"
                + "        \"checkin\": \"2018-01-01\",\n"
                + "        \"checkout\": \"2019-01-01\"\n"
                + "    },\n"
                + "    \"additionalneeds\": \"Breakfast\"\n"
                + "}";

        // Step 1 & 2: POST request — using default JSON parser (standard flow)
        // Custom parser is already registered above for text/plain responses
        Response response = given()
                    .baseUri("https://restful-booker.herokuapp.com")
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .body(requestBody)
                .when()
                    .post("/booking")
                .then()
                    .assertThat()
                        .statusCode(200)
                        .body("bookingid",             notNullValue())
                        .body("booking.firstname",     equalTo("Jim"))
                        .body("booking.lastname",      equalTo("Brown"))
                        .body("booking.totalprice",    equalTo(111))
                        .body("booking.depositpaid",   equalTo(true))
                    .extract()
                    .response();

        // Demonstrate explicit parser usage on the response body
        String rawBody = response.getBody().asString();

        // Parse the raw response string explicitly using REST Assured's JsonPath with JSON parser
        io.restassured.path.json.JsonPath jsonPath =
                new io.restassured.path.json.JsonPath(rawBody);

        String firstname   = jsonPath.getString("booking.firstname");
        String lastname    = jsonPath.getString("booking.lastname");
        int    totalprice  = jsonPath.getInt("booking.totalprice");
        boolean depositpaid = jsonPath.getBoolean("booking.depositpaid");

        // Step 3: Print the response in the console
        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Body         : " + response.getBody().asPrettyString());
        System.out.println("------ Custom Parser Extracted Values ------");
        System.out.println("Registered Parser     : text/plain -> JSON Parser");
        System.out.println("firstname             : " + firstname);
        System.out.println("lastname              : " + lastname);
        System.out.println("totalprice            : " + totalprice);
        System.out.println("depositpaid           : " + depositpaid);

        // Deregister custom parser after test to avoid side effects
        RestAssured.unregisterParser("text/plain");
    }
}
