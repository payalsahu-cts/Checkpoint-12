package tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.File;

public class UploadTest {

    @Test
    public void verifyFileUploadSuccess() {

        // Step 2: Reference the input file stored in the resources folder
        File uploadFile = new File("src/test/resources/sample_upload.txt");

        // Step 3: Use multiPart and send POST request to the upload API
        Response response = RestAssured
                .given()
                    .baseUri("https://the-internet.herokuapp.com")
                    .contentType("multipart/form-data")
                    .multiPart("file", uploadFile)
                    .log().all()
                .when()
                    .post("/upload")
                .then()
                    .log().all()
                    .extract()
                    .response();

        // Step 4: Verify the success response code 200
        int statusCode = response.getStatusCode();
        System.out.println("Status Code: " + statusCode);
        Assert.assertEquals(statusCode, 200, "Expected status code 200 but got: " + statusCode);

        // Print full response
        System.out.println("========= Full Response =========");
        System.out.println("Status Code  : " + response.getStatusCode());
        System.out.println("Status Line  : " + response.getStatusLine());
        System.out.println("Response Time: " + response.getTime() + " ms");
        System.out.println("Response Body:");
        System.out.println(response.getBody().asPrettyString());
        System.out.println("=================================");

        // Verify response body confirms successful upload
        String responseBody = response.getBody().asString();
        Assert.assertTrue(responseBody.contains("File Uploaded!"),
                "Response body does not contain 'File Uploaded!' confirmation");
        System.out.println("File upload verified successfully!");
    }
}
