package tests;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;

/**
 * Scenario 9 - Get the response of DELETE API Request
 *
 * Step 6: Method = DELETE
 * Step 7: Auth   = Basic Auth (admin / password123)
 * Step 8: URL    = https://restful-booker.herokuapp.com/booking/:id
 * Step 10: Send and verify
 */
public class DeleteApiWithBasicAuth {

    private static final String BASE_URI = "https://restful-booker.herokuapp.com";
    private static final String USERNAME = "admin";
    private static final String PASSWORD = "password123";

    private int bookingId;

    @BeforeClass
    public void createBookingToDelete() {

        String createBody = "{\n"
                + "    \"firstname\": \"Jim\",\n"
                + "    \"lastname\": \"Brown\",\n"
                + "    \"totalprice\": 111,\n"
                + "    \"depositpaid\": true,\n"
                + "    \"bookingdates\": {\n"
                + "        \"checkin\": \"2018-01-01\",\n"
                + "        \"checkout\": \"2019-01-01\"\n"
                + "    },\n"
                + "    \"additionalneeds\": \"Breakfast\"\n"
                + "}";

        Response createResponse = given()
                    .baseUri(BASE_URI)
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .body(createBody)
                .when()
                    .post("/booking")
                .then()
                    .assertThat().statusCode(200)
                    .extract().response();

        bookingId = createResponse.jsonPath().getInt("bookingid");
        System.out.println("Booking created with ID: " + bookingId);
    }

    @Test
    public void deleteBookingWithBasicAuth() {

        // Step 6-10: DELETE /booking/:id with Basic Auth
        Response response = given()
                    .baseUri(BASE_URI)
                    .contentType(ContentType.JSON)
                    .auth().basic(USERNAME, PASSWORD)
                .when()
                    .delete("/booking/" + bookingId)
                .then()
                    .assertThat()
                        // 201 Created is the response code for successful delete on this API
                        .statusCode(201)
                    .extract()
                    .response();

        System.out.println("========================================");
        System.out.println(" DELETE /booking/" + bookingId + " with Basic Auth");
        System.out.println("========================================");
        System.out.println("URL                   : " + BASE_URI + "/booking/" + bookingId);
        System.out.println("Method                : DELETE");
        System.out.println("Auth                  : Basic Auth (" + USERNAME + " / " + PASSWORD + ")");
        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Body         : " + response.getBody().asString());

        Assert.assertEquals(response.getStatusCode(), 201,
                "Expected 201 (deleted) but got: " + response.getStatusCode());

        // Verify the booking is actually deleted — GET should return 404
        Response getResponse = given()
                    .baseUri(BASE_URI)
                    .accept(ContentType.JSON.toString())
                .when()
                    .get("/booking/" + bookingId)
                .then()
                    .extract().response();

        System.out.println("Verification GET Status: " + getResponse.getStatusCode()
                + " (404 confirms deletion)");
        Assert.assertEquals(getResponse.getStatusCode(), 404,
                "Booking should be deleted but still found!");
        System.out.println("DELETE request verified successfully.");
    }
}
