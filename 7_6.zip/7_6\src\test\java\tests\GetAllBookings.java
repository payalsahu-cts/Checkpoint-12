package tests;

import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.notNullValue;

/**
 * Scenario 6 - Get the response of GET API Request
 *
 * Step 6: Method = GET
 * Step 7: URL   = https://restful-booker.herokuapp.com/booking
 * Step 8: Click Send and verify the response
 */
public class GetAllBookings {

    @Test
    public void getResponseFromBookingEndpoint() {

        // Step 6-8: GET https://restful-booker.herokuapp.com/booking
        Response response = given()
                    .baseUri("https://restful-booker.herokuapp.com")
                    .accept("application/json")
                .when()
                    .get("/booking")
                .then()
                    .assertThat()
                        .statusCode(200)
                        .body("$",          notNullValue())
                        .body("bookingid",  notNullValue())
                        .body("$",          org.hamcrest.Matchers.hasSize(greaterThan(0)))
                    .extract()
                    .response();

        List<Map<String, Object>> bookings  = response.jsonPath().getList("$");
        List<Integer>             bookingIds = response.jsonPath().getList("bookingid");

        System.out.println("========================================");
        System.out.println(" GET /booking Response");
        System.out.println("========================================");
        System.out.println("URL                   : https://restful-booker.herokuapp.com/booking");
        System.out.println("Method                : GET");
        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Total Bookings Found  : " + bookings.size());
        System.out.println("All Booking IDs       : " + bookingIds);
        System.out.println("Response Body         : " + response.getBody().asPrettyString());

        Assert.assertEquals(response.getStatusCode(), 200);
        Assert.assertTrue(bookings.size() > 0, "No bookings returned!");
        System.out.println("GET /booking verified successfully.");
    }
}
