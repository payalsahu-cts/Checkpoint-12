package tests;

import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;

public class ValidateNonMatchingSchema {

    @Test
    public void ensureDataTypesDoNotMatchSchema() {

        // Step 4: GET request to jsonplaceholder
        Response response = given()
                    .baseUri("https://jsonplaceholder.typicode.com")
                    .accept("application/json")
                .when()
                    .get("/posts/2")
                .then()
                    .assertThat()
                        .statusCode(200)
                    .extract()
                    .response();

        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Body         : " + response.getBody().asPrettyString());

        // Step 5: Ensure data types do NOT match the wrong-type schema using TestNG assertion
        boolean schemaMatched = true;
        try {
            given()
                .baseUri("https://jsonplaceholder.typicode.com")
                .accept("application/json")
            .when()
                .get("/posts/2")
            .then()
                .assertThat()
                    // Wrong-types schema — validation SHOULD fail
                    .body(matchesJsonSchemaInClasspath("postsSchemaWrongTypes.json"));
        } catch (AssertionError e) {
            schemaMatched = false;
            System.out.println("Schema mismatch detected (expected): " + e.getMessage());
        }

        // TestNG assertion — types should NOT match the wrong schema
        Assert.assertFalse(schemaMatched,
            "FAILED: Response data types unexpectedly matched the wrong-type schema!");

        System.out.println("------ Schema Data Type Mismatch Validation ------");
        System.out.println("Schema File              : postsSchemaWrongTypes.json");
        System.out.println("userId  schema type : string   | actual: "
                + response.jsonPath().get("userId").getClass().getSimpleName()
                + " --> MISMATCH");
        System.out.println("id      schema type : string   | actual: "
                + response.jsonPath().get("id").getClass().getSimpleName()
                + " --> MISMATCH");
        System.out.println("title   schema type : integer  | actual: "
                + response.jsonPath().get("title").getClass().getSimpleName()
                + " --> MISMATCH");
        System.out.println("body    schema type : boolean  | actual: "
                + response.jsonPath().get("body").getClass().getSimpleName()
                + " --> MISMATCH");
        System.out.println("Data Types Match Wrong Schema : " + schemaMatched + " (correctly NOT matching)");
    }
}
