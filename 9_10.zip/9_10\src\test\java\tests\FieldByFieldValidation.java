package tests;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.notNullValue;

public class FieldByFieldValidation {

    @Test
    public void validateIndividualFieldsInResponse() {

        String requestBody = "{\n"
                + "    \"firstname\": \"Jim\",\n"
                + "    \"lastname\": \"Brown\",\n"
                + "    \"totalprice\": 111,\n"
                + "    \"depositpaid\": true,\n"
                + "    \"bookingdates\": {\n"
                + "        \"checkin\": \"2018-01-01\",\n"
                + "        \"checkout\": \"2019-01-01\"\n"
                + "    },\n"
                + "    \"additionalneeds\": \"Breakfast\"\n"
                + "}";

        // Step 1: POST request
        // Step 2: Validate individual fields using body() method with JsonPath expressions
        Response response = given()
                    .baseUri("https://restful-booker.herokuapp.com")
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .body(requestBody)
                .when()
                    .post("/booking")
                .then()
                    .assertThat()
                        .statusCode(200)
                        // Top-level field
                        .body("bookingid",                        notNullValue())
                        .body("bookingid",                        greaterThan(0))
                        // Nested fields inside "booking"
                        .body("booking.firstname",                equalTo("Jim"))
                        .body("booking.lastname",                 equalTo("Brown"))
                        .body("booking.totalprice",               equalTo(111))
                        .body("booking.depositpaid",              equalTo(true))
                        // Deeply nested fields inside "booking.bookingdates"
                        .body("booking.bookingdates.checkin",     equalTo("2018-01-01"))
                        .body("booking.bookingdates.checkout",    equalTo("2019-01-01"))
                        // Optional field
                        .body("booking.additionalneeds",          equalTo("Breakfast"))
                    .extract()
                    .response();

        // Step 3: Print the response in the console
        System.out.println("Response Status Code         : " + response.getStatusCode());
        System.out.println("Response Body                : " + response.getBody().asPrettyString());
        System.out.println("------ Extracted Field Values ------");
        System.out.println("bookingid                    : " + response.jsonPath().getInt("bookingid"));
        System.out.println("booking.firstname            : " + response.jsonPath().getString("booking.firstname"));
        System.out.println("booking.lastname             : " + response.jsonPath().getString("booking.lastname"));
        System.out.println("booking.totalprice           : " + response.jsonPath().getInt("booking.totalprice"));
        System.out.println("booking.depositpaid          : " + response.jsonPath().getBoolean("booking.depositpaid"));
        System.out.println("booking.bookingdates.checkin : " + response.jsonPath().getString("booking.bookingdates.checkin"));
        System.out.println("booking.bookingdates.checkout: " + response.jsonPath().getString("booking.bookingdates.checkout"));
        System.out.println("booking.additionalneeds      : " + response.jsonPath().getString("booking.additionalneeds"));
    }
}
