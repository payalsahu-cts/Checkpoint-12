package tests;

import io.restassured.RestAssured;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.ByteArrayOutputStream;
import java.util.List;

public class UniversitiesCanadaTest {

    private static final String BASE_URL   = "http://universities.hipolabs.com";
    private static final String ENDPOINT   = "/search";
    private static final String COUNTRY    = "canada";
    private static final String OUTPUT_FILE = "response_log_canada.txt";

    // Scenario 3: Get number of universities in Canada and write response log to text file
    @Test
    public void getUniversitiesInCanadaAndWriteToFile() throws IOException {

        // Capture response log output into a ByteArrayOutputStream
        ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(byteStream);

        Response response = RestAssured
                .given()
                    .baseUri(BASE_URL)
                    .queryParam("country", COUNTRY)
                    .filter(new ResponseLoggingFilter(printStream))
                    .log().all()
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract()
                    .response();

        // Get total count of universities
        List<Object> universities = response.jsonPath().getList("$");
        int totalCount = universities.size();

        // Build the content to write into the text file
        StringBuilder logContent = new StringBuilder();
        logContent.append("=======================================================\n");
        logContent.append(" Response Status Code  : ").append(response.getStatusCode()).append("\n");
        logContent.append(" Response Time (ms)    : ").append(response.getTime()).append("\n");
        logContent.append(" Country Searched      : ").append(COUNTRY).append("\n");
        logContent.append(" Total Universities    : ").append(totalCount).append("\n");
        logContent.append("=======================================================\n");
        logContent.append(" Full Response Log     :\n");
        logContent.append(byteStream.toString()).append("\n");
        logContent.append("=======================================================\n");

        // Write the log content to a text file
        try (FileWriter writer = new FileWriter(OUTPUT_FILE)) {
            writer.write(logContent.toString());
        }

        // Print summary to console
        System.out.println("=======================================================");
        System.out.println(" Response Status Code  : " + response.getStatusCode());
        System.out.println(" Response Time (ms)    : " + response.getTime());
        System.out.println(" Country Searched      : " + COUNTRY);
        System.out.println(" Total Universities    : " + totalCount);
        System.out.println(" Response log written to file: " + OUTPUT_FILE);
        System.out.println("=======================================================");
    }
}
