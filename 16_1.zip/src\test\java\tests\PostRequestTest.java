package tests;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

public class PostRequestTest {

    @Test
    public void verifyPostRequestStatusCode() {

        // Step 3: Store the JSON body in a String variable
        String requestBody = "{\n" +
                "    \"name\": \"Apple MacBook Pro 16\",\n" +
                "    \"data\": {\n" +
                "       \"year\": 2019,\n" +
                "       \"price\": 1849.99,\n" +
                "       \"CPU model\": \"Intel Core i9\",\n" +
                "       \"Hard disk size\": \"1 TB\"\n" +
                "    }\n" +
                "}";

        // Step 4: Send POST request using the string variable as request body
        Response response = RestAssured
                .given()
                    .baseUri("https://api.restful-api.dev")
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .body(requestBody)
                    .log().all()
                .when()
                    .post("/objects")
                .then()
                    .log().all()
                    .extract()
                    .response();

        // Step 5: Verify status code is 200
        int statusCode = response.getStatusCode();
        System.out.println("Status Code: " + statusCode);
        Assert.assertEquals(statusCode, 200, "Expected status code 200 but got: " + statusCode);

        // Step 6: Print the entire response
        System.out.println("========= Full Response =========");
        System.out.println("Status Code  : " + response.getStatusCode());
        System.out.println("Status Line  : " + response.getStatusLine());
        System.out.println("Response Time: " + response.getTime() + " ms");
        System.out.println("Headers      : " + response.getHeaders());
        System.out.println("Response Body:");
        System.out.println(response.getBody().asPrettyString());
        System.out.println("=================================");
    }
}
