package tests;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

/**
 * Scenario 8 - Get the response of PATCH API Request
 *
 * Step 6: Method = PATCH
 * Step 7: Auth   = Basic Auth (admin / password123)
 * Step 8: URL    = https://restful-booker.herokuapp.com/booking/:id
 * Step 9: Partial update body (only fields being changed)
 * Step 10: Send and verify
 */
public class PatchApiWithBasicAuth {

    private static final String BASE_URI = "https://restful-booker.herokuapp.com";
    private static final String USERNAME = "admin";
    private static final String PASSWORD = "password123";

    private int bookingId;

    @BeforeClass
    public void createBookingToPatch() {

        String createBody = "{\n"
                + "    \"firstname\": \"Jim\",\n"
                + "    \"lastname\": \"Brown\",\n"
                + "    \"totalprice\": 111,\n"
                + "    \"depositpaid\": true,\n"
                + "    \"bookingdates\": {\n"
                + "        \"checkin\": \"2018-01-01\",\n"
                + "        \"checkout\": \"2019-01-01\"\n"
                + "    },\n"
                + "    \"additionalneeds\": \"Breakfast\"\n"
                + "}";

        Response createResponse = given()
                    .baseUri(BASE_URI)
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .body(createBody)
                .when()
                    .post("/booking")
                .then()
                    .assertThat().statusCode(200)
                    .extract().response();

        bookingId = createResponse.jsonPath().getInt("bookingid");
        System.out.println("Booking created with ID: " + bookingId);
    }

    @Test
    public void patchBookingWithBasicAuth() {

        // Step 9: Partial update body — only firstname and totalprice changed
        String patchBody = "{\n"
                + "    \"firstname\": \"John\",\n"
                + "    \"totalprice\": 500\n"
                + "}";

        // Step 6-10: PATCH /booking/:id with Basic Auth
        Response response = given()
                    .baseUri(BASE_URI)
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .auth().basic(USERNAME, PASSWORD)
                    .body(patchBody)
                .when()
                    .patch("/booking/" + bookingId)
                .then()
                    .assertThat()
                        .statusCode(200)
                        .body("firstname",  equalTo("John"))
                        .body("totalprice", equalTo(500))
                        // Unchanged fields remain the same
                        .body("lastname",   equalTo("Brown"))
                    .extract()
                    .response();

        System.out.println("========================================");
        System.out.println(" PATCH /booking/" + bookingId + " with Basic Auth");
        System.out.println("========================================");
        System.out.println("URL                   : " + BASE_URI + "/booking/" + bookingId);
        System.out.println("Method                : PATCH");
        System.out.println("Auth                  : Basic Auth (" + USERNAME + " / " + PASSWORD + ")");
        System.out.println("Fields Patched        : firstname=John, totalprice=500");
        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Body         : " + response.getBody().asPrettyString());

        Assert.assertEquals(response.getStatusCode(), 200);
        Assert.assertEquals(response.jsonPath().getString("firstname"), "John");
        Assert.assertEquals(response.jsonPath().getInt("totalprice"), 500);
        Assert.assertEquals(response.jsonPath().getString("lastname"), "Brown",
                "Unchanged field 'lastname' should still be Brown!");
        System.out.println("PATCH request verified successfully.");
    }
}
