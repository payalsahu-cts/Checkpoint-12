package com.api.tests;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;

/**
 * Test Class : GetResponseWithBaseURI
 *
 * Scenario   : Get the API response with baseURI in REST Assured
 * API        : https://jsonplaceholder.typicode.com/posts
 * Method     : GET
 * Path Param : id = 5  →  /posts/5
 *
 * Steps covered:
 * Step 1 - Maven project with TestNG & REST Assured dependencies (pom.xml)
 * Step 2 - Java class created in REST Assured framework (this file)
 * Step 3 - GET request to https://jsonplaceholder.typicode.com/posts
 * Step 4 - Path parameter: id = 5
 * Step 5 - Pass the endpoint URL using baseURI (RestAssured.baseURI)
 * Step 6 - Print all values of the response in the console
 *
 * HOW baseURI WORKS:
 *   RestAssured.baseURI = "https://jsonplaceholder.typicode.com"
 *   Every .get("/posts/{id}") then automatically prefixes this base.
 *   Full URL resolved → https://jsonplaceholder.typicode.com/posts/5
 *
 * THREE WAYS to set baseURI (all demonstrated):
 *   1. RestAssured.baseURI  (global static — applies to all tests)
 *   2. RequestSpecification (per-spec — scoped override)
 *   3. given().baseUri()    (per-request inline)
 */
public class GetResponseWithBaseURI {

    // ----------------------------------------------------------------
    // Constants
    // ----------------------------------------------------------------
    private static final String BASE_URI        = "https://jsonplaceholder.typicode.com";
    private static final String ENDPOINT        = "/posts/{id}";
    private static final String PATH_PARAM_NAME = "id";
    private static final int    PATH_PARAM_VAL  = 5;

    // ----------------------------------------------------------------
    // Step 2 & Step 5 : Setup — set RestAssured.baseURI globally
    // ----------------------------------------------------------------
    @BeforeClass
    public void setUp() {

        // ============================================================
        // STEP 5 : Pass the endpoint URL using baseURI
        // RestAssured.baseURI is a global static field.
        // Once set here, ALL tests in this class use it automatically.
        // ============================================================
        RestAssured.baseURI = BASE_URI;

        System.out.println("================================================================");
        System.out.println("  REST Assured Framework - Get API Response with Base URI       ");
        System.out.println("================================================================");
        System.out.println("Step 5  → RestAssured.baseURI set to : " + RestAssured.baseURI);
        System.out.println("Endpoint                             : " + ENDPOINT);
        System.out.println("Path Param                           : " + PATH_PARAM_NAME + " = " + PATH_PARAM_VAL);
        System.out.println("Resolved Full URL                    : " + BASE_URI + "/posts/" + PATH_PARAM_VAL);
        System.out.println();
        System.out.println("NOTE: baseURI is the host. Only the path /posts/{id} is needed");
        System.out.println("      in get() — REST Assured joins them automatically.");
    }

    // ================================================================
    // Step 3, 4, 5, 6 — Global RestAssured.baseURI (primary approach)
    // ================================================================

    /**
     * TEST 1 : Use global RestAssured.baseURI set in @BeforeClass, print all values
     *
     * Step 3 - GET /posts/{id}       (baseURI prefixed automatically)
     * Step 4 - pathParam("id", 5)
     * Step 5 - RestAssured.baseURI already set in setUp()
     * Step 6 - Print all JSON field values in a formatted table
     */
    @Test(priority = 1, description = "Global RestAssured.baseURI + pathParam id=5 — print all values")
    public void getResponse_GlobalBaseURI_PrintAllValues() {

        System.out.println("\n[TEST 1] Global RestAssured.baseURI — Print All Field Values");
        System.out.println("--------------------------------------------------------------");
        System.out.println("Active baseURI : " + RestAssured.baseURI);

        // Step 3: GET /posts/{id}  — baseURI from setUp() prefixed automatically
        // Step 4: pathParam id=5
        // Step 5: RestAssured.baseURI set in @BeforeClass
        Response response =
            given()
                .pathParam(PATH_PARAM_NAME, PATH_PARAM_VAL)   // Step 4
                .header("Accept", "application/json")
                .log().all()
            .when()
                .get(ENDPOINT)                                 // Step 3: only the path needed
            .then()
                .log().all()
                .statusCode(200)
                .extract()
                .response();

        // Step 6: Parse and print all field values
        JsonPath jp = response.jsonPath();

        int    userId = jp.getInt("userId");
        int    id     = jp.getInt("id");
        String title  = jp.getString("title");
        String body   = jp.getString("body");

        System.out.println("\n--- Response Values for baseURI + /posts/" + PATH_PARAM_VAL + " ---");
        System.out.println("+------------+--------------------------------------------------+");
        System.out.printf( "| %-10s | %-48s |%n", "Field", "Value");
        System.out.println("+------------+--------------------------------------------------+");
        System.out.printf( "| %-10s | %-48s |%n", "userId", userId);
        System.out.printf( "| %-10s | %-48s |%n", "id",     id);
        System.out.printf( "| %-10s | %-48s |%n", "title",  title);
        System.out.printf( "| %-10s | %-48s |%n", "body",
                           body.length() > 48 ? body.substring(0, 45) + "..." : body);
        System.out.println("+------------+--------------------------------------------------+");

        System.out.println("\n--- Full Field Values ---");
        System.out.println("userId : " + userId);
        System.out.println("id     : " + id);
        System.out.println("title  : " + title);
        System.out.println("body   : " + body);

        // Assertions
        Assert.assertEquals(id, PATH_PARAM_VAL, "id should match path param value 5");
        Assert.assertNotNull(title, "title should not be null");
        Assert.assertNotNull(body,  "body should not be null");

        System.out.println("\n[TEST 1] PASSED — baseURI + path param id=5 resolved and all values printed");
    }

    // ================================================================
    // Step 3, 4, 5, 6 — baseURI set inline via given().baseUri()
    // ================================================================

    /**
     * TEST 2 : Set baseUri inline per-request using given().baseUri()
     *
     * Step 3 - GET /posts/{id}
     * Step 4 - pathParam("id", 5)
     * Step 5 - .baseUri("https://jsonplaceholder.typicode.com") inline in given()
     * Step 6 - Print raw pretty JSON
     */
    @Test(priority = 2, description = "Inline given().baseUri() + pathParam id=5 — print raw JSON")
    public void getResponse_InlineBaseUri_PrintRawJSON() {

        System.out.println("\n[TEST 2] Inline given().baseUri() — Print Raw JSON");
        System.out.println("---------------------------------------------------");

        // Step 3, 4, 5 — all inside given()
        Response response =
            given()
                .baseUri(BASE_URI)                            // Step 5: inline per-request baseUri
                .pathParam(PATH_PARAM_NAME, PATH_PARAM_VAL)  // Step 4: id=5
                .header("Accept", "application/json")
                .log().uri()
            .when()
                .get(ENDPOINT)                                // Step 3: GET /posts/{id}
            .then()
                .statusCode(200)
                .extract()
                .response();

        // Step 6: Print raw pretty JSON
        System.out.println("\n--- Raw JSON Response (baseUri inline, id=5) ---");
        System.out.println(response.getBody().asPrettyString());

        System.out.println("\n--- Resolved URL Breakdown ---");
        System.out.println("baseUri   : " + BASE_URI);
        System.out.println("path      : /posts/" + PATH_PARAM_VAL);
        System.out.println("full URL  : " + BASE_URI + "/posts/" + PATH_PARAM_VAL);

        Assert.assertEquals(response.jsonPath().getInt("id"), PATH_PARAM_VAL);

        System.out.println("\n[TEST 2] PASSED — Inline baseUri set and raw JSON printed");
    }

    // ================================================================
    // Step 3, 4, 5, 6 — baseURI via RequestSpecification (reusable spec)
    // ================================================================

    /**
     * TEST 3 : Set baseURI via a reusable RequestSpecification
     *
     * Step 3 - GET /posts/{id}
     * Step 4 - pathParam("id", 5)
     * Step 5 - RequestSpecification with baseUri set — reusable across tests
     * Step 6 - Print each field with console labels
     */
    @Test(priority = 3, description = "RequestSpecification baseUri + pathParam id=5 — print labelled fields")
    public void getResponse_RequestSpecBaseUri_PrintLabelledFields() {

        System.out.println("\n[TEST 3] RequestSpecification with baseUri — Print Labelled Fields");
        System.out.println("-------------------------------------------------------------------");

        // Step 5: Build a reusable RequestSpecification with baseUri
        RequestSpecification requestSpec =
            given()
                .baseUri(BASE_URI)                            // Step 5: baseUri in spec
                .header("Accept", "application/json")
                .pathParam(PATH_PARAM_NAME, PATH_PARAM_VAL);  // Step 4: id=5

        System.out.println("RequestSpec baseUri : " + BASE_URI);
        System.out.println("Path param          : " + PATH_PARAM_NAME + " = " + PATH_PARAM_VAL);

        // Step 3: GET using the spec
        Response response =
            requestSpec
            .when()
                .get(ENDPOINT)                                // Step 3: GET /posts/{id}
            .then()
                .statusCode(200)
                .extract()
                .response();

        // Step 6: Print labelled field values
        JsonPath jp = response.jsonPath();

        System.out.println("\n--- Labelled Field Values (RequestSpec baseUri) ---");
        System.out.println("  [Field: userId]  → " + jp.getInt("userId"));
        System.out.println("  [Field: id    ]  → " + jp.getInt("id")    + "  ← matches path param id=" + PATH_PARAM_VAL);
        System.out.println("  [Field: title ]  → " + jp.getString("title"));
        System.out.println("  [Field: body  ]  → " + jp.getString("body"));

        Assert.assertEquals(jp.getInt("id"), PATH_PARAM_VAL, "id should be 5");

        System.out.println("\n[TEST 3] PASSED — RequestSpecification baseUri resolved and fields printed");
    }

    // ================================================================
    // Step 3, 4, 5, 6 — Jackson ObjectMapper full tree print
    // ================================================================

    /**
     * TEST 4 : Full JSON tree via Jackson + demonstrate baseURI resolution
     *
     * Step 3 - GET /posts/{id}
     * Step 4 - pathParam("id", 5)
     * Step 5 - RestAssured.baseURI (global, set in setUp)
     * Step 6 - Print full JSON tree using Jackson + URL breakdown summary
     */
    @Test(priority = 4, description = "Global baseURI + pathParam id=5, Jackson full tree print with URL summary")
    public void getResponse_BaseURI_JacksonFullTree() throws Exception {

        System.out.println("\n[TEST 4] Global baseURI + Jackson Full Tree Print");
        System.out.println("-------------------------------------------------");
        System.out.println("RestAssured.baseURI : " + RestAssured.baseURI);

        // Step 3, 4, 5: GET with global baseURI + pathParam
        String responseBody =
            given()
                .pathParam(PATH_PARAM_NAME, PATH_PARAM_VAL)  // Step 4
                .log().uri()
            .when()
                .get(ENDPOINT)                               // Step 3
            .then()
                .statusCode(200)
                .extract()
                .asString();

        // Step 6: Parse with Jackson and print every node
        ObjectMapper mapper   = new ObjectMapper();
        JsonNode     rootNode = mapper.readTree(responseBody);

        System.out.println("\n--- Full JSON Tree (Jackson) for /posts/" + PATH_PARAM_VAL + " ---");
        System.out.println("{");
        rootNode.fields().forEachRemaining(field ->
            System.out.printf("    %-10s : %s%n", field.getKey(), field.getValue().asText())
        );
        System.out.println("}");

        // URL Resolution Summary
        System.out.println("\n--- baseURI Resolution Summary ---");
        System.out.println("RestAssured.baseURI  : " + BASE_URI);
        System.out.println("Endpoint (path only) : /posts/{id}");
        System.out.println("Path Param id        : " + PATH_PARAM_VAL);
        System.out.println("Resolved Full URL    : " + BASE_URI + "/posts/" + PATH_PARAM_VAL);
        System.out.println("id in Response       : " + rootNode.path("id").asInt());
        System.out.println("title in Response    : " + rootNode.path("title").asText());

        Assert.assertEquals(rootNode.path("id").asInt(), PATH_PARAM_VAL,
            "id in response must equal path param " + PATH_PARAM_VAL);

        System.out.println("\n[TEST 4] PASSED — baseURI + Jackson full tree printed with URL summary");
    }
}
