# REST Assured - Get API Response with Base URI

## Scenario: Get API Response with Base URI

| Step | Description |
|------|-------------|
| 1 | Maven project with TestNG & REST Assured dependencies |
| 2 | Java class created in REST Assured framework |
| 3 | GET request to `https://jsonplaceholder.typicode.com/posts` |
| 4 | Path parameter: `id = 5` |
| 5 | Pass the endpoint URL using `baseURI` |
| 6 | Print all values of the response in the console |

---

## ⚡ How baseURI Works

```
RestAssured.baseURI = "https://jsonplaceholder.typicode.com"
                                    +
               .get("/posts/{id}")  with  pathParam("id", 5)
                                    ↓
        https://jsonplaceholder.typicode.com/posts/5
```

You only pass the **path** (`/posts/5`) in `.get()` — REST Assured automatically prepends `baseURI`.

---

## Three Ways to Set baseURI (all demonstrated)

| Method | Code | Scope |
|--------|------|-------|
| **Global static** | `RestAssured.baseURI = "..."` in `@BeforeClass` | Applies to ALL tests in class |
| **Inline per-request** | `given().baseUri("...")` | Applies to ONE test only |
| **RequestSpecification** | `RequestSpecification spec = given().baseUri("...")` | Reusable across multiple tests |

---

## Project Structure

```
baseuri-project/
├── pom.xml                              ← Maven dependencies
├── testng.xml                           ← TestNG suite configuration
├── README.md
└── src/
    └── test/
        └── java/
            └── com/api/tests/
                └── GetResponseWithBaseURI.java  ← Main test class
```

---

## API Details

- **Base URI:** `https://jsonplaceholder.typicode.com`
- **Endpoint:** `/posts/{id}`
- **Resolved URL:** `https://jsonplaceholder.typicode.com/posts/5`
- **Method:** GET
- **Path Param:** `id = 5`

### Expected Response
```json
{
    "userId": 1,
    "id": 5,
    "title": "nesciunt quas odio",
    "body": "repudiandae veniam quaerat sunt sed..."
}
```

---

## Test Cases

| Test Method | baseURI Style (Step 5) | Step 6 Output |
|-------------|----------------------|---------------|
| `getResponse_GlobalBaseURI_PrintAllValues` | `RestAssured.baseURI` (global) | Formatted table + full field values |
| `getResponse_InlineBaseUri_PrintRawJSON` | `given().baseUri()` (inline) | Raw pretty JSON + URL breakdown |
| `getResponse_RequestSpecBaseUri_PrintLabelledFields` | `RequestSpecification` (reusable spec) | Labelled fields with `[Field: x]` |
| `getResponse_BaseURI_JacksonFullTree` | `RestAssured.baseURI` + Jackson | Full JSON tree + URL resolution summary |

---

## How to Run

```bash
mvn clean test
```

Or in IDE: Right-click `testng.xml` → **Run**

---

## Sample Console Output (TEST 1)

```
Step 5 → RestAssured.baseURI set to : https://jsonplaceholder.typicode.com

--- Response Values for baseURI + /posts/5 ---
+------------+--------------------------------------------------+
| Field      | Value                                            |
+------------+--------------------------------------------------+
| userId     | 1                                                |
| id         | 5                                                |
| title      | nesciunt quas odio                               |
| body       | repudiandae veniam quaerat sunt sed...           |
+------------+--------------------------------------------------+

--- Full Field Values ---
userId : 1
id     : 5
title  : nesciunt quas odio
body   : repudiandae veniam quaerat sunt sed
alias aut fugiat sit autem mollitia...
```
