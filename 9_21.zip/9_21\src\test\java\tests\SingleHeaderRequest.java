package tests;

import io.restassured.response.Response;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.notNullValue;

public class SingleHeaderRequest {

    @Test
    public void getResponseWithSingleHeader() {

        // Step 1 & 3: Request body
        String requestBody = "{\n"
                + "    \"username\" : \"admin\",\n"
                + "    \"password\" : \"password123\"\n"
                + "}";

        // Step 2, 4: POST to /auth with single header Content-Type: application/json
        Response response = given()
                    .baseUri("https://restful-booker.herokuapp.com")
                    .header("Content-Type", "application/json")
                    .body(requestBody)
                .when()
                    .post("/auth")
                .then()
                    .assertThat()
                        .statusCode(200)
                        // Step 5: Validate token exists in response
                        .body("token", notNullValue())
                    .extract()
                    .response();

        // Step 5: Print the response in the console
        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Body         : " + response.getBody().asPrettyString());
        System.out.println("Auth Token            : " + response.jsonPath().getString("token"));
        System.out.println("Header Sent           : Content-Type = application/json");
    }
}
