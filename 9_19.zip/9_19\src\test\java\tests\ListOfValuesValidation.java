package tests;

import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.Matchers.hasSize;

public class ListOfValuesValidation {

    @Test
    public void validateListOfValuesInResponse() {

        String requestBody = "{\n"
                + "    \"firstname\": \"Jim\",\n"
                + "    \"lastname\": \"Brown\",\n"
                + "    \"totalprice\": 111,\n"
                + "    \"depositpaid\": true,\n"
                + "    \"bookingdates\": {\n"
                + "        \"checkin\": \"2018-01-01\",\n"
                + "        \"checkout\": \"2019-01-01\"\n"
                + "    },\n"
                + "    \"additionalneeds\": \"Breakfast\"\n"
                + "}";

        // Step 1: POST to create a booking
        Response postResponse = given()
                    .baseUri("https://restful-booker.herokuapp.com")
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .body(requestBody)
                .when()
                    .post("/booking")
                .then()
                    .assertThat()
                        .statusCode(200)
                    .extract()
                    .response();

        int createdBookingId = postResponse.jsonPath().getInt("bookingid");

        // Step 2: GET all bookings — returns a list of {bookingid} objects
        // Convert the response into a JsonPath document and validate the list
        Response listResponse = given()
                    .baseUri("https://restful-booker.herokuapp.com")
                    .accept(ContentType.JSON)
                .when()
                    .get("/booking")
                .then()
                    .assertThat()
                        .statusCode(200)
                        // Validate the list has more than 0 items
                        .body("$",          hasSize(org.hamcrest.Matchers.greaterThan(0)))
                        // Validate "bookingid" key exists in each list item
                        .body("bookingid",  hasItem(createdBookingId))
                    .extract()
                    .response();

        // Convert the full response body into a JsonPath document
        JsonPath jsonPathDoc = new JsonPath(listResponse.getBody().asString());

        // Extract the full list of booking IDs as a Java List
        List<Integer> allBookingIds = jsonPathDoc.getList("bookingid");

        // Extract the list of all booking objects as a List of Maps
        List<Map<String, Object>> allBookings = jsonPathDoc.getList("$");

        // Step 3: Print the response in the console
        System.out.println("POST Response Body            : " + postResponse.getBody().asPrettyString());
        System.out.println("Created Booking ID            : " + createdBookingId);
        System.out.println("------ List of Values Validation ------");
        System.out.println("Total bookings in list        : " + allBookings.size());
        System.out.println("All Booking IDs               : " + allBookingIds);
        System.out.println("Created ID exists in list     : " + allBookingIds.contains(createdBookingId));
        System.out.println("First booking object          : " + allBookings.get(0));
        System.out.println("Last  booking object          : " + allBookings.get(allBookings.size() - 1));
    }
}
