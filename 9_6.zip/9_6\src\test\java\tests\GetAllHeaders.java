package tests;

import io.restassured.http.ContentType;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;

public class GetAllHeaders {

    @Test
    public void getAllHeadersFromResponse() {

        String requestBody = "{\n"
                + "    \"firstname\": \"Jim\",\n"
                + "    \"lastname\": \"Brown\",\n"
                + "    \"totalprice\": 111,\n"
                + "    \"depositpaid\": true,\n"
                + "    \"bookingdates\": {\n"
                + "        \"checkin\": \"2018-01-01\",\n"
                + "        \"checkout\": \"2019-01-01\"\n"
                + "    },\n"
                + "    \"additionalneeds\": \"Breakfast\"\n"
                + "}";

        // Step 1: POST request and extract response
        Response response = given()
                    .baseUri("https://restful-booker.herokuapp.com")
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .body(requestBody)
                .when()
                    .post("/booking")
                .then()
                    .assertThat()
                        .statusCode(200)
                    .extract()
                    .response();

        // Step 2: Get all headers using headers() method
        Headers allHeaders = response.headers();

        // Step 3: Print all headers in the console
        System.out.println("Response Status Code : " + response.getStatusCode());
        System.out.println("Response Body        : " + response.getBody().asPrettyString());
        System.out.println("------ All Response Headers ------");
        for (Header header : allHeaders) {
            System.out.println(header.getName() + " : " + header.getValue());
        }
    }
}
