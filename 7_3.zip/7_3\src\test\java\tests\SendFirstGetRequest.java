package tests;

import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.notNullValue;

/**
 * Scenario 3 - Sending the First API Request
 *
 * Postman steps automated:
 *   Step 7: Method = GET
 *   Step 8: URL   = https://simple-tool-rental-api.glitch.me/status
 *   Step 9: Click Send
 */
public class SendFirstGetRequest {

    @Test
    public void sendFirstGetRequest() {

        // Step 7-9: GET https://simple-tool-rental-api.glitch.me/status
        Response response = given()
                    .baseUri("https://simple-tool-rental-api.glitch.me")
                    .accept("application/json")
                .when()
                    .get("/status")
                .then()
                    .assertThat()
                        .statusCode(200)
                        .body("status", notNullValue())
                    .extract()
                    .response();

        System.out.println("========================================");
        System.out.println(" First API Request - GET /status");
        System.out.println("========================================");
        System.out.println("URL                   : https://simple-tool-rental-api.glitch.me/status");
        System.out.println("Method                : GET");
        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Body         : " + response.getBody().asPrettyString());

        Assert.assertEquals(response.getStatusCode(), 200,
                "Expected status 200 but got: " + response.getStatusCode());
        System.out.println("First GET Request sent and verified successfully.");
    }
}
