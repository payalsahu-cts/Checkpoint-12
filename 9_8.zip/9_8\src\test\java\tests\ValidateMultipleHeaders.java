package tests;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

public class ValidateMultipleHeaders {

    @Test
    public void validateMultipleHeadersAtOnce() {

        String requestBody = "{\n"
                + "    \"firstname\": \"Jim\",\n"
                + "    \"lastname\": \"Brown\",\n"
                + "    \"totalprice\": 111,\n"
                + "    \"depositpaid\": true,\n"
                + "    \"bookingdates\": {\n"
                + "        \"checkin\": \"2018-01-01\",\n"
                + "        \"checkout\": \"2019-01-01\"\n"
                + "    },\n"
                + "    \"additionalneeds\": \"Breakfast\"\n"
                + "}";

        // Step 1: POST request and extract response
        Response response = given()
                    .baseUri("https://restful-booker.herokuapp.com")
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .body(requestBody)
                .when()
                    .post("/booking")
                .then()
                    .assertThat()
                        .statusCode(200)
                        // Step 2: Validate multiple headers at once using
                        // headers(String headerName, Matcher<?> matcher, Object... additionalHeaderNameMatcherPairs)
                        .headers(
                            "Content-Type", containsString("application/json"),
                            "Server",       equalTo("Cowboy"),
                            "Connection",   notNullValue()
                        )
                    .extract()
                    .response();

        // Step 3: Print the response in the console
        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Body         : " + response.getBody().asPrettyString());
        System.out.println("------ Validated Multiple Headers ------");
        System.out.println("Content-Type  : " + response.header("Content-Type"));
        System.out.println("Server        : " + response.header("Server"));
        System.out.println("Connection    : " + response.header("Connection"));
    }
}
