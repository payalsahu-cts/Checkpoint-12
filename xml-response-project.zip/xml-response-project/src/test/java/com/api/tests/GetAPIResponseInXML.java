package com.api.tests;

import io.restassured.RestAssured;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.ByteArrayInputStream;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import static io.restassured.RestAssured.*;

/**
 * Test Class : GetAPIResponseInXML
 *
 * Scenario   : Get the API response in XML in REST Assured
 * API        : https://restful-booker.herokuapp.com/booking/119
 * Method     : GET
 *
 * Steps covered:
 * Step 1 - Maven project with TestNG & REST Assured dependencies (pom.xml)
 * Step 2 - Java class created in REST Assured framework (this file)
 * Step 3 - GET request to https://restful-booker.herokuapp.com/booking/119
 * Step 4 - Content-Type: application/xml  |  Accept: application/xml
 * Step 5 - Print all values of the XML response in the console
 *
 * Expected XML Response:
 * <booking>
 *   <firstname>...</firstname>
 *   <lastname>...</lastname>
 *   <totalprice>...</totalprice>
 *   <depositpaid>...</depositpaid>
 *   <bookingdates>
 *     <checkin>...</checkin>
 *     <checkout>...</checkout>
 *   </bookingdates>
 *   <additionalneeds>...</additionalneeds>
 * </booking>
 */
public class GetAPIResponseInXML {

    // ----------------------------------------------------------------
    // Constants
    // ----------------------------------------------------------------
    private static final String BASE_URL  = "https://restful-booker.herokuapp.com";
    private static final String ENDPOINT  = "/booking/119";
    private static final int    BOOKING_ID = 119;

    // ----------------------------------------------------------------
    // Step 2 : Setup — configure base URI before tests run
    // ----------------------------------------------------------------
    @BeforeClass
    public void setUp() {
        RestAssured.baseURI = BASE_URL;
        System.out.println("=======================================================");
        System.out.println("  REST Assured Framework - Get API Response in XML     ");
        System.out.println("=======================================================");
        System.out.println("Base URI   : " + BASE_URL);
        System.out.println("Endpoint   : " + ENDPOINT);
        System.out.println("Booking ID : " + BOOKING_ID);
    }

    // ================================================================
    // Step 3, 4, 5 — GET + XML headers + print raw XML response
    // ================================================================

    /**
     * TEST 1 : Fetch and print the raw XML response body
     *
     * Step 3 - GET /booking/119
     * Step 4 - Content-Type: application/xml | Accept: application/xml
     * Step 5 - Print the raw XML response string to console
     */
    @Test(priority = 1, description = "GET booking/119 with XML headers and print raw XML response")
    public void getAndPrintRawXMLResponse() {

        System.out.println("\n[TEST 1] Fetch and Print Raw XML Response");
        System.out.println("------------------------------------------");

        // Step 3: GET /booking/119
        // Step 4: Set Content-Type and Accept to application/xml
        Response response =
            given()
                .contentType("application/xml")        // Step 4: Content-Type header
                .accept("application/xml")             // Step 4: Accept header
                .log().all()                           // Log full request
            .when()
                .get(ENDPOINT)                         // Step 3: GET call
            .then()
                .log().all()                           // Log full response
                .statusCode(200)
                .extract()
                .response();

        // Step 5: Print the raw XML response body
        String xmlBody = response.getBody().asString();

        System.out.println("\n--- Raw XML Response Body ---");
        System.out.println(xmlBody);
        System.out.println("-----------------------------");

        Assert.assertNotNull(xmlBody, "XML response body should not be null");
        Assert.assertTrue(xmlBody.contains("booking"), "Response should contain 'booking' XML element");

        System.out.println("\n[TEST 1] PASSED - Raw XML response printed successfully");
    }

    // ================================================================
    // Step 3, 4, 5 — Parse XML with REST Assured XmlPath & print each field
    // ================================================================

    /**
     * TEST 2 : Parse XML using REST Assured XmlPath and print each field
     *
     * Step 3 - GET /booking/119
     * Step 4 - Content-Type: application/xml | Accept: application/xml
     * Step 5 - Extract and print each XML field value using XmlPath (GPath)
     */
    @Test(priority = 2, description = "Parse XML response using XmlPath and print all field values")
    public void getAndPrintXML_UsingXmlPath() {

        System.out.println("\n[TEST 2] Parse & Print XML using REST Assured XmlPath");
        System.out.println("------------------------------------------------------");

        // Step 3 & 4: GET with XML headers
        Response response =
            given()
                .contentType("application/xml")        // Step 4: Content-Type
                .accept("application/xml")             // Step 4: Accept
                .log().uri()
            .when()
                .get(ENDPOINT)                         // Step 3: GET
            .then()
                .statusCode(200)
                .extract()
                .response();

        // Step 4: Parse response into XmlPath
        XmlPath xmlPath = response.xmlPath();

        // Step 5: Extract and print each field value
        String firstName       = xmlPath.getString("booking.firstname");
        String lastName        = xmlPath.getString("booking.lastname");
        String totalPrice      = xmlPath.getString("booking.totalprice");
        String depositPaid     = xmlPath.getString("booking.depositpaid");
        String checkIn         = xmlPath.getString("booking.bookingdates.checkin");
        String checkOut        = xmlPath.getString("booking.bookingdates.checkout");
        String additionalNeeds = xmlPath.getString("booking.additionalneeds");

        System.out.println("\n--- Parsed XML Field Values ---");
        System.out.println("+-----------------------+------------------------------+");
        System.out.printf("| %-21s | %-28s |%n", "Field",          "Value");
        System.out.println("+-----------------------+------------------------------+");
        System.out.printf("| %-21s | %-28s |%n", "firstname",       firstName);
        System.out.printf("| %-21s | %-28s |%n", "lastname",        lastName);
        System.out.printf("| %-21s | %-28s |%n", "totalprice",      totalPrice);
        System.out.printf("| %-21s | %-28s |%n", "depositpaid",     depositPaid);
        System.out.printf("| %-21s | %-28s |%n", "checkin",         checkIn);
        System.out.printf("| %-21s | %-28s |%n", "checkout",        checkOut);
        System.out.printf("| %-21s | %-28s |%n", "additionalneeds", additionalNeeds != null ? additionalNeeds : "N/A");
        System.out.println("+-----------------------+------------------------------+");

        // Assertions
        Assert.assertNotNull(firstName,   "firstname should not be null");
        Assert.assertNotNull(lastName,    "lastname should not be null");
        Assert.assertNotNull(totalPrice,  "totalprice should not be null");
        Assert.assertNotNull(depositPaid, "depositpaid should not be null");
        Assert.assertNotNull(checkIn,     "checkin should not be null");
        Assert.assertNotNull(checkOut,    "checkout should not be null");

        System.out.println("\n[TEST 2] PASSED - All XML field values parsed and printed");
    }

    // ================================================================
    // Step 3, 4, 5 — Parse XML with DOM parser & print all node values
    // ================================================================

    /**
     * TEST 3 : Parse XML using Java DOM parser and print all nodes
     *
     * Step 3 - GET /booking/119
     * Step 4 - Content-Type: application/xml | Accept: application/xml
     * Step 5 - Walk DOM tree and print every element name + text value
     */
    @Test(priority = 3, description = "Parse XML response using Java DOM parser and print all nodes")
    public void getAndPrintXML_UsingDOMParser() throws Exception {

        System.out.println("\n[TEST 3] Parse & Print XML using Java DOM Parser");
        System.out.println("-------------------------------------------------");

        // Step 3 & 4: GET with XML headers
        String xmlBody =
            given()
                .contentType("application/xml")        // Step 4: Content-Type
                .accept("application/xml")             // Step 4: Accept
                .log().uri()
            .when()
                .get(ENDPOINT)                         // Step 3: GET
            .then()
                .statusCode(200)
                .extract()
                .asString();

        // Step 4: Parse XML string into DOM Document
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder        = factory.newDocumentBuilder();
        Document document              = builder.parse(
            new ByteArrayInputStream(xmlBody.getBytes(StandardCharsets.UTF_8))
        );
        document.getDocumentElement().normalize();

        // Step 5: Print using Transformer (pretty-printed XML)
        Transformer transformer = TransformerFactory.newInstance().newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");

        StringWriter writer = new StringWriter();
        transformer.transform(new DOMSource(document), new StreamResult(writer));

        System.out.println("\n--- Pretty-Printed XML (DOM Parser) ---");
        System.out.println(writer.toString());

        // Step 5: Also print each tag + value individually
        System.out.println("--- Individual Node Values ---");
        String[] tags = {"firstname", "lastname", "totalprice", "depositpaid", "checkin", "checkout", "additionalneeds"};
        for (String tag : tags) {
            NodeList nodeList = document.getElementsByTagName(tag);
            if (nodeList.getLength() > 0) {
                String value = nodeList.item(0).getTextContent();
                System.out.printf("  %-20s : %s%n", tag, value);
            }
        }

        Assert.assertNotNull(document.getElementsByTagName("booking"), "'booking' root element should exist");

        System.out.println("\n[TEST 3] PASSED - XML parsed via DOM and all nodes printed");
    }

    // ================================================================
    // Step 3, 4, 5 — Print response headers alongside XML values
    // ================================================================

    /**
     * TEST 4 : Print response headers and XML body values together
     *
     * Step 3 - GET /booking/119
     * Step 4 - Content-Type: application/xml | Accept: application/xml
     * Step 5 - Print Content-Type header + all XML body values
     */
    @Test(priority = 4, description = "Print response headers and all XML body field values")
    public void getAndPrintHeaders_AndXMLValues() {

        System.out.println("\n[TEST 4] Print Response Headers + XML Body Values");
        System.out.println("--------------------------------------------------");

        // Step 3 & 4: GET with XML headers
        Response response =
            given()
                .contentType("application/xml")        // Step 4: Content-Type
                .accept("application/xml")             // Step 4: Accept
                .log().uri()
            .when()
                .get(ENDPOINT)                         // Step 3: GET
            .then()
                .statusCode(200)
                .extract()
                .response();

        // Step 5: Print response metadata
        System.out.println("\n--- Response Metadata ---");
        System.out.println("Status Code    : " + response.getStatusCode());
        System.out.println("Status Line    : " + response.getStatusLine());
        System.out.println("Content-Type   : " + response.getContentType());
        System.out.println("Response Time  : " + response.getTime() + " ms");

        // Step 5: Parse and print all XML field values
        XmlPath xmlPath = response.xmlPath();

        System.out.println("\n--- XML Response Values ---");
        System.out.println("firstname        : " + xmlPath.getString("booking.firstname"));
        System.out.println("lastname         : " + xmlPath.getString("booking.lastname"));
        System.out.println("totalprice       : " + xmlPath.getString("booking.totalprice"));
        System.out.println("depositpaid      : " + xmlPath.getString("booking.depositpaid"));
        System.out.println("checkin          : " + xmlPath.getString("booking.bookingdates.checkin"));
        System.out.println("checkout         : " + xmlPath.getString("booking.bookingdates.checkout"));
        System.out.println("additionalneeds  : " + xmlPath.getString("booking.additionalneeds"));

        // Verify content type is XML
        Assert.assertTrue(
            response.getContentType().contains("xml"),
            "Content-Type should contain 'xml' but got: " + response.getContentType()
        );

        System.out.println("\n[TEST 4] PASSED - Headers and XML values printed successfully");
    }
}
