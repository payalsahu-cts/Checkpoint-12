# REST Assured - Get API Response in XML

## Scenario: Get the API Response in XML in REST Assured

| Step | Description |
|------|-------------|
| 1 | Maven project with TestNG & REST Assured dependencies |
| 2 | Java class created in REST Assured framework |
| 3 | GET request to `https://restful-booker.herokuapp.com/booking/119` |
| 4 | Content-Type: `application/xml` \| Accept: `application/xml` |
| 5 | Print all values of the XML response in the console |

---

## Project Structure

```
xml-response-project/
├── pom.xml                          ← Maven dependencies
├── testng.xml                       ← TestNG suite configuration
├── README.md
└── src/
    └── test/
        └── java/
            └── com/api/tests/
                └── GetAPIResponseInXML.java   ← Main test class
```

---

## API Details

- **URL:** `https://restful-booker.herokuapp.com/booking/119`
- **Method:** GET
- **Content-Type:** `application/xml`
- **Accept:** `application/xml`

### Expected XML Response
```xml
<booking>
    <firstname>John</firstname>
    <lastname>Smith</lastname>
    <totalprice>111</totalprice>
    <depositpaid>true</depositpaid>
    <bookingdates>
        <checkin>2018-01-01</checkin>
        <checkout>2019-01-01</checkout>
    </bookingdates>
    <additionalneeds>Breakfast</additionalneeds>
</booking>
```

---

## Dependencies Used

| Library | Version | Purpose |
|---------|---------|---------|
| REST Assured | 5.3.2 | API testing framework |
| rest-assured xml-path | 5.3.2 | XmlPath / GPath XML parsing |
| TestNG | 7.8.0 | Test runner & assertions |
| Jackson Databind | 2.15.2 | JSON/XML deserialization |
| Jackson Dataformat XML | 2.15.2 | XML format support |
| JAXB API | 2.3.1 | XML binding |

---

## Test Cases

| Test Method | Parse Method (Step 4) | Print Output (Step 5) |
|-------------|----------------------|----------------------|
| `getAndPrintRawXMLResponse` | Raw string body | Raw XML string as-is |
| `getAndPrintXML_UsingXmlPath` | REST Assured `XmlPath` (GPath) | Formatted table of all fields |
| `getAndPrintXML_UsingDOMParser` | Java `DOM DocumentBuilder` | Pretty-printed XML + node list |
| `getAndPrintHeaders_AndXMLValues` | `XmlPath` + response metadata | Headers + all XML field values |

---

## How to Run

```bash
mvn clean test
```

Or in IDE: Right-click `testng.xml` → **Run**

---

## Sample Console Output (TEST 2)

```
--- Parsed XML Field Values ---
+-----------------------+------------------------------+
| Field                 | Value                        |
+-----------------------+------------------------------+
| firstname             | John                         |
| lastname              | Smith                        |
| totalprice            | 111                          |
| depositpaid           | true                         |
| checkin               | 2018-01-01                   |
| checkout              | 2019-01-01                   |
| additionalneeds       | Breakfast                    |
+-----------------------+------------------------------+
```
