# REST Assured - Get API Response with Single Query Parameter

## Scenario: Get API Response with Single Query Parameter

| Step | Description |
|------|-------------|
| 1 | Maven project with TestNG & REST Assured dependencies |
| 2 | Java class created in REST Assured framework |
| 3 | GET request to `https://reqres.in/api/users` |
| 4 | Query parameter: `page=2` |
| 5 | Print all values of the response in the console |

---

## Project Structure

```
query-param-project/
├── pom.xml                              ← Maven dependencies
├── testng.xml                           ← TestNG suite configuration
├── README.md
└── src/
    └── test/
        └── java/
            └── com/api/tests/
                └── GetResponseWithSingleQueryParam.java  ← Main test class
```

---

## API Details

- **URL:** `https://reqres.in/api/users?page=2`
- **Method:** GET
- **Query Param:** `page=2`

### Expected Response
```json
{
    "page": 2,
    "per_page": 6,
    "total": 12,
    "total_pages": 2,
    "data": [
        {
            "id": 7,
            "email": "michael.lawson@reqres.in",
            "first_name": "Michael",
            "last_name": "Lawson",
            "avatar": "https://reqres.in/img/faces/7-image.jpg"
        }
    ],
    "support": {
        "url": "https://reqres.in/#support-heading",
        "text": "To keep ReqRes free..."
    }
}
```

---

## Three Ways to Pass Query Parameters (all demonstrated)

| Method | Code | Use Case |
|--------|------|----------|
| `.queryParam()` | `.queryParam("page", 2)` | Recommended — explicit & readable |
| `.param()` | `.param("page", 2)` | Shorthand for GET requests |
| Inline URL | `.get("/api/users?page=2")` | Quick one-liners |

---

## Test Cases

| Test Method | Query Param Style | Step 5 Output |
|-------------|------------------|---------------|
| `getResponseWithQueryParam_AndPrintValues` | `.queryParam()` | Pagination + all user fields + support block |
| `getResponseWithParam_Shorthand` | `.param()` | Raw JSON + page confirmation |
| `getResponseWithParamInURL_PrintNames` | Inline in URL | Formatted ID, name, email table |
| `getResponseWithQueryParam_JacksonFullPrint` | `.queryParam()` + Jackson | Full JSON tree traversal |

---

## How to Run

```bash
mvn clean test
```

Or in IDE: Right-click `testng.xml` → **Run**

---

## Sample Console Output (TEST 1)

```
--- Pagination Values ---
page         : 2
per_page     : 6
total        : 12
total_pages  : 2

--- User Data Values (page=2) ---
Total Users on Page : 6

  User [1] :
    id         : 7
    email      : michael.lawson@reqres.in
    first_name : Michael
    last_name  : Lawson
    avatar     : https://reqres.in/img/faces/7-image.jpg
```
