package com.api.tests;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;

import static io.restassured.RestAssured.*;

/**
 * Test Class : GetResponseWithSingleQueryParam
 *
 * Scenario   : Get the API response with single query parameter in REST Assured
 * API        : https://reqres.in/api/users
 * Method     : GET
 * Parameter  : page=2
 *
 * Steps covered:
 * Step 1 - Maven project with TestNG & REST Assured dependencies (pom.xml)
 * Step 2 - Java class created in REST Assured framework (this file)
 * Step 3 - GET request to https://reqres.in/api/users
 * Step 4 - Query parameter: page=2
 * Step 5 - Print all values of the response in the console
 *
 * Expected Response:
 * {
 *   "page": 2,
 *   "per_page": 6,
 *   "total": 12,
 *   "total_pages": 2,
 *   "data": [
 *     { "id": 7, "email": "...", "first_name": "...", "last_name": "...", "avatar": "..." },
 *     ...
 *   ],
 *   "support": { "url": "...", "text": "..." }
 * }
 */
public class GetResponseWithSingleQueryParam {

    // ----------------------------------------------------------------
    // Constants
    // ----------------------------------------------------------------
    private static final String BASE_URL  = "https://reqres.in";
    private static final String ENDPOINT  = "/api/users";
    private static final String PARAM_KEY = "page";
    private static final int    PARAM_VAL = 2;

    // ----------------------------------------------------------------
    // Step 2 : Setup — configure base URI before tests run
    // ----------------------------------------------------------------
    @BeforeClass
    public void setUp() {
        RestAssured.baseURI = BASE_URL;
        System.out.println("================================================================");
        System.out.println("  REST Assured - Get API Response with Single Query Parameter   ");
        System.out.println("================================================================");
        System.out.println("Base URI  : " + BASE_URL);
        System.out.println("Endpoint  : " + ENDPOINT);
        System.out.println("Parameter : " + PARAM_KEY + "=" + PARAM_VAL);
        System.out.println("Full URL  : " + BASE_URL + ENDPOINT + "?" + PARAM_KEY + "=" + PARAM_VAL);
    }

    // ================================================================
    // Step 3, 4, 5 — queryParam() method (primary recommended approach)
    // ================================================================

    /**
     * TEST 1 : Pass query param using .queryParam() and print all values
     *
     * Step 3 - GET /api/users
     * Step 4 - .queryParam("page", 2)
     * Step 5 - Print all pagination fields + each user's data fields
     */
    @Test(priority = 1, description = "GET /api/users?page=2 using queryParam() and print all values")
    public void getResponseWithQueryParam_AndPrintValues() {

        System.out.println("\n[TEST 1] GET with queryParam(\"page\", 2) - Print All Values");
        System.out.println("-------------------------------------------------------------");

        // Step 3: GET /api/users
        // Step 4: Pass query parameter page=2
        Response response =
            given()
                .queryParam(PARAM_KEY, PARAM_VAL)      // Step 4: page=2
                .header("Accept", "application/json")
                .log().all()                           // Log request with query param
            .when()
                .get(ENDPOINT)                         // Step 3: GET call
            .then()
                .log().all()                           // Log full response
                .statusCode(200)
                .extract()
                .response();

        // Step 5: Parse and print all response values
        JsonPath jp = response.jsonPath();

        // --- Pagination info ---
        int    page       = jp.getInt("page");
        int    perPage    = jp.getInt("per_page");
        int    total      = jp.getInt("total");
        int    totalPages = jp.getInt("total_pages");

        System.out.println("\n--- Pagination Values ---");
        System.out.println("page         : " + page);
        System.out.println("per_page     : " + perPage);
        System.out.println("total        : " + total);
        System.out.println("total_pages  : " + totalPages);

        // --- User data list ---
        List<Map<String, Object>> dataList = jp.getList("data");

        System.out.println("\n--- User Data Values (page=2) ---");
        System.out.println("Total Users on Page : " + dataList.size());
        System.out.println();

        for (int i = 0; i < dataList.size(); i++) {
            Map<String, Object> user = dataList.get(i);
            System.out.println("  User [" + (i + 1) + "] :");
            System.out.println("    id         : " + user.get("id"));
            System.out.println("    email      : " + user.get("email"));
            System.out.println("    first_name : " + user.get("first_name"));
            System.out.println("    last_name  : " + user.get("last_name"));
            System.out.println("    avatar     : " + user.get("avatar"));
            System.out.println();
        }

        // --- Support block ---
        String supportUrl  = jp.getString("support.url");
        String supportText = jp.getString("support.text");

        System.out.println("--- Support Block ---");
        System.out.println("support.url  : " + supportUrl);
        System.out.println("support.text : " + supportText);

        // Assertions
        Assert.assertEquals(page, 2,          "Page number should be 2");
        Assert.assertFalse(dataList.isEmpty(), "User data list should not be empty");

        System.out.println("\n[TEST 1] PASSED - All response values printed successfully");
    }

    // ================================================================
    // Step 3, 4, 5 — param() shorthand method
    // ================================================================

    /**
     * TEST 2 : Pass query param using .param() shorthand
     *
     * Step 3 - GET /api/users
     * Step 4 - .param("page", 2)  [shorthand for queryParam in GET]
     * Step 5 - Print raw JSON + page number confirmation
     */
    @Test(priority = 2, description = "GET /api/users?page=2 using param() shorthand and print raw JSON")
    public void getResponseWithParam_Shorthand() {

        System.out.println("\n[TEST 2] GET with .param(\"page\", 2) Shorthand");
        System.out.println("-----------------------------------------------");

        // Step 3 & 4: GET with param() shorthand
        Response response =
            given()
                .param(PARAM_KEY, PARAM_VAL)           // Step 4: shorthand queryParam
                .log().uri()
            .when()
                .get(ENDPOINT)                         // Step 3: GET
            .then()
                .statusCode(200)
                .extract()
                .response();

        // Step 5: Print raw JSON body
        System.out.println("\n--- Raw JSON Response Body ---");
        System.out.println(response.getBody().asPrettyString());

        // Confirm page param was respected
        int returnedPage = response.jsonPath().getInt("page");
        System.out.println("\nReturned page value : " + returnedPage);
        Assert.assertEquals(returnedPage, 2, "Page should be 2");

        System.out.println("\n[TEST 2] PASSED - param() shorthand works and raw JSON printed");
    }

    // ================================================================
    // Step 3, 4, 5 — Pass param inline in URL string
    // ================================================================

    /**
     * TEST 3 : Pass query param directly in the URL string
     *
     * Step 3 - GET /api/users?page=2  (param embedded in URL)
     * Step 4 - page=2 in URL
     * Step 5 - Print each user's first_name and last_name
     */
    @Test(priority = 3, description = "GET with page=2 embedded in URL string, print first/last names")
    public void getResponseWithParamInURL_PrintNames() {

        System.out.println("\n[TEST 3] GET with page=2 Embedded in URL - Print User Names");
        System.out.println("-------------------------------------------------------------");

        // Step 3 & 4: param embedded directly in URL
        Response response =
            given()
                .log().uri()
            .when()
                .get(ENDPOINT + "?page=2")             // Step 3 & 4 combined
            .then()
                .statusCode(200)
                .extract()
                .response();

        // Step 5: Extract and print first_name + last_name for each user
        List<String> firstNames = response.jsonPath().getList("data.first_name");
        List<String> lastNames  = response.jsonPath().getList("data.last_name");
        List<Integer> ids       = response.jsonPath().getList("data.id");
        List<String> emails     = response.jsonPath().getList("data.email");

        System.out.println("\n--- User Names on Page 2 ---");
        for (int i = 0; i < firstNames.size(); i++) {
            System.out.printf("  [%d] ID: %-4d | Name: %-20s | Email: %s%n",
                i + 1,
                ids.get(i),
                firstNames.get(i) + " " + lastNames.get(i),
                emails.get(i));
        }

        Assert.assertEquals(firstNames.size(), lastNames.size(), "Name list sizes should match");
        Assert.assertFalse(firstNames.isEmpty(), "Name list should not be empty");

        System.out.println("\n[TEST 3] PASSED - User names from page=2 printed successfully");
    }

    // ================================================================
    // Step 3, 4, 5 — Jackson ObjectMapper full parse + print
    // ================================================================

    /**
     * TEST 4 : Parse full response with Jackson ObjectMapper and print entire tree
     *
     * Step 3 - GET /api/users
     * Step 4 - queryParam page=2
     * Step 5 - Print every key-value in the JSON tree using Jackson
     */
    @Test(priority = 4, description = "Parse full response with Jackson ObjectMapper and print every value")
    public void getResponseWithQueryParam_JacksonFullPrint() throws Exception {

        System.out.println("\n[TEST 4] GET page=2 - Full JSON Tree Print via Jackson");
        System.out.println("-------------------------------------------------------");

        // Step 3 & 4: GET with queryParam
        String responseBody =
            given()
                .queryParam(PARAM_KEY, PARAM_VAL)
                .log().uri()
            .when()
                .get(ENDPOINT)
            .then()
                .statusCode(200)
                .extract()
                .asString();

        // Step 5: Parse and pretty-print using Jackson
        ObjectMapper mapper   = new ObjectMapper();
        JsonNode     rootNode = mapper.readTree(responseBody);

        System.out.println("\n--- Full Response Tree (Jackson) ---");

        // Top-level fields
        System.out.println("page        : " + rootNode.path("page").asInt());
        System.out.println("per_page    : " + rootNode.path("per_page").asInt());
        System.out.println("total       : " + rootNode.path("total").asInt());
        System.out.println("total_pages : " + rootNode.path("total_pages").asInt());

        // Data array
        JsonNode dataArray = rootNode.path("data");
        System.out.println("\ndata array  : " + dataArray.size() + " user(s)");

        dataArray.forEach(user -> {
            System.out.println("\n  {");
            user.fields().forEachRemaining(f ->
                System.out.println("    " + f.getKey() + " : " + f.getValue().asText())
            );
            System.out.println("  }");
        });

        // Support block
        JsonNode support = rootNode.path("support");
        System.out.println("\nsupport     :");
        support.fields().forEachRemaining(f ->
            System.out.println("  " + f.getKey() + " : " + f.getValue().asText())
        );

        Assert.assertTrue(rootNode.path("page").asInt() == 2, "Page should be 2");

        System.out.println("\n[TEST 4] PASSED - Full JSON tree printed via Jackson");
    }
}
