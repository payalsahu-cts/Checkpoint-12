package tests;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class USPopulationResponseSpecTest {

    private static final String BASE_URI = "https://datausa.io";
    private static final String ENDPOINT = "/api/data";

    private RequestSpecification  requestSpec;
    private ResponseSpecification responseSpec;
    private Response              response;

    // Step 3 & 4: Create RequestSpecification and ResponseSpecification @BeforeClass
    @BeforeClass
    public void setUpSpecifications() {

        // Build RequestSpecification with URI and query params
        requestSpec = new RequestSpecBuilder()
                .setBaseUri(BASE_URI)
                .setBasePath(ENDPOINT)
                .addQueryParam("drilldowns", "Nation")
                .addQueryParam("measures",   "Population")
                .addQueryParam("Year",       "2022")
                .build();

        // Build ResponseSpecification — validate status code 200 and Content-Type as JSON
        responseSpec = new ResponseSpecBuilder()
                .expectStatusCode(200)
                .expectContentType(ContentType.JSON)
                .build();

        System.out.println("=======================================================");
        System.out.println(" RequestSpecification  created:");
        System.out.println("   Base URI   : " + BASE_URI);
        System.out.println("   Endpoint   : " + ENDPOINT);
        System.out.println("   drilldowns : Nation");
        System.out.println("   measures   : Population");
        System.out.println("   Year       : 2022");
        System.out.println("-------------------------------------------------------");
        System.out.println(" ResponseSpecification created:");
        System.out.println("   Expected Status Code  : 200");
        System.out.println("   Expected Content-Type : application/json");
        System.out.println("=======================================================");

        // Step 5: Send GET request using both RequestSpec and ResponseSpec
        response = RestAssured
                .given()
                    .spec(requestSpec)
                    .log().all()
                .when()
                    .get()
                .then()
                    .log().all()
                    .spec(responseSpec)
                    .extract()
                    .response();
    }

    // Scenario 1: Print United States population details for year 2022
    @Test
    public void printUSPopulationDetails2022() {

        // Step 6: Print ID Nation
        String idNation = response.jsonPath().getString("data[0].'ID Nation'");

        // Step 7: Print Nation
        String nation = response.jsonPath().getString("data[0].Nation");

        // Step 8: Print ID Year
        String idYear = response.jsonPath().getString("data[0].'ID Year'");

        // Step 9: Print Population
        String population = response.jsonPath().getString("data[0].Population");

        // Step 10: Print Slug Nation
        String slugNation = response.jsonPath().getString("data[0].'Slug Nation'");

        // Step 11: Print source_name & source_description
        String sourceName        = response.jsonPath()
                .getString("source[0].annotations.source_name");
        String sourceDescription = response.jsonPath()
                .getString("source[0].annotations.source_description");

        System.out.println("=======================================================");
        System.out.println(" United States Population Details - Year 2022");
        System.out.println("=======================================================");
        System.out.println(" ID Nation          : " + idNation);
        System.out.println(" Nation             : " + nation);
        System.out.println(" ID Year            : " + idYear);
        System.out.println(" Population         : " + population);
        System.out.println(" Slug Nation        : " + slugNation);
        System.out.println("-------------------------------------------------------");
        System.out.println(" Source Name        : " + sourceName);
        System.out.println(" Source Description : " + sourceDescription);
        System.out.println("=======================================================");
    }
}
