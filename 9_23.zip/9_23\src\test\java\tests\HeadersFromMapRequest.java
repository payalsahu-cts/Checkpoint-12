package tests;

import io.restassured.response.Response;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.notNullValue;

public class HeadersFromMapRequest {

    @Test
    public void getResponseWithHeadersFromMap() {

        // Step 1 & 3: Request body
        String requestBody = "{\n"
                + "    \"username\" : \"admin\",\n"
                + "    \"password\" : \"password123\"\n"
                + "}";

        // Step 4: Define headers in a Map
        Map<String, String> headersMap = new HashMap<>();
        headersMap.put("Content-Type", "application/json");
        headersMap.put("Accept",       "application/json");

        // Step 2 & 4: POST to /auth — pass all headers from the Map using headers(Map)
        Response response = given()
                    .baseUri("https://restful-booker.herokuapp.com")
                    .headers(headersMap)
                    .body(requestBody)
                .when()
                    .post("/auth")
                .then()
                    .assertThat()
                        .statusCode(200)
                        // Step 5: Validate token exists
                        .body("token", notNullValue())
                    .extract()
                    .response();

        // Step 5: Print the response in the console
        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Body         : " + response.getBody().asPrettyString());
        System.out.println("Auth Token            : " + response.jsonPath().getString("token"));
        System.out.println("------ Headers Passed via Map ------");
        headersMap.forEach((key, value) ->
                System.out.println(key + " : " + value));
    }
}
