# REST Assured API Testing Framework

## Scenario: Verify the Response of the GET API

| Step | Description |
|------|-------------|
| 1 | Maven project with TestNG & REST Assured dependencies |
| 2 | Java test class created in REST Assured framework |
| 3 | GET request sent to `https://postman-echo.com/basic-auth` |
| 4 | Basic Auth applied (Username: `postman`, Password: `password`) |
| 5 | Status code verified as `200` |
| 6 | Response body verified (`authenticated: true`) |

---

## Project Structure

```
restassured-project/
├── pom.xml                          ← Maven dependencies (TestNG + REST Assured)
├── testng.xml                       ← TestNG suite configuration
├── README.md
└── src/
    └── test/
        └── java/
            └── com/api/tests/
                └── VerifyGetAPIResponse.java   ← Main test class
```

---

## Prerequisites

- Java 11 or higher
- Maven 3.6+

---

## How to Run

### Option 1: Run via Maven (command line)
```bash
mvn clean test
```

### Option 2: Run via IDE (IntelliJ / Eclipse)
1. Import as Maven project
2. Right-click `testng.xml` → **Run**
   OR
3. Right-click `VerifyGetAPIResponse.java` → **Run As TestNG Test**

---

## Test Cases

| Test Method | Description | Expected |
|-------------|-------------|----------|
| `verifyGetAPIResponse_FluentChain` | Full fluent REST Assured chain | Status 200, authenticated=true |
| `verifyStatusCode_200` | Explicit status code assertion | Status 200 |
| `verifyResponseBody` | Full response body verification | Content-Type JSON, authenticated=true |
| `verifyUnauthorizedWithWrongCredentials` | Negative test with wrong credentials | Status 401 |

---

## API Details

- **URL:** `https://postman-echo.com/basic-auth`
- **Method:** GET
- **Auth:** Basic Auth
  - Username: `postman`
  - Password: `password`

### Expected Response Body
```json
{
    "authenticated": true
}
```

---

## Dependencies Used

| Library | Version | Purpose |
|---------|---------|---------|
| REST Assured | 5.3.2 | API testing framework |
| TestNG | 7.8.0 | Test runner & assertions |
| Hamcrest | 2.2 | Response matchers |
