package com.api.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

/**
 * Test Class: VerifyGetAPIResponse
 *
 * Scenario: Verify the response of the GET API
 * API     : https://postman-echo.com/basic-auth
 * Auth    : Basic Auth (Username: postman, Password: password)
 *
 * Steps covered:
 * Step 1 - Maven project with TestNG & REST Assured dependencies (pom.xml)
 * Step 2 - Java class created in REST Assured framework (this file)
 * Step 3 - Send GET request to the API
 * Step 4 - Apply Basic Auth credentials
 * Step 5 - Verify status code is 200
 * Step 6 - Verify the response body
 */
public class VerifyGetAPIResponse {

    // ----------------------------------------------------------------
    // Constants
    // ----------------------------------------------------------------
    private static final String BASE_URL      = "https://postman-echo.com";
    private static final String ENDPOINT      = "/basic-auth";
    private static final String USERNAME       = "postman";
    private static final String PASSWORD       = "password";

    // ----------------------------------------------------------------
    // Step 2 : Setup - configure base URI once for all tests
    // ----------------------------------------------------------------
    @BeforeClass
    public void setUp() {
        RestAssured.baseURI = BASE_URL;
        System.out.println("====================================================");
        System.out.println("  REST Assured Framework - GET API Verification");
        System.out.println("====================================================");
        System.out.println("Base URI set to : " + BASE_URL);
    }

    // ================================================================
    // Step 3, 4, 5, 6 combined in one test — full fluent chain
    // ================================================================

    /**
     * TEST 1: Fluent chain approach (Steps 3-6 in one block)
     * - Sends GET with Basic Auth
     * - Asserts status code 200
     * - Asserts response body authenticated == true
     */
    @Test(priority = 1, description = "Verify GET API response using fluent chain")
    public void verifyGetAPIResponse_FluentChain() {

        System.out.println("\n[TEST 1] Fluent Chain - GET with Basic Auth");
        System.out.println("Endpoint : " + BASE_URL + ENDPOINT);

        // Step 3: Send GET request
        // Step 4: Apply Basic Auth
        // Step 5: Verify status code = 200
        // Step 6: Verify response body
        given()
            .auth()
                .preemptive()
                .basic(USERNAME, PASSWORD)       // Step 4: Basic Auth credentials
            .log().all()                         // Log request details
        .when()
            .get(ENDPOINT)                       // Step 3: GET request
        .then()
            .log().all()                         // Log response details
            .statusCode(200)                     // Step 5: Verify status code
            .body("authenticated", equalTo(true)); // Step 6: Verify response

        System.out.println("[TEST 1] PASSED - Status 200 & authenticated = true");
    }

    // ================================================================
    // Step 5: Verify status code — explicit assertion with Response object
    // ================================================================

    /**
     * TEST 2: Step-by-step approach using Response object
     * Demonstrates explicit status code + body assertions (Steps 5 & 6)
     */
    @Test(priority = 2, description = "Verify status code is 200 explicitly")
    public void verifyStatusCode_200() {

        System.out.println("\n[TEST 2] Explicit Status Code Verification");

        // Step 3: GET request | Step 4: Basic Auth
        Response response =
            given()
                .auth()
                    .preemptive()
                    .basic(USERNAME, PASSWORD)
            .when()
                .get(ENDPOINT)
            .then()
                .extract()
                .response();

        // Step 5: Verify status code
        int statusCode = response.getStatusCode();
        System.out.println("Actual Status Code : " + statusCode);
        Assert.assertEquals(statusCode, 200,
            "Expected status code 200 but got: " + statusCode);

        System.out.println("[TEST 2] PASSED - Status Code is 200");
    }

    // ================================================================
    // Step 6: Verify the response body in detail
    // ================================================================

    /**
     * TEST 3: Full response verification (Step 6)
     * - Verifies Content-Type header
     * - Verifies 'authenticated' field in JSON body
     * - Prints the complete response body
     */
    @Test(priority = 3, description = "Verify the complete API response body")
    public void verifyResponseBody() {

        System.out.println("\n[TEST 3] Response Body Verification");

        // Step 3 & 4: GET + Basic Auth
        Response response =
            given()
                .auth()
                    .preemptive()
                    .basic(USERNAME, PASSWORD)
            .when()
                .get(ENDPOINT)
            .then()
                .extract()
                .response();

        // ------ Step 6: Verify Response ------

        // 6a. Verify Content-Type header
        String contentType = response.getContentType();
        System.out.println("Content-Type : " + contentType);
        Assert.assertTrue(contentType.contains("application/json"),
            "Expected Content-Type to contain 'application/json' but got: " + contentType);

        // 6b. Verify 'authenticated' field is true
        boolean isAuthenticated = response.jsonPath().getBoolean("authenticated");
        System.out.println("authenticated : " + isAuthenticated);
        Assert.assertTrue(isAuthenticated,
            "Expected 'authenticated' to be true but got: " + isAuthenticated);

        // 6c. Print full response body
        System.out.println("Full Response Body : " + response.getBody().asPrettyString());

        System.out.println("[TEST 3] PASSED - Response body verified successfully");
    }

    // ================================================================
    // Bonus: Negative Test — wrong credentials should return 401
    // ================================================================

    /**
     * TEST 4: Negative test — wrong credentials
     * Confirms that invalid credentials return HTTP 401
     */
    @Test(priority = 4, description = "Verify 401 is returned for wrong credentials")
    public void verifyUnauthorizedWithWrongCredentials() {

        System.out.println("\n[TEST 4] Negative Test - Wrong Credentials");

        given()
            .auth()
                .preemptive()
                .basic("wrongUser", "wrongPass")
            .log().all()
        .when()
            .get(ENDPOINT)
        .then()
            .log().status()
            .statusCode(401);

        System.out.println("[TEST 4] PASSED - 401 returned for invalid credentials");
    }
}
