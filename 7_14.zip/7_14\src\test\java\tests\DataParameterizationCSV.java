package tests;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

/**
 * Scenario 15 - Data Parameterization using CSV in Postman
 *
 * Steps automated:
 *   Step 3:  POST https://jsonplaceholder.typicode.com/posts
 *   Step 4:  Pass request body (title, body, userId from CSV)
 *   Step 9:  CSV file placed in src/test/resources/posts_data.csv
 *   Step 11: CSV values read via TestNG @DataProvider (equivalent of CSV import)
 *   Step 14: Each row runs as a separate test iteration
 *
 * CSV file: src/test/resources/posts_data.csv
 * Columns : title, body, userId
 */
public class DataParameterizationCSV {

    // Step 9/11: Read CSV file from classpath — equivalent of importing CSV in Postman Runner
    @DataProvider(name = "csvPostsData")
    public Object[][] readCsvData() throws IOException {

        List<Object[]> rows = new ArrayList<>();

        // Load CSV from classpath (src/test/resources/)
        InputStream inputStream = getClass()
                .getClassLoader()
                .getResourceAsStream("posts_data.csv");

        if (inputStream == null) {
            throw new RuntimeException("CSV file not found: posts_data.csv");
        }

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
            String line;
            boolean isHeader = true;

            while ((line = reader.readLine()) != null) {
                // Skip the header row
                if (isHeader) {
                    isHeader = false;
                    continue;
                }
                // Split by comma and trim whitespace
                String[] columns = line.split(",");
                rows.add(new Object[]{
                        columns[0].trim(),               // title
                        columns[1].trim(),               // body
                        Integer.parseInt(columns[2].trim()) // userId
                });
            }
        }

        System.out.println("CSV rows loaded for parameterization: " + rows.size());
        return rows.toArray(new Object[0][]);
    }

    // Step 3, 4, 14: Runs once per CSV row — each row is one Postman Runner iteration
    @Test(dataProvider = "csvPostsData")
    public void createPostWithCsvData(String title, String body, int userId) {

        // Step 4: Build request body from CSV row values
        String requestBody = "{\n"
                + "    \"title\"  : \"" + title  + "\",\n"
                + "    \"body\"   : \"" + body   + "\",\n"
                + "    \"userId\" : " + userId   + "\n"
                + "}";

        // Step 3: POST /posts with parameterized data
        Response response = given()
                    .baseUri("https://jsonplaceholder.typicode.com")
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .body(requestBody)
                .when()
                    .post("/posts")
                .then()
                    .assertThat()
                        .statusCode(201)
                        .body("id",     notNullValue())
                        .body("title",  equalTo(title))
                        .body("body",   equalTo(body))
                        .body("userId", equalTo(userId))
                    .extract()
                    .response();

        int createdId = response.jsonPath().getInt("id");

        System.out.println("========================================");
        System.out.println(" CSV Row → POST /posts");
        System.out.println("========================================");
        System.out.println("title    : " + title);
        System.out.println("body     : " + body);
        System.out.println("userId   : " + userId);
        System.out.println("Status   : " + response.getStatusCode());
        System.out.println("Post ID  : " + createdId);
        System.out.println("Response : " + response.getBody().asPrettyString());

        // Verify status 201 and response fields
        Assert.assertEquals(response.getStatusCode(), 201);
        Assert.assertEquals(response.jsonPath().getString("title"),  title);
        Assert.assertEquals(response.jsonPath().getString("body"),   body);
        Assert.assertEquals(response.jsonPath().getInt("userId"),    userId);
        System.out.println("CSV row iteration PASSED.");
    }
}
