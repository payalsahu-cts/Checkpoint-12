package tests;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;

public class GetSingleHeader {

    @Test
    public void getSingleHeaderFromResponse() {

        String requestBody = "{\n"
                + "    \"firstname\": \"Jim\",\n"
                + "    \"lastname\": \"Brown\",\n"
                + "    \"totalprice\": 111,\n"
                + "    \"depositpaid\": true,\n"
                + "    \"bookingdates\": {\n"
                + "        \"checkin\": \"2018-01-01\",\n"
                + "        \"checkout\": \"2019-01-01\"\n"
                + "    },\n"
                + "    \"additionalneeds\": \"Breakfast\"\n"
                + "}";

        // Step 2: POST request and extract response
        Response response = given()
                    .baseUri("https://restful-booker.herokuapp.com")
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .body(requestBody)
                .when()
                    .post("/booking")
                .then()
                    .assertThat()
                        .statusCode(200)
                    .extract()
                    .response();

        // Step 3: Get a single header using header(String headerName) method
        String contentType   = response.header("Content-Type");
        String server        = response.header("Server");
        String connection    = response.header("Connection");

        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Body         : " + response.getBody().asPrettyString());
        System.out.println("------ Single Header Extraction ------");
        System.out.println("Content-Type  header  : " + contentType);
        System.out.println("Server        header  : " + server);
        System.out.println("Connection    header  : " + connection);
    }
}
