package tests;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

/**
 * Scenario 13 - Get the Values of Environment Variables in Postman
 *
 * Steps automated:
 *   Step 3: GET https://gorest.co.in/public/v2/users/{{APIID}}
 *   Step 4: Extract ID from response (pre-script equivalent)
 *   Step 5: Bearer token from gorest.co.in
 *   Step 6: Verify status code is 200
 *   Step 7: Verify response body
 *
 * NOTE: Replace YOUR_TOKEN_HERE with your personal token from
 *       https://gorest.co.in → Profile (top right) → API Token
 */
public class GetGoRestUser {

    private static final String BEARER_TOKEN = "YOUR_TOKEN_HERE";
    private static final String BASE_URI     = "https://gorest.co.in";

    // Equivalent of Postman environment variable {{APIID}}
    // Populated in @BeforeClass by first creating a user (same as 7_11 flow)
    private int APIID;

    @BeforeClass
    public void createUserToFetch() {

        // Pre-script equivalent: create a user first and store ID in APIID variable
        String createBody = "{\n"
                + "    \"name\"   : \"Fetch User\",\n"
                + "    \"email\"  : \"fetchuser_" + System.currentTimeMillis() + "@example.com\",\n"
                + "    \"gender\" : \"female\",\n"
                + "    \"status\" : \"active\"\n"
                + "}";

        Response createResponse = given()
                    .baseUri(BASE_URI)
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .header("Authorization", "Bearer " + BEARER_TOKEN)
                    .body(createBody)
                .when()
                    .post("/public/v2/users")
                .then()
                    .assertThat().statusCode(201)
                    .extract().response();

        // Step 4: Extract ID — equivalent of pm.environment.get("APIID") in pre-script
        APIID = createResponse.jsonPath().getInt("id");

        System.out.println("========================================");
        System.out.println(" Environment Variable Retrieved");
        System.out.println(" APIID = " + APIID);
        System.out.println("========================================");
    }

    @Test
    public void getUserByIdUsingEnvVariable() {

        // Step 3, 5-7: GET /public/v2/users/{{APIID}} with Bearer token
        Response response = given()
                    .baseUri(BASE_URI)
                    .accept(ContentType.JSON)
                    .header("Authorization", "Bearer " + BEARER_TOKEN)
                .when()
                    .get("/public/v2/users/" + APIID)
                .then()
                    .assertThat()
                        // Step 6: Verify 200
                        .statusCode(200)
                        // Step 7: Verify response body
                        .body("id",     equalTo(APIID))
                        .body("name",   notNullValue())
                        .body("email",  notNullValue())
                        .body("gender", notNullValue())
                        .body("status", equalTo("active"))
                    .extract()
                    .response();

        // Step 4: Extract ID from GET response
        int fetchedId = response.jsonPath().getInt("id");

        System.out.println("========================================");
        System.out.println(" GET /public/v2/users/" + APIID);
        System.out.println("========================================");
        System.out.println("URL                   : " + BASE_URI + "/public/v2/users/" + APIID);
        System.out.println("Method                : GET");
        System.out.println("Env Variable APIID    : " + APIID);
        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Body         : " + response.getBody().asPrettyString());
        System.out.println("------ Extracted from Response ------");
        System.out.println("id     : " + fetchedId);
        System.out.println("name   : " + response.jsonPath().getString("name"));
        System.out.println("email  : " + response.jsonPath().getString("email"));
        System.out.println("gender : " + response.jsonPath().getString("gender"));
        System.out.println("status : " + response.jsonPath().getString("status"));

        Assert.assertEquals(response.getStatusCode(), 200);
        Assert.assertEquals(fetchedId, APIID, "Returned ID does not match APIID!");
        System.out.println("GET user by APIID verified successfully.");
    }
}
