package tests;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

/**
 * Scenario 12 - Set the Environment Variables in Postman
 *
 * Steps automated:
 *   Step 5: POST https://gorest.co.in/public/v2/users
 *   Step 6: Bearer token from gorest.co.in (replace YOUR_TOKEN_HERE)
 *   Step 7: Request body with name, email, gender, status
 *   Step 8: Capture created user ID (equivalent of Postman global variable APIID)
 *   Step 9: Verify status code is 201
 *   Step 10: Verify response body
 *
 * NOTE: Replace YOUR_TOKEN_HERE with your personal token from
 *       https://gorest.co.in → Profile (top right) → API Token
 */
public class CreateGoRestUser {

    // Step 3/6: Paste your Bearer token from gorest.co.in here
    private static final String BEARER_TOKEN = "YOUR_TOKEN_HERE";
    private static final String BASE_URI     = "https://gorest.co.in";

    // Step 8: Global variable equivalent — stores the created user ID
    public static int APIID;

    @Test
    public void createUserAndCaptureId() {

        // Step 7: Request body
        String requestBody = "{\n"
                + "    \"name\"   : \"Test User\",\n"
                + "    \"email\"  : \"testuser_" + System.currentTimeMillis() + "@example.com\",\n"
                + "    \"gender\" : \"male\",\n"
                + "    \"status\" : \"active\"\n"
                + "}";

        // Step 5-10: POST /public/v2/users with Bearer token
        Response response = given()
                    .baseUri(BASE_URI)
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .header("Authorization", "Bearer " + BEARER_TOKEN)
                    .body(requestBody)
                .when()
                    .post("/public/v2/users")
                .then()
                    .assertThat()
                        // Step 9: Verify status code is 201
                        .statusCode(201)
                        // Step 10: Verify response body fields
                        .body("id",     notNullValue())
                        .body("name",   equalTo("Test User"))
                        .body("gender", equalTo("male"))
                        .body("status", equalTo("active"))
                    .extract()
                    .response();

        // Step 8: Capture the ID in a static variable (equivalent of Postman global APIID)
        APIID = response.jsonPath().getInt("id");

        System.out.println("========================================");
        System.out.println(" POST /public/v2/users — Create User");
        System.out.println("========================================");
        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Body         : " + response.getBody().asPrettyString());
        System.out.println("------ Captured Environment Variable ------");
        System.out.println("APIID (global var)    : " + APIID);

        // Step 9: TestNG assertion
        Assert.assertEquals(response.getStatusCode(), 201,
                "Expected 201 Created but got: " + response.getStatusCode());
        Assert.assertTrue(APIID > 0, "User ID should be a positive integer!");
        System.out.println("User created successfully. APIID = " + APIID);
    }
}
