package tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class BitcoinRatePrintTest {

    private static final String BASE_URL = "https://api.coindesk.com/v1/bpi/currentprice.json";
    private Response response;

    @BeforeClass
    public void setUp() {
        RestAssured.baseURI = BASE_URL;

        response = RestAssured
                .given()
                    .log().all()
                .when()
                    .get()
                .then()
                    .log().all()
                    .extract()
                    .response();
    }

    // Scenario 3: Print Bitcoin rate against USD currency
    @Test(priority = 1)
    public void printUSDRate() {
        System.out.println("========== Scenario 3: Bitcoin Rate - USD ==========");

        String code        = response.jsonPath().getString("bpi.USD.code");
        String symbol      = response.jsonPath().getString("bpi.USD.symbol");
        String rate        = response.jsonPath().getString("bpi.USD.rate");
        String description = response.jsonPath().getString("bpi.USD.description");
        String usdRate     = response.jsonPath().getString("bpi.USD.rate");
        float  rateFloat   = response.jsonPath().getFloat("bpi.USD.rate_float");

        System.out.println("Code        : " + code);
        System.out.println("Symbol      : " + symbol);
        System.out.println("Rate        : " + rate);
        System.out.println("Description : " + description);
        System.out.println("USD Rate    : " + usdRate);
        System.out.println("Rate Float  : " + rateFloat);
        System.out.println("====================================================");
    }

    // Scenario 4: Print Bitcoin rate against GBP currency
    @Test(priority = 2)
    public void printGBPRate() {
        System.out.println("========== Scenario 4: Bitcoin Rate - GBP ==========");

        String code        = response.jsonPath().getString("bpi.GBP.code");
        String symbol      = response.jsonPath().getString("bpi.GBP.symbol");
        String rate        = response.jsonPath().getString("bpi.GBP.rate");
        String description = response.jsonPath().getString("bpi.GBP.description");
        String gbpRate     = response.jsonPath().getString("bpi.GBP.rate");
        float  rateFloat   = response.jsonPath().getFloat("bpi.GBP.rate_float");

        System.out.println("Code        : " + code);
        System.out.println("Symbol      : " + symbol);
        System.out.println("Rate        : " + rate);
        System.out.println("Description : " + description);
        System.out.println("GBP Rate    : " + gbpRate);
        System.out.println("Rate Float  : " + rateFloat);
        System.out.println("====================================================");
    }

    // Scenario 5: Print Bitcoin rate against EUR currency
    @Test(priority = 3)
    public void printEURRate() {
        System.out.println("========== Scenario 5: Bitcoin Rate - EUR ==========");

        String code        = response.jsonPath().getString("bpi.EUR.code");
        String symbol      = response.jsonPath().getString("bpi.EUR.symbol");
        String rate        = response.jsonPath().getString("bpi.EUR.rate");
        String description = response.jsonPath().getString("bpi.EUR.description");
        String eurRate     = response.jsonPath().getString("bpi.EUR.rate");
        float  rateFloat   = response.jsonPath().getFloat("bpi.EUR.rate_float");

        System.out.println("Code        : " + code);
        System.out.println("Symbol      : " + symbol);
        System.out.println("Rate        : " + rate);
        System.out.println("Description : " + description);
        System.out.println("EUR Rate    : " + eurRate);
        System.out.println("Rate Float  : " + rateFloat);
        System.out.println("====================================================");
    }
}
