package tests;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.anyOf;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.greaterThanOrEqualTo;
import static org.hamcrest.Matchers.lessThan;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;

public class LogicalOperationsValidation {

    @Test
    public void performLogicalOperationsOnResponse() {

        String requestBody = "{\n"
                + "    \"firstname\": \"Jim\",\n"
                + "    \"lastname\": \"Brown\",\n"
                + "    \"totalprice\": 111,\n"
                + "    \"depositpaid\": true,\n"
                + "    \"bookingdates\": {\n"
                + "        \"checkin\": \"2018-01-01\",\n"
                + "        \"checkout\": \"2019-01-01\"\n"
                + "    },\n"
                + "    \"additionalneeds\": \"Breakfast\"\n"
                + "}";

        // Step 1: POST request
        // Step 2: Logical operations — allOf (AND), anyOf (OR), not (NOT)
        Response response = given()
                    .baseUri("https://restful-booker.herokuapp.com")
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .body(requestBody)
                .when()
                    .post("/booking")
                .then()
                    .assertThat()
                        .statusCode(200)

                        // AND — allOf: ALL conditions must be true
                        .body("booking.firstname",
                                allOf(notNullValue(), equalTo("Jim")))

                        .body("booking.totalprice",
                                allOf(greaterThan(0), lessThan(1000), equalTo(111)))

                        .body("booking.bookingdates.checkin",
                                allOf(notNullValue(), containsString("2018")))

                        // OR — anyOf: AT LEAST ONE condition must be true
                        .body("booking.additionalneeds",
                                anyOf(equalTo("Breakfast"), equalTo("Lunch"), equalTo("Dinner")))

                        .body("booking.depositpaid",
                                anyOf(equalTo(true), equalTo(false)))

                        .statusCode(anyOf(equalTo(200), equalTo(201)))

                        // NOT — not: condition must NOT be true
                        .body("booking.firstname",  not(equalTo("John")))
                        .body("booking.lastname",   not(equalTo("Doe")))
                        .body("booking.totalprice", not(lessThan(0)))
                        .body("bookingid",          not(equalTo(0)))

                        // Combined: allOf + not
                        .body("booking.totalprice",
                                allOf(greaterThanOrEqualTo(1), not(equalTo(0))))

                    .extract()
                    .response();

        // Step 3: Print the response in the console
        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Body         : " + response.getBody().asPrettyString());
        System.out.println("------ Logical Operations Summary ------");
        System.out.println("allOf  (AND) - firstname is notNull AND equals Jim    : PASSED");
        System.out.println("allOf  (AND) - totalprice > 0 AND < 1000 AND == 111  : PASSED");
        System.out.println("anyOf  (OR)  - additionalneeds is Breakfast/Lunch/Dinner: PASSED");
        System.out.println("not    (NOT) - firstname is NOT John                  : PASSED");
        System.out.println("not    (NOT) - totalprice is NOT less than 0          : PASSED");
    }
}
