package tests;

import io.restassured.response.Response;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.anyOf;
import static org.hamcrest.Matchers.equalTo;

public class LimitRedirects {

    @Test
    public void limitRedirectsToOne() {

        // Step 1 & 3: Limit the number of redirects to 1 using redirects().max(int)
        Response response = given()
                    .baseUri("https://simple-tool-rental-api.glitch.me")
                    .redirects().max(1)
                .when()
                    .get("/status")
                .then()
                    .assertThat()
                        .statusCode(anyOf(equalTo(200), equalTo(301), equalTo(302), equalTo(307)))
                    .extract()
                    .response();

        System.out.println("------ Max Redirects = 1 ------");
        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Status Line  : " + response.getStatusLine());
        System.out.println("Response Body         : " + response.getBody().asString());
    }

    @Test
    public void limitRedirectsToZero() {

        // Limit to 0 redirects — same as disabling redirects
        Response response = given()
                    .baseUri("https://simple-tool-rental-api.glitch.me")
                    .redirects().max(0)
                .when()
                    .get("/status")
                .then()
                    .assertThat()
                        .statusCode(anyOf(equalTo(200), equalTo(301), equalTo(302), equalTo(307)))
                    .extract()
                    .response();

        System.out.println("------ Max Redirects = 0 ------");
        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Body         : " + response.getBody().asString());
        System.out.println("Location Header       : " + response.getHeader("Location"));
    }

    @Test
    public void limitRedirectsToFive() {

        // Limit to 5 redirects (default REST Assured behaviour is typically unlimited)
        Response response = given()
                    .baseUri("https://simple-tool-rental-api.glitch.me")
                    .redirects().max(5)
                .when()
                    .get("/status")
                .then()
                    .assertThat()
                        .statusCode(200)
                    .extract()
                    .response();

        System.out.println("------ Max Redirects = 5 ------");
        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Body         : " + response.getBody().asString());
    }
}
