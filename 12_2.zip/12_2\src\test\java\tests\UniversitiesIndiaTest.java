package tests;

import io.restassured.RestAssured;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import java.util.List;

public class UniversitiesIndiaTest {

    private static final String BASE_URL = "http://universities.hipolabs.com";
    private static final String ENDPOINT = "/search";
    private static final String COUNTRY  = "india";

    // Scenario 2: Get number of universities in India and print response log using ResponseLoggingFilter
    @Test
    public void getNumberOfUniversitiesInIndia() {

        Response response = RestAssured
                .given()
                    .baseUri(BASE_URL)
                    .queryParam("country", COUNTRY)
                    .filter(new ResponseLoggingFilter())
                    .log().all()
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract()
                    .response();

        // Extract the full list of universities from the JSON array response
        List<Object> universities = response.jsonPath().getList("$");

        int totalCount = universities.size();

        System.out.println("=======================================================");
        System.out.println(" Response Status Code  : " + response.getStatusCode());
        System.out.println(" Response Time (ms)    : " + response.getTime());
        System.out.println(" Country Searched      : " + COUNTRY);
        System.out.println(" Total Universities    : " + totalCount);
        System.out.println("=======================================================");
    }
}
