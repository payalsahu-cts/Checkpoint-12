package tests;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.hasSize;

public class ListSizeCheckValidation {

    @Test
    public void verifyListSizeInResponse() {

        String requestBody = "{\n"
                + "    \"firstname\": \"Jim\",\n"
                + "    \"lastname\": \"Brown\",\n"
                + "    \"totalprice\": 111,\n"
                + "    \"depositpaid\": true,\n"
                + "    \"bookingdates\": {\n"
                + "        \"checkin\": \"2018-01-01\",\n"
                + "        \"checkout\": \"2019-01-01\"\n"
                + "    },\n"
                + "    \"additionalneeds\": \"Breakfast\"\n"
                + "}";

        // Step 1: POST request
        // Step 2: Verify size of lists in the response using hasSize() and GPath size()
        Response response = given()
                    .baseUri("https://restful-booker.herokuapp.com")
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .body(requestBody)
                .when()
                    .post("/booking")
                .then()
                    .assertThat()
                        .statusCode(200)
                        // Root level has exactly 2 keys: "bookingid" and "booking"
                        .body("$",                      hasSize(2))
                        // "booking" object has exactly 6 fields
                        .body("booking",                hasSize(6))
                        // "booking.bookingdates" object has exactly 2 fields
                        .body("booking.bookingdates",   hasSize(2))
                        // Verify using GPath size() — confirms count is greater than 0
                        .body("$.size()",               greaterThan(0))
                        .body("booking.size()",         equalTo(6))
                        .body("booking.bookingdates.size()", equalTo(2))
                    .extract()
                    .response();

        // Step 3: Print the response in the console
        System.out.println("Response Status Code              : " + response.getStatusCode());
        System.out.println("Response Body                     : " + response.getBody().asPrettyString());

        // Extract and print list sizes using jsonPath
        Map<String, Object> root         = response.jsonPath().getMap("$");
        Map<String, Object> booking      = response.jsonPath().getMap("booking");
        Map<String, Object> bookingDates = response.jsonPath().getMap("booking.bookingdates");
        List<Integer> allBookingIds      = given()
                                            .baseUri("https://restful-booker.herokuapp.com")
                                            .accept(ContentType.JSON)
                                           .when()
                                            .get("/booking")
                                           .then()
                                            .extract()
                                            .jsonPath()
                                            .getList("bookingid");

        System.out.println("------ List Size Check Results ------");
        System.out.println("Root level keys count             : " + root.size());
        System.out.println("booking fields count              : " + booking.size());
        System.out.println("booking.bookingdates fields count : " + bookingDates.size());
        System.out.println("Total bookings in system          : " + allBookingIds.size());
    }
}
