package tests;

import io.restassured.response.Response;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.anyOf;
import static org.hamcrest.Matchers.equalTo;

public class RedirectFalse {

    @Test
    public void disableRedirectAndValidate() {

        // Step 2 & 4: GET /status with redirects disabled using redirects().follow(false)
        Response response = given()
                    .baseUri("https://simple-tool-rental-api.glitch.me")
                    .redirects().follow(false)
                .when()
                    .get("/status")
                .then()
                    .assertThat()
                        // When redirects are disabled, response may be 200 or a 3xx redirect code
                        .statusCode(anyOf(equalTo(200), equalTo(301), equalTo(302), equalTo(307)))
                    .extract()
                    .response();

        // Step 3: Print the response in the console
        System.out.println("------ Redirect Disabled (redirects().follow(false)) ------");
        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Status Line  : " + response.getStatusLine());
        System.out.println("Response Body         : " + response.getBody().asString());
        System.out.println("Location Header       : " + response.getHeader("Location"));
        System.out.println("Redirect Followed     : false");
    }

    @Test
    public void enableRedirectAndValidate() {

        // For comparison — same API with redirects enabled (default behaviour)
        Response response = given()
                    .baseUri("https://simple-tool-rental-api.glitch.me")
                    .redirects().follow(true)
                .when()
                    .get("/status")
                .then()
                    .assertThat()
                        .statusCode(200)
                    .extract()
                    .response();

        System.out.println("------ Redirect Enabled (redirects().follow(true)) ------");
        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Body         : " + response.getBody().asString());
        System.out.println("Redirect Followed     : true");
    }
}
