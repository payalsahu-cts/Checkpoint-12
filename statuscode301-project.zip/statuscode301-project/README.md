# REST Assured - Validate 301 Status Code

## Scenario: Validate the 301 Status Code in REST Assured

| Step | Description |
|------|-------------|
| 1 | Maven project with TestNG & REST Assured dependencies |
| 2 | Java class created in REST Assured framework |
| 3 | GET request sent to `https://the-internet.herokuapp.com/status_codes/301` |
| 4 | Verify the status code is `301` |

---

## ⚠️ Important: Redirect Handling

REST Assured **follows redirects automatically** by default — meaning without configuration,
a 301 response would be silently followed and you'd see a 200 instead.

This project disables redirect following using:
```java
.config(RestAssuredConfig.config()
    .redirect(RedirectConfig.redirectConfig()
        .followRedirects(false)))
```
This ensures the raw **301 Moved Permanently** response is captured and validated.

---

## Project Structure

```
statuscode301-project/
├── pom.xml                          ← Maven dependencies (TestNG + REST Assured)
├── testng.xml                       ← TestNG suite configuration
├── README.md
└── src/
    └── test/
        └── java/
            └── com/api/tests/
                └── ValidateStatusCode301.java   ← Main test class
```

---

## Prerequisites

- Java 11 or higher
- Maven 3.6+

---

## How to Run

```bash
mvn clean test
```

Or in IDE: Right-click `testng.xml` → **Run**

---

## Test Cases

| Test Method | Description | Expected |
|-------------|-------------|----------|
| `validateStatusCode301_FluentChain` | Fluent REST Assured chain assertion | Status 301 |
| `validateStatusCode301_ExplicitAssertion` | TestNG `Assert.assertEquals` on response | Status 301 |
| `validateStatusLine_And_LocationHeader` | Status line + Location header check | Contains "301" + Location not null |

---

## API Details

- **URL:** `https://the-internet.herokuapp.com/status_codes/301`
- **Method:** GET
- **Auth:** None required
- **Expected Status Code:** `301 Moved Permanently`
- **Expected Headers:** `Location` header pointing to redirect destination
