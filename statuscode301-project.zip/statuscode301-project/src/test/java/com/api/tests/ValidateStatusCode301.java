package com.api.tests;

import io.restassured.RestAssured;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RedirectConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;

/**
 * Test Class : ValidateStatusCode301
 *
 * Scenario   : Validate the 301 status code in REST Assured
 * API        : https://the-internet.herokuapp.com/status_codes/301
 * Method     : GET
 *
 * Steps covered:
 * Step 1 - Maven project with TestNG & REST Assured dependencies (pom.xml)
 * Step 2 - Java class created in REST Assured framework (this file)
 * Step 3 - GET request sent to https://the-internet.herokuapp.com/status_codes/301
 * Step 4 - Verify the status code is 301
 *
 * NOTE: By default REST Assured follows redirects automatically.
 *       redirects().follow(false) is REQUIRED to capture the raw 301 response.
 */
public class ValidateStatusCode301 {

    // ----------------------------------------------------------------
    // Constants
    // ----------------------------------------------------------------
    private static final String BASE_URL = "https://the-internet.herokuapp.com";
    private static final String ENDPOINT = "/status_codes/301";

    // ----------------------------------------------------------------
    // Step 2 : Setup — configure base URI before tests run
    // ----------------------------------------------------------------
    @BeforeClass
    public void setUp() {
        RestAssured.baseURI = BASE_URL;
        System.out.println("=======================================================");
        System.out.println("  REST Assured Framework - Status Code 301 Validation  ");
        System.out.println("=======================================================");
        System.out.println("Base URI : " + BASE_URL);
        System.out.println("Endpoint : " + ENDPOINT);
        System.out.println("NOTE     : Redirect following is DISABLED to capture 301");
    }

    // ================================================================
    // Step 3 & 4 — Fluent chain: GET + disable redirect + assert 301
    // ================================================================

    /**
     * TEST 1 : Fluent chain approach
     * Disables auto-redirect so the raw 301 is captured, then asserts inline.
     */
    @Test(priority = 1, description = "Validate 301 status code using fluent REST Assured chain")
    public void validateStatusCode301_FluentChain() {

        System.out.println("\n[TEST 1] Fluent Chain - Validate Status Code 301");

        // Step 3: GET request to the API
        // Step 4: Verify status code is 301
        given()
            .config(RestAssuredConfig.config()
                .redirect(RedirectConfig.redirectConfig()
                    .followRedirects(false)))   // MUST disable to capture 301
            .log().all()
        .when()
            .get(ENDPOINT)                      // Step 3: GET call
        .then()
            .log().all()
            .statusCode(301);                   // Step 4: Assert status code = 301

        System.out.println("[TEST 1] PASSED - Status Code is 301");
    }

    // ================================================================
    // Step 3 & 4 — Explicit assertion using Response object
    // ================================================================

    /**
     * TEST 2 : Explicit assertion using Response object + TestNG Assert
     */
    @Test(priority = 2, description = "Validate 301 status code using explicit TestNG assertion")
    public void validateStatusCode301_ExplicitAssertion() {

        System.out.println("\n[TEST 2] Explicit Assertion - Validate Status Code 301");

        // Step 3: Send GET request with redirects disabled
        Response response =
            given()
                .config(RestAssuredConfig.config()
                    .redirect(RedirectConfig.redirectConfig()
                        .followRedirects(false)))
                .log().uri()
            .when()
                .get(ENDPOINT)
            .then()
                .extract()
                .response();

        // Step 4: Verify the status code is 301
        int actualStatusCode = response.getStatusCode();
        System.out.println("Actual Status Code   : " + actualStatusCode);
        System.out.println("Expected Status Code : 301");

        Assert.assertEquals(actualStatusCode, 301,
            "Status code mismatch! Expected 301 but got: " + actualStatusCode);

        System.out.println("[TEST 2] PASSED - Status Code verified as 301");
    }

    // ================================================================
    // Step 3 & 4 — Status line + Location header verification
    // ================================================================

    /**
     * TEST 3 : Verify HTTP status line and Location redirect header
     * A 301 response should include a Location header pointing to the new URL.
     */
    @Test(priority = 3, description = "Validate status line and Location header for 301 redirect")
    public void validateStatusLine_And_LocationHeader() {

        System.out.println("\n[TEST 3] Status Line & Location Header Verification");

        // Step 3: GET with redirects disabled
        Response response =
            given()
                .config(RestAssuredConfig.config()
                    .redirect(RedirectConfig.redirectConfig()
                        .followRedirects(false)))
                .log().uri()
            .when()
                .get(ENDPOINT)
            .then()
                .extract()
                .response();

        // Step 4: Verify status line contains "301"
        String statusLine = response.getStatusLine();
        System.out.println("Status Line      : " + statusLine);
        Assert.assertTrue(statusLine.contains("301"),
            "Expected status line to contain '301' but got: " + statusLine);

        // Bonus: Verify Location header is present (standard for 301)
        String locationHeader = response.getHeader("Location");
        System.out.println("Location Header  : " + locationHeader);
        Assert.assertNotNull(locationHeader,
            "Expected 'Location' header in 301 response, but it was null");

        System.out.println("[TEST 3] PASSED - Status Line contains 301 & Location header present");
    }
}
