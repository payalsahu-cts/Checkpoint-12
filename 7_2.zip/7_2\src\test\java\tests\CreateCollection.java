package tests;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.notNullValue;

/**
 * Scenario 2 - Create Collections for API Request
 *
 * In Postman:
 *   Step 1: Open Postman
 *   Step 2: Click New button
 *   Step 3: Select Collection
 *   Step 4: Give collection a meaningful name
 *
 * In REST Assured (Java equivalent):
 *   A "collection" is represented by a Java class grouping related @Test methods,
 *   all sharing a common RequestSpecification (base URL, headers, auth).
 *   The class name acts as the collection name.
 */
public class CreateCollection {

    // Collection name — groups all related booking API requests
    private static final String COLLECTION_NAME = "Restful Booker API Collection";
    private static final String BASE_URI        = "https://restful-booker.herokuapp.com";

    // Shared specification for the entire collection
    private RequestSpecification collectionSpec;

    @BeforeClass
    public void setupCollection() {
        collectionSpec = given()
                .baseUri(BASE_URI)
                .header("Content-Type", "application/json")
                .accept("application/json");

        System.out.println("========================================");
        System.out.println(" Collection Created : " + COLLECTION_NAME);
        System.out.println(" Base URI           : " + BASE_URI);
        System.out.println("========================================");
    }

    // Request 1 in collection — Get all bookings
    @Test(priority = 1)
    public void getAllBookings() {

        Response response = given(collectionSpec)
                .when()
                    .get("/booking")
                .then()
                    .assertThat()
                        .statusCode(200)
                        .body("$", notNullValue())
                    .extract()
                    .response();

        System.out.println("[Collection: " + COLLECTION_NAME + "] GET /booking");
        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Body         : " + response.getBody().asPrettyString());
        Assert.assertEquals(response.getStatusCode(), 200);
    }

    // Request 2 in collection — Get booking by ID
    @Test(priority = 2)
    public void getBookingById() {

        Response response = given(collectionSpec)
                .when()
                    .get("/booking/1")
                .then()
                    .assertThat()
                        .statusCode(anyOf(200, 404))
                    .extract()
                    .response();

        System.out.println("[Collection: " + COLLECTION_NAME + "] GET /booking/1");
        System.out.println("Response Status Code  : " + response.getStatusCode());
        System.out.println("Response Body         : " + response.getBody().asPrettyString());
    }

    private org.hamcrest.Matcher<Integer> anyOf(int... codes) {
        org.hamcrest.Matcher<Integer>[] matchers = new org.hamcrest.Matcher[codes.length];
        for (int i = 0; i < codes.length; i++) {
            matchers[i] = org.hamcrest.Matchers.equalTo(codes[i]);
        }
        return org.hamcrest.Matchers.anyOf(matchers);
    }
}
