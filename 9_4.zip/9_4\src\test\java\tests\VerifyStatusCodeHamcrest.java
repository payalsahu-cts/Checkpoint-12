package tests;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;

public class VerifyStatusCodeHamcrest {

    @Test
    public void verifyPostBookingStatusCodeUsingHamcrest() {

        String requestBody = "{\n"
                + "    \"firstname\": \"Jim\",\n"
                + "    \"lastname\": \"Brown\",\n"
                + "    \"totalprice\": 111,\n"
                + "    \"depositpaid\": true,\n"
                + "    \"bookingdates\": {\n"
                + "        \"checkin\": \"2018-01-01\",\n"
                + "        \"checkout\": \"2019-01-01\"\n"
                + "    },\n"
                + "    \"additionalneeds\": \"Breakfast\"\n"
                + "}";

        Response response = given()
                    .baseUri("https://restful-booker.herokuapp.com")
                    .contentType(ContentType.JSON)
                    .accept(ContentType.JSON)
                    .body(requestBody)
                .when()
                    .post("/booking")
                .then()
                    .assertThat()
                        // Verify status code using Hamcrest equalTo matcher
                        .statusCode(equalTo(200))
                        // Verify status line using Hamcrest containsString matcher
                        .statusLine(containsString("OK"))
                    .extract()
                    .response();

        System.out.println("Response Status Code : " + response.getStatusCode());
        System.out.println("Response Status Line : " + response.getStatusLine());
        System.out.println("Response Body        : " + response.getBody().asPrettyString());
    }
}
