package tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import java.util.List;

public class UniversitiesTest {

    private static final String BASE_URL  = "http://universities.hipolabs.com";
    private static final String ENDPOINT  = "/search";
    private static final String COUNTRY   = "United States";

    // Scenario 1: Get number of universities in United States and print response log
    @Test
    public void getNumberOfUniversitiesInUnitedStates() {

        Response response = RestAssured
                .given()
                    .baseUri(BASE_URL)
                    .queryParam("country", COUNTRY)
                    .log().all()
                .when()
                    .get(ENDPOINT)
                .then()
                    .log().all()
                    .extract()
                    .response();

        // Get the full list of universities from JSON array response
        List<Object> universities = response.jsonPath().getList("$");

        int totalCount = universities.size();

        System.out.println("=======================================================");
        System.out.println(" Response Status Code  : " + response.getStatusCode());
        System.out.println(" Response Time (ms)    : " + response.getTime());
        System.out.println(" Country Searched      : " + COUNTRY);
        System.out.println(" Total Universities    : " + totalCount);
        System.out.println("=======================================================");
        System.out.println(" Full Response Log     :");
        System.out.println(response.asPrettyString());
        System.out.println("=======================================================");
    }
}
